#!/usr/bin/env python3
import pika

connection = pika.BlockingConnection(pika.URLParameters('amqp://ngogongrabbitmq:abcde12345@rabbit-pub-docker:5672/'))
channel = connection.channel()


channel.queue_declare(queue='rab_pc_client_q')

def callback(ch, method, properties, body):
    print(" [x] Received %r" % body)

channel.basic_consume(callback,
                      queue='rab_pc_client_q',
                      no_ack=True)

print(' [*] Waiting for messages. To exit press CTRL+C')
channel.start_consuming()
