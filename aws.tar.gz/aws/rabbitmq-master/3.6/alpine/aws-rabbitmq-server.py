#! /usr/bin/env python3

from __future__ import print_function
import httplib2
import os
from collections import OrderedDict

import datetime
from datetime import datetime, timedelta, timezone, date
import io
import time
#import data_helpers

import sys
import time
import json
#import lxml.html

import boto3
import pymongo
import pika
import logging

import threading
import copy
import requests



import argparse

parser = argparse.ArgumentParser()
parser.add_argument('inputarg', nargs='*')
argument = parser.parse_args()

print ("argument.inputarg = " , argument.inputarg )
#if argument.inputarg is not None :
if len(argument.inputarg) > 0 :
  if len(argument.inputarg) == 1 :
      args_rabbitmqserverurl =  'amqp://ngogongrabbitmq:abcde12345@rabbit-pub-docker:5672/'
      args_mongodburl = "mongodb+srv://normaluser:abcde12345@cluster0-q3gf2.mongodb.net"
      args_awsurl = "http://ecs-demo-web:3000"
      args_jobid = "99999"
      args_sleeptimeout = 5
  else :
    # ./aws-rabbitmq-server.py "amqp://ngogongrabbitmq:abcde12345@35.227.37.217:5672/" "mongodb+srv://normaluser:abcde12345@cluster0-q3gf2.mongodb.net" "http://loadb-ecs-demo-123071637.us-east-2.elb.amazonaws.com" "99999"
    # id 311293 , similaritieslist = 311034 310728
    # id 311289 , similaritieslist = 311235 311056 31144 311211
    # ./aws-rabbitmq-server.py "amqp://ngogongrabbitmq:abcde12345@localhost:5672/" "mongodb+srv://normaluser:abcde12345@cluster0-q3gf2.mongodb.net" "http://loadb-ecs-demo-123071637.us-east-2.elb.amazonaws.com" "99999"
    
    # ./aws-client-pc-checkstatus.py "amqp://ngogongrabbitmq:abcde12345@35.227.37.217:5672/" "http://loadb-ecs-demo-123071637.us-east-2.elb.amazonaws.com"  "mongodb+srv://normaluser:abcde12345@cluster0-q3gf2.mongodb.net" 
    
    args_rabbitmqserverurl  = argument.inputarg[0]
    args_mongodburl  = argument.inputarg[1]
    args_awsurl  = argument.inputarg[2]
    args_jobid  = argument.inputarg[3]
    args_sleeptimeout = 60

else :
  args_rabbitmqserverurl  = None
  args_mongodburl  = None
  args_awsurl  = None
  args_jobid  = None
  args_sleeptimeout = 60



LOG_FORMAT = ('%(levelname) -10s %(asctime)s %(name) -30s %(funcName) '
                '-35s %(lineno) -5d: %(message)s')
LOGGER = logging.getLogger(__name__)
EXCHANGE = 'ngogongrabbitmqexchange'
EXCHANGE_TYPE = 'topic'
QUEUE = 'ngogongrabbitmqtext'
ROUTING_KEY = 'example.text'


def set_default(obj):
    if isinstance(obj, set):
      print("whats wrong with this obj", obj)
      return list(obj)
    else :
      print("whats wrong with this unknown obj", obj)
      raise TypeError





from enum import Enum
class ServerStatusEnum(Enum) :
   # represent the last status of server
   IDLE = 1
   SENDING_AWS_SCRAPY_REQUEST = 2
   SENDING_AWS_GENSIM_REQUEST = 3

   def toJSON (self):
      return json.dumps(self, default=lambda o: o.__dict__, 
            sort_keys=True, indent=4)

class RabbitmqServerExecption (Exception) :
  def __init__ (self, mesg) :
    self.msg = mesg


class RabbitmqWorker_BLOCK (threading.Thread) :

   def __init__ (self, tname, rabbiturl, 
                       qname, parent, addref, delref=None ):
      threading.Thread.__init__(self)
      self.threadname = tname
      self.queuename = qname
      self.rabbiturl = rabbiturl
      self.parentref = parent
      self.addref = addref
      self.delref = delref
      self.exchange = ''
      self.topic = 'topic'

   def on_request (self, channel, method, properties, body ):
      print ("\n\n\n\n\n---------------------RabbitmqWorker_BLOCK=",self.threadname,
            " on_request 1")
      inDict = json.loads(body)
      # body = { 'prevkey' : , 'key' : , 'data' : }
      if ( self.delref is not None) and ('prevkey' in inDict) :
        self.delref(inDict['prevkey'])
      print ("\n\n\n\n\n---------------------RabbitmqWorker_BLOCK=",self.threadname,
            " on_request 2")

      if 'key' in inDict :
        # 'key''s value is a string
        inDict['data']['properties']={}
        inDict['data']['properties']['correlation_id']= properties.correlation_id \
                if hasattr(properties, 'correlation_id') else None
        inDict['data']['properties']['reply_to']= properties.reply_to \
                if hasattr(properties, 'reply_to') else None
        #copy.deepcopy(properties)
        self.addref( inDict['key'] , inDict['data'] )
      print ("\n\n\n\n\n---------------------RabbitmqWorker_BLOCK=",self.threadname,
            " on_request 3")
      channel.basic_ack(delivery_tag = method.delivery_tag)
      
   def run(self) :
      
      # should it be in a loop or ?
      while True :
        try : 

           print ("---------------------RabbitmqWorker_BLOCK=",self.threadname,
            " run 1111111111111111111111111")
           self.connection = pika.BlockingConnection(pika.connection.URLParameters(
             self.rabbiturl ) )
           #self.exchange = 'ngogongrabbitmqexchange'
           self.channel = self.connection.channel()
           #self.channel.exchange_declare(exchange=self.exchange)
           self.channel.queue_declare(queue = self.queuename )


           #self.channel.basic_qos(prefetch_count=1) 
           self.channel.basic_consume(self.on_request,
                          queue = self.queuename )
           print ("---------------------RabbitmqWorker_BLOCK=",self.threadname,
             " run 2222222222222222222222222")
           try :
             print ("---------------------RabbitmqWorker_BLOCK=",self.threadname,
                " run 33333333333333333333333")
             self.channel.start_consuming()
             print ("---------------------RabbitmqWorker_BLOCK=",self.threadname,
                " run 44444444444444444444444")
           except KeyboardInterrupt:
              print ("---------------------RabbitmqWorker_BLOCK=",self.threadname,
                " run 4.11 keyboardinterrupt")
              self.channel.stop_consuming()
              self.connection.close()
              break
        except pika.exceptions.ConnectionClosed as err:
        #except pika.exceptions.ConnectionClosedByBroker as err:
        # Uncomment this to make the example not attempt recovery
        # from server-initiated connection closure, including
        # when the node is stopped cleanly
        #
        # break
             print ("---------------------RabbitmqWorker_BLOCK=",self.threadname,
                " run 5555 ConnectionClosedByBroker err=", err)         
             continue
        # Do not recover on channel errors
        except pika.exceptions.AMQPChannelError as err:
             print ("---------------------RabbitmqWorker_BLOCK=",self.threadname,
                " run 6666 ConnectionClosedByBroker err=", err)         
             print("Caught a channel error: {}, stopping...".format(err))
             continue
        # Recover on all other connection errors
        except pika.exceptions.AMQPConnectionError as err:
             print ("---------------------RabbitmqWorker_BLOCK=",self.threadname,
                " run 7777 ConnectionClosedByBroker err=", err)         
             print("Connection was closed, retrying...")
             continue
           
              

   def publish(self, in_exchange, 
              in_routing_key, #reply q name
              in_correlation_id,
              in_body  ) :
       
       self.channel.basic_publish(exchange=in_exchange if len(in_exchange) > 0 else self.exchange,
                          routing_key=in_routing_key, #reply q name
                          properties=pika.BasicProperties( correlation_id = \
                            in_correlation_id ),
                          body= in_body  ) 
                



class RabbitmqServer_BLOCK () :

   wait_finish_pc_client_q=OrderedDict()
   finish_pc_client_q=OrderedDict()
   wait_pc_client_q = OrderedDict()
   lock_wait_pc_client_q = threading.RLock()
   def addWaitPCClientQ ( self, k, v) :
     with self.lock_wait_pc_client_q :
        print ("\n\n\n\n\n++++++++++++++++++++ inside addWaitPCClientQ")
        self.wait_pc_client_q[k]= v 
   def delWaitPCClientQ ( self, k ) :
     with self.lock_wait_pc_client_q :
        if k in self.wait_pc_client_q:
           del self.wait_pc_client_q[k]



   wait_aws_task_to_finish_q = OrderedDict()
   lock_wait_aws_task_to_finish_q = threading.RLock ()
   def addWaitAWSTaskToFinishQ ( self, k, v) :
     with self.lock_wait_aws_task_to_finish_q :
        print ("++++++++++++++++++++ inside addWaitAWSTaskToFinishQ")
        self.wait_aws_task_to_finish_q[k]= v 
        print ("++++++++++++++++++++ inside addWaitAWSTaskToFinishQ",
          self.wait_aws_task_to_finish_q 
        )
   def delWaitAWSTaskToFinishQ ( self, k ) :
     with self.lock_wait_aws_task_to_finish_q :
        if k in self.wait_aws_task_to_finish_q:
           del self.wait_aws_task_to_finish_q[k]
   
    

   def addWaitAssignArticleIDQ ( self, k, v) :
     with self.lock_wait_assign_articleid_q :
        print ("++++++++++++++++++++ inside addWaitAssignArticleIDQ")
        self.wait_assign_articleid_q[k]= v 
        print ("++++++++++++++++++++ inside addWaitAssignArticleIDQ",
         self.wait_assign_articleid_q)
   def delWaitAssignArticleIDQ ( self, k ) :
     with self.lock_wait_assign_articleid_q :
        if k in self.wait_assign_articleid_q:
           del self.wait_assign_articleid_q[k]



   wait_finish_assign_articleid_q = OrderedDict()
   lock_wait_finish_assign_articleid_q = threading.RLock()
   def addWaitFinishAssignArticleIDQ ( self, k, v) :
     with self.lock_wait_finish_assign_articleid_q :
        print ("++++++++++++++++++++ inside addWaitFinishAssignArticleIDQ")
        self.wait_finish_assign_articleid_q[k]= v 
        print ("++++++++++++++++++++ inside addWaitFinishAssignArticleIDQ",
          self.wait_finish_assign_articleid_q)
   def delWaitFinishAssignArticleIDQ ( self, k ) :
     with self.lock_wait_finish_assign_articleid_q :
        if k in self.wait_finish_assign_articleid_q:
           del self.wait_finish_assign_articleid_q[k]

   def addFinishAssignArticleIDQ ( self, k, v) :
     with self.lock_finish_assign_articleid_q :
        print ("++++++++++++++++++++ inside addFinishAssignArticleIDQ")
        self.finish_assign_articleid_q[k]= v 
        print ("++++++++++++++++++++ inside addFinishAssignArticleIDQ",
          self.finish_assign_articleid_q)
   def delFinishAssignArticleIDQ ( self, k ) :
     with self.lock_finish_assign_articleid_q :
        if k in self.finish_assign_articleid_q:
           del self.finish_assign_articleid_q[k]


   wait_gensim_start_q = OrderedDict()
   lock_wait_gensim_start_q = threading.RLock()
   def addWaitGensimStartQ ( self, k, v) :
     with self.lock_wait_gensim_start_q :
        print ("++++++++++++++++++++ inside addWaitGensimStartQ")
        self.wait_gensim_start_q[k]= v 
        print ("++++++++++++++++++++ inside addWaitGensimStartQ",
          self.wait_gensim_start_q)
   def delWaitGensimStartQ ( self, k ) :
     with self.lock_wait_gensim_start_q :
        if k in self.wait_gensim_start_q:
           del self.wait_gensim_start_q[k]

   wait_gensim_finish_q = OrderedDict()
   lock_wait_gensim_finish_q = threading.RLock()
   def addWaitGensimFinishQ ( self, k, v) :
     with self.lock_wait_gensim_finish_q :
        print ("++++++++++++++++++++ inside addWaitGensimFinishQ")
        self.wait_gensim_finish_q[k]= v 
        print ("++++++++++++++++++++ inside addWaitGensimFinishQ",
          self.wait_gensim_finish_q)
   def delWaitGensimFinishQ ( self, k ) :
     with self.lock_wait_gensim_finish_q :
        if k in self.wait_gensim_finish_q:
           del self.wait_gensim_finish_q[k]


   def addDoneGensimQ ( self, k, v) :
     with self.lock_done_gensim_q :
        print ("++++++++++++++++++++ inside addDoneGensimQ")
        self.done_gensim_q[k]= v 
        print ("++++++++++++++++++++ inside addDoneGensimQ",
          self.done_gensim_q)
   def delDoneGensimQ ( self, k ) :
     with self.lock_done_gensim_q :
        if k in self.done_gensim_q:
           del self.done_gensim_q[k]


   def addTaskToStartQ (self) :
      self.wait_aws_task_to_start = OrderedDict()
      self.wait_aws_task_to_start['16'] = { 'firstsubdomaintable_id' : "16" ,
                        'domaintable_id' : "14",
                        'categorytable_id' : "3" }
      self.wait_aws_task_to_start['1'] = { 'firstsubdomaintable_id' : "1" ,
                        'domaintable_id' : "1",
                        'categorytable_id' : "3" }
      self.wait_aws_task_to_start['11'] = { 'firstsubdomaintable_id' : "11" ,
                        'domaintable_id' : "10",
                        'categorytable_id' : "3" }
      self.wait_aws_task_to_start['10'] = { 'firstsubdomaintable_id' : "10" ,
                        'domaintable_id' : "9",
                        'categorytable_id' : "3" }
      self.wait_aws_task_to_start['3'] = { 'firstsubdomaintable_id' : "3" ,
                        'domaintable_id' : "4",
                        'categorytable_id' : "3" }
      self.wait_aws_task_to_start['9'] = { 'firstsubdomaintable_id' : "9" ,
                        'domaintable_id' : "8",
                        'categorytable_id' : "3" }
      self.wait_aws_task_to_start['7'] = { 'firstsubdomaintable_id' : "7" ,
                        'domaintable_id' : "6",
                        'categorytable_id' : "3" }
      self.wait_aws_task_to_start['13'] = { 'firstsubdomaintable_id' : "13" ,
                        'domaintable_id' : "11",
                        'categorytable_id' : "3" }
      """                  
      self.wait_aws_task_to_start['14'] = { 'firstsubdomaintable_id' : "14" ,
                        'domaintable_id' : "12",
                        'categorytable_id' : "3" }
      """                  
      self.wait_aws_task_to_start['15'] = { 'firstsubdomaintable_id' : "15" ,
                        'domaintable_id' : "13",
                        'categorytable_id' : "3" }

      """                  
      self.wait_aws_task_to_start['16'] = { 'firstsubdomaintable_id' : "16" ,
                        'domaintable_id' : "14",
                        'categorytable_id' : "3" }
      """

      self.wait_aws_task_to_start['18'] = { 'firstsubdomaintable_id' : "18" ,
                        'domaintable_id' : "15",
                        'categorytable_id' : "3" }


      self.wait_aws_task_to_start['2'] = { 'firstsubdomaintable_id' : "2" ,
                        'domaintable_id' : "2",
                        'categorytable_id' : "2" }
      self.wait_aws_task_to_start['17'] = { 'firstsubdomaintable_id' : "17" ,
                        'domaintable_id' : "4",
                        'categorytable_id' : "2" }
      self.wait_aws_task_to_start['8'] = { 'firstsubdomaintable_id' : "8" ,
                        'domaintable_id' : "8",
                        'categorytable_id' : "2" }
      self.wait_aws_task_to_start['6'] = { 'firstsubdomaintable_id' : "6" ,
                        'domaintable_id' : "6",
                        'categorytable_id' : "2" }
      self.wait_aws_task_to_start['19'] = { 'firstsubdomaintable_id' : "19" ,
                        'domaintable_id' : "16",
                        'categorytable_id' : "2" }


      self.wait_aws_task_to_start['20'] = { 'firstsubdomaintable_id' : "20" ,
                        'domaintable_id' : "17",
                        'categorytable_id' : "5" }
      self.wait_aws_task_to_start['24'] = { 'firstsubdomaintable_id' : "24" ,
                        'domaintable_id' : "21",
                        'categorytable_id' : "5" }



      self.wait_aws_task_to_start['21'] = { 'firstsubdomaintable_id' : "21" ,
                        'domaintable_id' : "18",
                        'categorytable_id' : "6" }
      self.wait_aws_task_to_start['25'] = { 'firstsubdomaintable_id' : "25" ,
                        'domaintable_id' : "22",
                        'categorytable_id' : "6" }
      self.wait_aws_task_to_start['26'] = { 'firstsubdomaintable_id' : "26" ,
                        'domaintable_id' : "2",
                        'categorytable_id' : "6" }
      self.wait_aws_task_to_start['33'] = { 'firstsubdomaintable_id' : "33" ,
                        'domaintable_id' : "22",
                        'categorytable_id' : "6" }



      self.wait_aws_task_to_start['27'] = { 'firstsubdomaintable_id' : "27" ,
                        'domaintable_id' : "2",
                        'categorytable_id' : "7" }
      self.wait_aws_task_to_start['28'] = { 'firstsubdomaintable_id' : "28" ,
                        'domaintable_id' : "8",
                        'categorytable_id' : "7" }
      self.wait_aws_task_to_start['29'] = { 'firstsubdomaintable_id' : "29" ,
                        'domaintable_id' : "4",
                        'categorytable_id' : "7" }


      self.wait_aws_task_to_start['30'] = { 'firstsubdomaintable_id' : "30" ,
                        'domaintable_id' : "2",
                        'categorytable_id' : "8" }
      self.wait_aws_task_to_start['31'] = { 'firstsubdomaintable_id' : "31" ,
                        'domaintable_id' : "8",
                        'categorytable_id' : "8" }
      self.wait_aws_task_to_start['32'] = { 'firstsubdomaintable_id' : "32" ,
                        'domaintable_id' : "4",
                        'categorytable_id' : "8" }



   def addWaitGensimTaskToStartQ (self) :
      self.wait_aws_gensim_to_start = OrderedDict()
      self.wait_aws_gensim_to_start['8'] = { \
               '30' : { 'firstsubdomaintable_id' : "30" ,
                        'domaintable_id' : "2",
                        'categorytable_id' : "8" }, 
               '31' : { 'firstsubdomaintable_id' : "31" ,
                        'domaintable_id' : "8",
                        'categorytable_id' : "8" }, 
               '32' : { 'firstsubdomaintable_id' : "32" ,
                        'domaintable_id' : "4",
                        'categorytable_id' : "8" }, 
      }
      
      self.wait_aws_gensim_to_start['7'] = { \
               '27' : { 'firstsubdomaintable_id' : "27" ,
                        'domaintable_id' : "2",
                        'categorytable_id' : "7" }, 
               '28' : { 'firstsubdomaintable_id' : "28" ,
                        'domaintable_id' : "8",
                        'categorytable_id' : "7" }, 
               '29' : { 'firstsubdomaintable_id' : "29" ,
                        'domaintable_id' : "4",
                        'categorytable_id' : "7" }, 
      }
      
      
      self.wait_aws_gensim_to_start['3'] = { \
               '1' : { 'firstsubdomaintable_id' : "1" ,
                        'domaintable_id' : "1",
                        'categorytable_id' : "3" }, 
               '11' : { 'firstsubdomaintable_id' : "11" ,
                        'domaintable_id' : "10",
                        'categorytable_id' : "3" }, 
               '10' : { 'firstsubdomaintable_id' : "10" ,
                        'domaintable_id' : "9",
                        'categorytable_id' : "3" }, 
               '3' : { 'firstsubdomaintable_id' : "3" ,
                        'domaintable_id' : "4",
                        'categorytable_id' : "3" }, 
               '9' : { 'firstsubdomaintable_id' : "9" ,
                        'domaintable_id' : "8",
                        'categorytable_id' : "3" }, 
               '7' : { 'firstsubdomaintable_id' : "7" ,
                        'domaintable_id' : "6",
                        'categorytable_id' : "3" }, 
               '13' : { 'firstsubdomaintable_id' : "13" ,
                        'domaintable_id' : "11",
                        'categorytable_id' : "3" }, 
               #'14' : { 'firstsubdomaintable_id' : "14" ,
               #         'domaintable_id' : "12",
               #         'categorytable_id' : "3" }, 
               '15' : { 'firstsubdomaintable_id' : "15" ,
                        'domaintable_id' : "13",
                        'categorytable_id' : "3" }, 
               '16' : { 'firstsubdomaintable_id' : "16" ,
                        'domaintable_id' : "14",
                        'categorytable_id' : "3" }, 
               '18' : { 'firstsubdomaintable_id' : "18" ,
                        'domaintable_id' : "15",
                        'categorytable_id' : "3" }, 
      }
      


      self.wait_aws_gensim_to_start['2'] = { \
               '2' : { 'firstsubdomaintable_id' : "2" ,
                        'domaintable_id' : "2",
                        'categorytable_id' : "2" }, 
               '17' : { 'firstsubdomaintable_id' : "17" ,
                        'domaintable_id' : "4",
                        'categorytable_id' : "2" }, 
               '8' : { 'firstsubdomaintable_id' : "8" ,
                        'domaintable_id' : "8",
                        'categorytable_id' : "2" }, 
               '6' : { 'firstsubdomaintable_id' : "6" ,
                        'domaintable_id' : "6",
                        'categorytable_id' : "2" }, 
               '19' : { 'firstsubdomaintable_id' : "19" ,
                        'domaintable_id' : "16",
                        'categorytable_id' : "2" }, 
      }
      

      self.wait_aws_gensim_to_start['5'] = { \
               '20' : { 'firstsubdomaintable_id' : "20" ,
                        'domaintable_id' : "17",
                        'categorytable_id' : "5" }, 
               '24' : { 'firstsubdomaintable_id' : "24" ,
                        'domaintable_id' : "24",
                        'categorytable_id' : "5" }, 
      }
      

      self.wait_aws_gensim_to_start['6'] = { \
               '21' : { 'firstsubdomaintable_id' : "21" ,
                        'domaintable_id' : "18",
                        'categorytable_id' : "6" }, 
               '25' : { 'firstsubdomaintable_id' : "25" ,
                        'domaintable_id' : "22",
                        'categorytable_id' : "6" }, 
               '26' : { 'firstsubdomaintable_id' : "26" ,
                        'domaintable_id' : "2",
                        'categorytable_id' : "6" }, 
               '33' : { 'firstsubdomaintable_id' : "33" ,
                        'domaintable_id' : "22",
                        'categorytable_id' : "6" }, 
      }
      

   def addWaitGensimTaskToStartQ_Test (self) :
      self.wait_aws_gensim_to_start = OrderedDict()
      self.wait_aws_gensim_to_start['8'] = { }
      self.wait_aws_gensim_to_start['7'] = { }
      self.wait_aws_gensim_to_start['3'] = { }

      self.wait_aws_gensim_to_start['2'] = {}

      self.wait_aws_gensim_to_start['5'] = { }

      self.wait_aws_gensim_to_start['6'] = { }


   def __init__ (self, ampqurl ):
      self.ampqurl = 'localhost'
      self.awsurl = 'localhost'
      self.mongodburl = 'localhost'
      self.jobid = None
      self.articleID = None
      self.articleIDForward = None
      self.connecturl = 'localhost'
      self.rabbiturl = ampqurl
      self.wait_aws_gensim_to_start = None
      self.waitFirstsubdomain = None
      self.errstartscrapy = []
      self.errstartgensim = []
      self.latestupdatetimelist = []
      self.timerjobscrapyq = []
      self.timerjobscrapyforgetq = []
      self.timerjobgensimq = []
      self.timerjobgensimforgetq = []


      self.rab_pc_client_th = RabbitmqWorker_BLOCK( "rab_pc_client_th",
                       self.rabbiturl, "rab_pc_client_q",
                       self, self.addWaitPCClientQ )

      # thread to handle aws task to wait for assign article id
      self.rab_wait_assign_articleid_th=0
      
      self.rab_wait_assign_articleid_th = RabbitmqWorker_BLOCK( \
                       "rab_wait_assign_articleid_th",
                       self.rabbiturl, "wait_assign_articleid_q",
                       self , self.addWaitAssignArticleIDQ ,
                       self.delWaitAWSTaskToFinishQ )
                       
      self.wait_assign_articleid_q = OrderedDict()
      self.lock_wait_assign_articleid_q = threading.RLock()

      #aws task send back to let server know it0 has finished the assign
      #article id
      self.rab_finish_assign_articleid_th =0
      
      self.rab_finish_assign_articleid_th = RabbitmqWorker_BLOCK( \
                       "rab_finish_assign_articleid_th",
                       self.rabbiturl, "finish_assign_articleid_q",
                       self, self.addFinishAssignArticleIDQ,
                       self.delWaitFinishAssignArticleIDQ )
      
      self.finish_assign_articleid_q = OrderedDict()
      self.lock_finish_assign_articleid_q = threading.RLock()


      self.rab_done_gensim_th =0
      
      self.rab_done_gensim_th = RabbitmqWorker_BLOCK( \
                       "rab_done_gensim_th",
                       self.rabbiturl, "done_gensim_q",
                       self, self.addDoneGensimQ,
                       self.delWaitGensimFinishQ )
      
      self.done_gensim_q = OrderedDict()
      self.lock_done_gensim_q = threading.RLock()

   

   def run(self) :
      #start the thread to handle request from client
      print (" \n\n\n---------------RabbitmqServer_BLOCK whileloopwait 0.1 ")

      self.rab_pc_client_th.start() 
      print ("  \n\n\n---------------RabbitmqServer_BLOCK whileloopwait 0.2 ")
      self.rab_wait_assign_articleid_th.start()
      print ("  \n\n\n---------------RabbitmqServer_BLOCK whileloopwait 0.3 ")
      self.rab_finish_assign_articleid_th.start()
      print ("  \n\n\n---------------RabbitmqServer_BLOCK whileloopwait 0.4 ")
      self.rab_done_gensim_th.start()
      print (" ---------------RabbitmqServer_BLOCK whileloopwait 0.5 ")

      whileloopwait = True
      self.serverstatus = ServerStatusEnum.IDLE
                  
      #force gensim for now
      #
      #
      if args_jobid is not None:
        self.addWaitGensimTaskToStartQ_Test()
        self.rabbitmqserverurl =  args_rabbitmqserverurl
        self.mongodburl = args_mongodburl
        self.awsurl = args_awsurl
        self.jobid = args_jobid

      while whileloopwait :
         # checking pc client request
         print (" ---------------RabbitmqServer_BLOCK whileloopwait 1 ")
         try :
          with self.lock_wait_pc_client_q :
           print (" ---------------RabbitmqServer_BLOCK lock_wait_pc_client_q 1 ")
           if len(self.wait_pc_client_q) > 0 :
             #process the request 
             for k, v in self.wait_pc_client_q.items() :
                if k == 'scrapyrequest' :
                  if len(self.wait_finish_pc_client_q) > 0 :
                    #only one scrapyrequest at a time
                    reasonofrefuse = { 'reason' : 
                        'server is processing one request already' }
                    """    
                    self.rab_pc_client_th.publish(exchange='',
                          routing_key=v['replytoq'], #reply q name
                          properties=pika.BasicProperties( correlation_id = \
                            v['correlationid'] ),
                          body= json.dumps(reasonofrefuse)  ) 
                    """
                    self.rab_pc_client_th.publish('',
                          v['replytoq'], #reply q name
                          v['correlationid'] ,
                          json.dumps(reasonofrefuse)  ) 
                    print ("--------------- RabbitmqServer_BLOCK lock_wait_pc_client_q 2 ")
                  else :
                    print ("--------------- RabbitmqServer_BLOCK lock_wait_pc_client_q 3 ")
                    self.jobid = v['jobid']
                    self.mongodburl = v['mongodburl']
                    self.awsurl = v['awsurl']
                    self.articleID = v['articleID']
                    self.articleIDForward = v['articleID']
                    self.firstsubupdatedict = v['firstsubupdatedict']
                    self.rabbitmqserverurl = v['rabbitmqserverurl']
                    #key in the wait_finish_pc_client_q is "request name" like
                    # scrapyrequest and value will be from aws-client-pc.py 
                    v['start-processing-request-time'] = int(datetime.now().timestamp())
                    self.wait_finish_pc_client_q[k] = v
                    self.addTaskToStartQ()
                    self.addWaitGensimTaskToStartQ()
                    print ("--------------- RabbitmqServer_BLOCK lock_wait_pc_client_q 4 ")
                elif k == 'checkstatus' :
                  print ("--------------- RabbitmqServer_BLOCK lock_wait_pc_client_q 5 ")
                  bodymsg = OrderedDict()
                  bodymsg['wait_pc_client_q'] = self.wait_pc_client_q
                  bodymsg['wait_aws_task_to_finish_q'] = \
                      self.wait_aws_task_to_finish_q 
                  print ("--------------- RabbitmqServer_BLOCK lock_wait_pc_client_q 5.1 ",
                    self.wait_aws_task_to_finish_q)

                  bodymsg['wait_assign_articleid_q'] = \
                      self.wait_assign_articleid_q 
                  print ("--------------- RabbitmqServer_BLOCK lock_wait_pc_client_q 5.2 ",
                    self.wait_assign_articleid_q)
                  bodymsg['wait_finish_assign_articleid_q'] = \
                      self.wait_finish_assign_articleid_q 
                  print ("--------------- RabbitmqServer_BLOCK lock_wait_pc_client_q 5.3 ",
                    self.wait_finish_assign_articleid_q)
                  bodymsg['finish_assign_articleid_q'] = \
                      self.finish_assign_articleid_q 
                  print ("--------------- RabbitmqServer_BLOCK lock_wait_pc_client_q 5.4 ",
                    self.finish_assign_articleid_q)
                  bodymsg['wait_gensim_finish_q'] = \
                      self.wait_gensim_finish_q 
                  print ("--------------- RabbitmqServer_BLOCK lock_wait_pc_client_q 5.5 ",
                    self.wait_gensim_finish_q)
                  bodymsg['done_gensim_q'] = \
                      self.done_gensim_q 
                  print ("--------------- RabbitmqServer_BLOCK lock_wait_pc_client_q 5.6 ",
                    self.done_gensim_q)
                  bodymsg['serverstatusenum'] = \
                      str(self.serverstatus)
                  bodymsg['articleID'] = \
                      str(self.articleID)
                  bodymsg['articleIDForward'] = \
                      str(self.articleIDForward)
                  bodymsg['wait_aws_gensim_to_start'] = \
                      self.wait_aws_gensim_to_start
                  bodymsg['waitFirstsubdomain'] = \
                      self.waitFirstsubdomain
                  bodymsg['errstartscrapy'] = \
                      self.errstartscrapy
                  bodymsg['errstartgensim'] = \
                      self.errstartgensim
                  bodymsg['latestupdatetimelist'] = \
                      self.latestupdatetimelist
                  bodymsg['timerjobscrapyq'] = \
                      self.timerjobscrapyq
                  bodymsg['timerjobscrapyforgetq'] = \
                      self.timerjobscrapyforgetq
                  bodymsg['timerjobgensimq'] = \
                      self.timerjobgensimq
                  bodymsg['timerjobgensimforgetq'] = \
                      self.timerjobgensimforgetq
                  bodymsg['wait_finish_pc_client_q'] = \
                      self.wait_finish_pc_client_q
                  bodymsg['finish_pc_client_q'] = \
                      self.finish_pc_client_q
                      
                  print ("------------------- RabbitmqServer_BLOCK body_msg=", bodymsg)
                  print ("------------------- RabbitmqServer_BLOCK type of v[correlationid]",
                     type(v['correlationid']), ",value=",v['correlationid'])

                  self.rab_pc_client_th.publish('',
                     v['replytoq'],
                     v['correlationid'] if type(v['correlationid']) == str else str(v['correlationid']),
                     json.dumps(bodymsg, default=set_default)
                     )    

                  """    
                  self.channel.basic_publish(exchange='',
                          routing_key=v['replytoq'], #reply q name
                          properties=pika.BasicProperties( correlation_id = \
                            v['correlationid'] ),
                          body= json.dumps(bodymsg)  ) 
                  """    
                  print (" ---------------RabbitmqServer_BLOCK lock_wait_pc_client_q 6 ")
                else :
                    print (" ---------------RabbitmqServer_BLOCK lock_wait_pc_client_q 7 ")
                    reasonofrefuse = { 'reason' : 'invalid request=' + k + \
                                       ' , end' }
                    self.rab_pc_client_th.publish ('',
                         v['replytoq'],
                         v['correlationid'],
                         json.dumps(reasonofrefuse)
                       )
                    """                   
                    self.channel.basic_publish(exchange='',
                          routing_key=v['replytoq'], #reply q name
                          properties=pika.BasicProperties( correlation_id = \
                            v['correlationid'] ),
                          body= json.dumps(reasonofrefuse)  ) 
                    """
                    print (" ---------------RabbitmqServer_BLOCK lock_wait_pc_client_q 8 ")


             #remove every request in the q
             # just reset it
             self.wait_pc_client_q = {}
         except RabbitmqServerExecption as e :
            print ("--------------------RabbitmqServerExecption e.msg=", e.msg)   

         # start the scrapy work which is queued
         remove_list=[] 
         try :
          with self.lock_wait_aws_task_to_finish_q :
           # sending request to aws task
           print ("--------------- RabbitmqServer_BLOCK self.lock_wait_aws_task_to_finish_q 1")
           if not hasattr(self, 'wait_aws_task_to_start') or len(self.wait_aws_task_to_start) <= 0 :
             
             raise RabbitmqServerExecption("nothing to process in wait_aws_task_to_start") 
           for firstsubdomainid, value in self.wait_aws_task_to_start.items() : 
              # example of "value"
              # self.wait_aws_task_to_start['32'] = { 
              #          'firstsubdomaintable_id' : 32 ,
              #          'domaintable_id' : 4,
              #          'categorytable_id' : 8 }

              print ("--------------- RabbitmqServer_BLOCK self.lock_wait_aws_task_to_finish_q 2 firstsubdomainid=", firstsubdomainid)
              firstsubupdatekey = "firstsubdomaintable_id_" + firstsubdomainid
              latesttime = self.firstsubupdatedict[firstsubupdatekey]
              
              requestbody = { 'jobid' : self.jobid ,
                              'mongodburl' : self.mongodburl,
                              'firstsubdomaintable_id' : \
                                 firstsubdomainid,
                              'domaintable_id' : \
                                 value['domaintable_id'],
                              'categorytable_id' : \
                                 value['categorytable_id'],
                              'latestupdatetime' : \
                                 latesttime,
                              'rabbitmqserverurl' : \
                                 self.rabbitmqserverurl,
                              'timestart' : \
                                 int(datetime.now().timestamp()), 
                                 }
              print (" ---------------RabbitmqServer_BLOCK self.lock_wait_aws_task_to_finish_q 2.1 requestbody=",
               requestbody)
              print (" ---------------RabbitmqServer_BLOCK self.lock_wait_aws_task_to_finish_q 2.2 articleid=",
                self.articleID, ", afrticleidforward=", self.articleIDForward)
              

              sleep_count=1
              response=None
              while sleep_count < 10 and response is None:
                print (" ---------------RabbitmqServer_BLOCK self.lock_wait_aws_task_to_finish_q 2.3 ")
                try :    
                   print (" ---------------RabbitmqServer_BLOCK self.lock_wait_aws_task_to_finish_q 2.4 ")
                   response = requests.post(self.awsurl + '/web/startscrapy' ,
                   #       json=json.dumps(requestbody) )
                          json=requestbody )
                   print (" ---------------RabbitmqServer_BLOCK self.lock_wait_aws_task_to_finish_q 2.5 ")
                except requests.ConnectionError as e:
                   print("  ---------------RabbitmqServer_BLOCK  self.lock_wait_aws_task_to_finish_q ",
                     "OOPS!! Connection Error. Make sure you are connected to Internet. Technical Details given below.\n")
                   print(str(e))
                   sleep_count += 1            
                   time.sleep(5*sleep_count)
                   continue
                except requests.Timeout as e:
                   print("    ---------------RabbitmqServer_BLOCK  self.lock_wait_aws_task_to_finish_q OOPS!! Timeout Error")
                   print(str(e))
                   sleep_count += 1            
                   time.sleep(5*sleep_count)
                   continue
                except requests.RequestException as e:
                   print("    ---------------RabbitmqServer_BLOCK  self.lock_wait_aws_task_to_finish_q OOPS!! General Error")
                   print(str(e))
                   sleep_count += 1            
                   time.sleep(5*sleep_count)
                   continue

              if sleep_count == 10 :
                print("    ---------------RabbitmqServer_BLOCK  self.lock_finish_assign_articleid_q cannot make requests")
                os._exit(-1)
                 

              print (" ---------------RabbitmqServer_BLOCK self.lock_wait_aws_task_to_finish_q 3 firstsubdomainid=", firstsubdomainid)
              
              if (response.status_code == 200)  :
                 bodymsg = response.json()
                 print (" ---------------RabbitmqServer_BLOCK self.lock_wait_aws_task_to_finish_q 4 firstsubdomainid=", firstsubdomainid,
                   ", bodymsg=", bodymsg)
                 if bodymsg['responsestatus'] == 'willprocess' :
                    print (" ---------------RabbitmqServer_BLOCK self.lock_wait_aws_task_to_finish_q 5 firstsubdomainid=", 
                       firstsubdomainid , ", bodymsg=" ,
                       bodymsg )
                    #del self.wait_aws_task_to_start[firstsubdomainid]
                    self.addWaitAWSTaskToFinishQ( firstsubdomainid , value ) 
                    print (" ---------------RabbitmqServer_BLOCK self.lock_wait_aws_task_to_finish_q 5.1 ")
                    remove_list.append(firstsubdomainid)
                    ldict = OrderedDict()
                    ldict1 = {}
                    ldict1[firstsubdomainid] = value
                    ldict[int(datetime.now().timestamp())] = \
                         ldict1
                    self.timerjobscrapyq.append(ldict)
  
                    time.sleep(5)
                    print (" ---------------RabbitmqServer_BLOCK self.lock_wait_aws_task_to_finish_q 5.2 ")
                 elif bodymsg['responsestatus'] == 'willprocessgensim' :
                    print (" ---------------RabbitmqServer_BLOCK self.lock_wait_aws_task_to_finish_q 5.6 firstsubdomainid=", 
                       firstsubdomainid , ", bodymsg=" ,
                       bodymsg )
                    raise RabbitmqServerExecption(" willprocessgensim") 
                 elif bodymsg['responsestatus'] == 'busywithscrapy' :
                    print (" ---------------RabbitmqServer_BLOCK self.lock_wait_aws_task_to_finish_q 6 firstsubdomainid=", 
                       firstsubdomainid , ", bodymsg=" ,
                       bodymsg )
                    raise RabbitmqServerExecption(" busywithscrapy") 
                 elif bodymsg['responsestatus'] == 'errorawsscrapychildprocesssh' :
                    print (" ---------------RabbitmqServer_BLOCK self.lock_wait_aws_task_to_finish_q 6.1 firstsubdomainid=", 
                       firstsubdomainid , ", bodymsg=" ,
                       bodymsg )
                    raise RabbitmqServerExecption(" errorawsscrapychildprocesssh") 

                 elif bodymsg['responsestatus'] == 'busywaitassignarticleid' :
                    print (" ---------------RabbitmqServer_BLOCK self.lock_wait_aws_task_to_finish_q 7 firstsubdomainid=", 
                       firstsubdomainid , ", bodymsg=" ,
                       bodymsg )
                    raise RabbitmqServerExecption(" busywaitassignarticleid") 
                 elif bodymsg['responsestatus'] == 'busyassignarticleid' :
                    print (" ---------------RabbitmqServer_BLOCK self.lock_wait_aws_task_to_finish_q 7.1 firstsubdomainid=", 
                       firstsubdomainid , ", bodymsg=" ,
                       bodymsg )
                    raise RabbitmqServerExecption(" busyassignarticleid") 
                 elif bodymsg['responsestatus'] == 'errorawsassignchildprocesspy' :
                    print (" ---------------RabbitmqServer_BLOCK self.lock_wait_aws_task_to_finish_q 7.2 firstsubdomainid=", 
                       firstsubdomainid , ", bodymsg=" ,
                       bodymsg )
                    raise RabbitmqServerExecption(" errorawsassignchildprocesspy") 
                 elif bodymsg['responsestatus'] == 'errorselfdestruct' :
                    print (" ---------------RabbitmqServer_BLOCK self.lock_wait_aws_task_to_finish_q 7.3 firstsubdomainid=", 
                       firstsubdomainid , ", bodymsg=" ,
                       bodymsg )
                    raise RabbitmqServerExecption(" errorselfdestruct") 
                 elif bodymsg['responsestatus'] == 'selfdestructing' :
                    print (" ---------------RabbitmqServer_BLOCK self.lock_wait_aws_task_to_finish_q 7.4 firstsubdomainid=", 
                       firstsubdomainid , ", bodymsg=" ,
                       bodymsg )
                    raise RabbitmqServerExecption(" selfdestructing") 

                 elif bodymsg['responsestatus'] == 'busywithgensim' :
                    print (" ---------------RabbitmqServer_BLOCK self.lock_wait_aws_task_to_finish_q 8 firstsubdomainid=", 
                       firstsubdomainid , ", bodymsg=" ,
                       bodymsg )
                    raise RabbitmqServerExecption(" busywithgensim") 
                 elif bodymsg['responsestatus'] == 'errorstartgensim' :
                    print (" ---------------RabbitmqServer_BLOCK self.lock_wait_aws_task_to_finish_q 8.1 firstsubdomainid=", 
                       firstsubdomainid , ", bodymsg=" ,
                       bodymsg )
                    raise RabbitmqServerExecption(" errorstartgensim") 
 
              else :
                 print (" ---------------RabbitmqServer_BLOCK self.lock_wait_aws_task_to_finish_q 9 firstsubdomainid=", 
                      firstsubdomainid, ",status_code=",
                      response.status_code , ", response.json()=" )
                      #response.json() )
                 errbody = { firstsubdomainid : { "requestbody" : requestbody ,
                                                  "status_code" : response.status_code , 
                                                  "time" : int(datetime.now().timestamp()) } }                                               
                 self.errstartscrapy.append(errbody)
                 raise RabbitmqServerExecption(" unknown status code") 
 
          
         except RabbitmqServerExecption as e :
            print ("--------------------RabbitmqServerExecption e.msg=", e.msg)   

         #remove item in wait_aws_task_to_start
         for k in remove_list :
           if k in self.wait_aws_task_to_start :
             del self.wait_aws_task_to_start[k]
             print (" ---------------RabbitmqServer_BLOCK self.lock_wait_aws_task_to_finish_q 10 del k=",k) 
             

         try :  
          with self.lock_wait_assign_articleid_q :
          #with self.lock_wait_aws_task_to_finish_q :
           # sending request to aws task
           print (" ---------------RabbitmqServer_BLOCK lock_wait_assign_articleid_q 10")

           # get the no of rows from this firstsubdomain 
           # 
           print (" ---------------RabbitmqServer_BLOCK lock_wait_assign_articleid_q 10.1 articleid=",
                self.articleID, ", afrticleidforward=", self.articleIDForward)

           if hasattr(self, 'waitFirstsubdomain') and \
              self.waitFirstsubdomain is None and \
              len(self.wait_assign_articleid_q) >0 :
             #that's okay to assign because the last one has been finished
             #self.waitFirstsubdomain = self.wait_assign_articleid_q.popitem(last=False)
             testwaitFirstsubdomain = self.wait_assign_articleid_q.popitem(last=False)
             #find the job in timer q
             #for now if the job has worked more than an hour 
             foundtimerjob=False
             indexfoundtimerjob=-1
             """
             for i, x in enumerate(self.timerjobscrapyforgetq) :
                # x is the orderdict
                x_tup = x.popitem(last=False)
                # x_tup[0] , timestamp
                # x_tup[1] , { firstsubdomainid : value }
                # ldict = OrderedDict()
                # ldict[int(datetime.now(timezone(timedelta(hours=8))).timestamp())] = \
                # { firstsubdomainid : value }
                for x_tup_key_firstsubd in x_tup[1].keys() :
                  if testwaitFirstsubdomain[0] == x_tup_key_firstsubd and \
                      int(testwaitFirstsubdomain[1]['correlationid']) > int(x_tup[0]) +3600 :
                    foundtimerjob=True
                    indexfoundtimerjob = i
                    print (" ---------------RabbitmqServer_BLOCK ",  
                       " lock_wait_assign_articleid_q found-forgettimerjob =", 
                       " firstsubdomainid=" , x_tup_key_firstsubd , " index=", i)                  
                    break
                if foundtimerjob :
                  break
             else :
                print (" ---------------RabbitmqServer_BLOCK ",
                  " lock_wait_assign_articleid_q forgettimerjob good " )

             if foundtimerjob and (indexfoundtimerjob != -1) :
                print (" ---------------RabbitmqServer_BLOCK ",
                  " lock_wait_assign_articleid_q delete timerjobscrapyforgetq ",
                  " = ", self.timerjobscrapyq[indexfoundtimerjob])
                del self.timerjobscrapyforgetq[indexfoundtimerjob]
                errstring = " RabbitmqServer_BLOCK lock_wait_assign_articleid_q" + \
                   " found timerjobscrapyforgetq firstsubdomainid=" + \
                   str(testwaitFirstsubdomain)
                raise RabbitmqServerExecption(errstring)  
             """



             print (" ---------------RabbitmqServer_BLOCK ",  
                       " lock_wait_assign_articleid_q timerjobscrapyq =",
                       self.timerjobscrapyq) 
             for i, x in enumerate(self.timerjobscrapyq) :
                for timestamp in x.keys() :
                  # x is the orderdict
                  item  = x[timestamp]
                  # x[0] , timestamp
                  # x[1] , { firstsubdomainid : value }
                  # ldict = OrderedDict()
                  # ldict[int(datetime.now(timezone(timedelta(hours=8))).timestamp())] = \
                  # { firstsubdomainid : value }
                  for x_key_firstsubd in item.keys() :
                    if testwaitFirstsubdomain[0] == x_key_firstsubd :
                      foundtimerjob=True
                      indexfoundtimerjob = i
                      self.waitFirstsubdomain = testwaitFirstsubdomain
                      print (" ---------------RabbitmqServer_BLOCK ",  
                         " lock_wait_assign_articleid_q foundtimerjob =", 
                         " firstsubdomainid=" , x_key_firstsubd , " index=", i)                  
                      break
                  if foundtimerjob :
                    break
                if foundtimerjob :
                  break
             else :
                print (" ---------------RabbitmqServer_BLOCK ",
                  " lock_wait_assign_articleid_q something wrong ",
                  " with foundtimerjob error ")
                errstring = " RabbitmqServer_BLOCK lock_wait_assign_articleid_q" + \
                   " cannot find firstsubdomainid=" + str(testwaitFirstsubdomain)
                raise RabbitmqServerExecption(errstring)  

             if foundtimerjob and indexfoundtimerjob != -1:
                print (" ---------------RabbitmqServer_BLOCK ",
                  " lock_wait_assign_articleid_q delete timerjobscrapyq ",
                  " = ", self.timerjobscrapyq[indexfoundtimerjob])
                del self.timerjobscrapyq[indexfoundtimerjob]
             

           else :
             #it is still doing the assigning
             print (" ---------------RabbitmqServer_BLOCK lock_wait_assign_articleid_q error 11")
             raise RabbitmqServerExecption(" no waitfirstsubdomain")
           print (" ---------------RabbitmqServer_BLOCK lock_wait_assign_articleid_q 11.1 articleid=",
                self.articleID, ", afrticleidforward=", self.articleIDForward)

           #it should be only one 
           # [0] = firstsubdomain id , [1] = data
           print (" ---------------RabbitmqServer_BLOCK lock_wait_assign_articleid_q  12", 
               ",k=", self.waitFirstsubdomain[0] , ", v=", self.waitFirstsubdomain[1])
           totalarticlehasbeenscrap = self.waitFirstsubdomain[1]['noofrow']  
           replyqname = self.waitFirstsubdomain[1]['replyqueuename']
           correlationid = self.waitFirstsubdomain[1]['correlationid']
           elem_latestupdatetimelist = self.waitFirstsubdomain[1]['latestupdatetime']
           if isinstance(elem_latestupdatetimelist, str) :
             if len(elem_latestupdatetimelist) > 10 :
                print (" ---------------RabbitmqServer_BLOCK lock_wait_assign_articleid_q  12.1",
                  len(elem_latestupdatetimelist), ",elem_latestupdatetimelist=",
                  elem_latestupdatetimelist )          
             print (" ---------------RabbitmqServer_BLOCK lock_wait_assign_articleid_q  12.2",
                  len(elem_latestupdatetimelist), ",elem_latestupdatetimelist=",
                  elem_latestupdatetimelist )
             #elem_latestupdatetimelist = datetime.strptime(elem_latestupdatetimelist,"%Y-%m-%d %H:%M:%S.%f")
           #if '-' not in elem_latestupdatetimelist and '.' not in elem_latestupdatetimelist:
           #  #this is weird, covert 15xxxxxxxx format to str of time format
           #  elem_latestupdatetimelist = datetime.fromtimestamp(elem_latestupdatetimelist).strftime("%Y-%m-%d %H:%M:%S.%f")




           self.latestupdatetimelist.append({
             "firstsubdomaintable_id_" + self.waitFirstsubdomain[0] :
                elem_latestupdatetimelist  } )


           self.articleIDForward = str(int(self.articleID) + \
                                       int(totalarticlehasbeenscrap) )

           jsonresponse = { 'articleIDForward' : self.articleID }

           print(" ---------------RabbitmqServer_BLOCK lock_wait_assign_articleid_q 13",
             " ,jsonresponse=", jsonresponse)
           self.rab_wait_assign_articleid_th.publish ( '',
                replyqname,
                correlationid,
                json.dumps(jsonresponse)
              )

           #assign to wait_finish_assign
           self.addWaitFinishAssignArticleIDQ(self.waitFirstsubdomain[0],
              self.waitFirstsubdomain[1])


           """
           self.channel.basic_publish(exchange=self.exchange,
                        routing_key = replyqname, 
                        properties=pika.BasicProperties(
                          # reply_to = replyqname,
                          correlation_id = correlationId
                          ),
                        body=str(self.articleIDForward)
                        )
           """
           #should i do the following?
           #
           #while self.response is None:
           #self.connection.process_data_events()
           #return int(self.response)
 

           """
           self.articleID 
                    self.addWaitAWSTaskToFinishQ( firstsubdomainid , value )   

           self.rab_wait_assign_articleid_th = RabbitmqWorker_BLOCK( \
                       "rab_wait_assign_articleid",
                       self.rabbiturl, "wait_assign_articleid_q",
                       self )
           """
         except RabbitmqServerExecption as e :
            print ("--------------------RabbitmqServerExecption e.msg=", e.msg)   


         try :  
          with self.lock_finish_assign_articleid_q :
           # sending request to aws task
           # wait_aws_gensim_to_start

           print (" ---------------RabbitmqServer_BLOCK lock_finish_assign_articleid_q 1")
           
           if self.wait_aws_gensim_to_start is None :
              raise RabbitmqServerExecption(" not yet ready to gensim") 

           # [0]= firstsubdomain_id , [1] = data section from index.js
           if len(self.finish_assign_articleid_q) > 0:
             finishassign_tup = self.finish_assign_articleid_q.popitem(last=False) 
             self.articleID = self.articleIDForward

           else :
             finishassign_tup = None 
           print (" ---------------RabbitmqServer_BLOCK ",
                    "lock_finish_assign_articleid_q 1.1 finishassign_tup=" ,
                    finishassign_tup
                    )

           print (" ---------------RabbitmqServer_BLOCK ",
                    "lock_finish_assign_articleid_q 1.2 waitFirstsubdomain=" ,
                    self.waitFirstsubdomain
                    )
           if self.waitFirstsubdomain is not None and \
              finishassign_tup is not None and \
              self.waitFirstsubdomain[0] == finishassign_tup[0] :
              self.waitFirstsubdomain = None

           print (" ---------------RabbitmqServer_BLOCK lock_finish_assign_articleid_q 1.3 articleid=",
                self.articleID, ", afrticleidforward=", self.articleIDForward)

           # delete the firstsubdomain which is just finish assign
           if finishassign_tup is not None :
            for k, v in self.wait_aws_gensim_to_start.items() :
             if len(v) > 0 :
               if finishassign_tup[0] in v :
                 print (" ---------------RabbitmqServer_BLOCK ",
                    "lock_finish_assign_articleid_q 2")
                 # finishassign_tup[0] is firstsubdomaintable_id 
                 del v[finishassign_tup[0]]
                 break

           print (" ---------------RabbitmqServer_BLOCK ",
                    "lock_finish_assign_articleid_q 3 wait_aws_gensim_to_start.keys=",
                    self.wait_aws_gensim_to_start.keys())
           
           remove_list=[]
           gensim_cat_id = None
           gensim_script_name = None
           if '2' in self.wait_aws_gensim_to_start and \
              '3' in self.wait_aws_gensim_to_start and \
              len(self.wait_aws_gensim_to_start['2']) == 0 and \
              len(self.wait_aws_gensim_to_start['3']) == 0 and \
              '2-3' not in self.done_gensim_q :
              # nothing start gensim yet
              # start gensim now
              gensim_cat_id = '2-3'
              remove_list.append('2')
              remove_list.append('3')
              gensim_script_name = 'aws-gonggensim.py'
              
           elif '5' in self.wait_aws_gensim_to_start and \
                '6' in self.wait_aws_gensim_to_start and \
                len(self.wait_aws_gensim_to_start['5']) == 0 and \
                len(self.wait_aws_gensim_to_start['6']) == 0 and \
                '5-6' not in self.done_gensim_q :
              # nothing start gensim yet
              # start gensim now
              gensim_cat_id = '5-6'
              remove_list.append('5')
              remove_list.append('6')
              gensim_script_name = 'aws-gonggensim-fin.py'
           elif '7' in self.wait_aws_gensim_to_start and \
                len(self.wait_aws_gensim_to_start['7']) == 0 and \
                '7' not in self.done_gensim_q :
              # nothing start gensim yet
              # start gensim now
              remove_list.append('7')
              gensim_cat_id = '7'
              gensim_script_name = 'aws-gonggensim-sport.py'
           elif '8' in self.wait_aws_gensim_to_start and \
                len(self.wait_aws_gensim_to_start['8']) == 0 and \
                '8' not in self.done_gensim_q :
              # nothing start gensim yet
              # start gensim now
              remove_list.append('8')
              gensim_cat_id = '8'
              gensim_script_name = 'aws-gonggensim-ent.py'
           else :
              raise RabbitmqServerExecption(" _wait_aws_gensim_to_start, nothing to start") 



                      

           
           if gensim_cat_id is not None :
              requestbody = { 'jobid' : self.jobid ,
                              'mongodburl' : self.mongodburl,
                              'categorytable_id' : \
                                 gensim_cat_id,
                              'rabbitmqserverurl' : \
                                 self.rabbitmqserverurl,
                              'gensimscript_name' : \
                                 gensim_script_name,
                              'timestart' : \
                                 int(datetime.now().timestamp()),
                              }
              print (" ---------------RabbitmqServer_BLOCK ",
                 " self.lock_finish_assign_articleid_q 4 requestbody=",
                 requestbody)


              sleep_count=1
              response=None
              while sleep_count < 10 and response is None:
                print (" ---------------RabbitmqServer_BLOCK ",
                    " self.lock_finish_assign_articleid_q 4.1 ")
                try :    
                   print (" ---------------RabbitmqServer_BLOCK ",
                    " self.lock_finish_assign_articleid_q 4.2 ")
                   response = requests.post(self.awsurl + '/web/startgensim' ,
                   #            json=json.dumps(requestbody) )
                                json=requestbody )
                   print (" ---------------RabbitmqServer_BLOCK ",
                    " self.lock_finish_assign_articleid_q 4.3 ")
                except requests.ConnectionError as e:
                   print("  ---------------RabbitmqServer_BLOCK  self.lock_finish_assign_articleid_q ",
                     "OOPS!! Connection Error. Make sure you are connected to Internet. Technical Details given below.\n")
                   print(str(e))
                   sleep_count += 1            
                   time.sleep(5*sleep_count)
                   continue
                except requests.Timeout as e:
                   print("    ---------------RabbitmqServer_BLOCK  self.lock_finish_assign_articleid_q OOPS!! Timeout Error")
                   print(str(e))
                   sleep_count += 1            
                   time.sleep(5 *sleep_count)
                   continue
                except requests.RequestException as e:
                   print("    ---------------RabbitmqServer_BLOCK  self.lock_finish_assign_articleid_q OOPS!! General Error")
                   print(str(e))
                   sleep_count += 1            
                   time.sleep(5 * sleep_count)
                   continue


              if sleep_count == 10 :
                print("    ---------------RabbitmqServer_BLOCK  self.lock_finish_assign_articleid_q cannot make requests")
                os._exit(-1)
                 
              print (" ---------------RabbitmqServer_BLOCK ",
                 " self.lock_finish_assign_articleid_q 5 ")
              if (response.status_code == 200)  :
                 bodymsg = response.json()
                 print (" ---------------RabbitmqServer_BLOCK ",
                      " self.lock_finish_assign_articleid_q 6 ",
                      ", bodymsg=", bodymsg)
                 if bodymsg['responsestatus'] == 'willprocessgensim' :
                    print (" ---------------RabbitmqServer_BLOCK ",
                       " self.lock_finish_assign_articleid_q 7 gensim_cat_id=", 
                       gensim_cat_id , ", bodymsg=" ,
                       bodymsg )
                    #del self.wait_aws_task_to_start[firstsubdomainid]
                    self.addWaitGensimFinishQ( gensim_cat_id , requestbody ) 
                    ldict = OrderedDict()
                    ldict[int(datetime.now().timestamp())] = \
                        gensim_cat_id
                    self.timerjobgensimq.append(ldict)

                    print (" ---------------RabbitmqServer_BLOCK ",
                       " self.lock_finish_assign_articleid_q 8 gensim_cat_id=", 
                       gensim_cat_id , ", remove_list=", remove_list)
                    for x in remove_list :
                       del self.wait_aws_gensim_to_start[x]
                 elif bodymsg['responsestatus'] == 'willprocess' :
                    print (" ---------------RabbitmqServer_BLOCK ",
                       " self.lock_finish_assign_articleid_q 8.5 gensim_cat_id=", 
                       gensim_cat_id , ", bodymsg=" ,
                       bodymsg )
                    raise RabbitmqServerExecption(" willprocess") 

                 elif bodymsg['responsestatus'] == 'busywithscrapy' :
                    print (" ---------------RabbitmqServer_BLOCK ",
                       " self.lock_finish_assign_articleid_q 9 gensim_cat_id=", 
                       gensim_cat_id , ", bodymsg=" ,
                       bodymsg )
                    raise RabbitmqServerExecption(" busywithscrapy") 
                 elif bodymsg['responsestatus'] == 'errorawsscrapychildprocesssh' :
                    print (" ---------------RabbitmqServer_BLOCK ",
                       " self.lock_finish_assign_articleid_q 9.1 gensim_cat_id=", 
                       gensim_cat_id , ", bodymsg=" ,
                       bodymsg )
                    raise RabbitmqServerExecption(" errorawsscrapychildprocesssh") 

                 elif bodymsg['responsestatus'] == 'busywaitassignarticleid' :
                    print (" ---------------RabbitmqServer_BLOCK ",
                       " self.lock_finish_assign_articleid_q 10 gensim_cat_id=", 
                       gensim_cat_id , ", bodymsg=" ,
                       bodymsg )
                    raise RabbitmqServerExecption(" busywaitassignarticleid") 
                 elif bodymsg['responsestatus'] == 'busyassignarticleid' :
                    print (" ---------------RabbitmqServer_BLOCK ",
                       " self.lock_finish_assign_articleid_q 10.1 gensim_cat_id=", 
                       gensim_cat_id , ", bodymsg=" ,
                       bodymsg )
                    raise RabbitmqServerExecption(" busyassignarticleid") 
                 elif bodymsg['responsestatus'] == 'errorawsassignchildprocesspy' :
                    print (" ---------------RabbitmqServer_BLOCK ",
                       " self.lock_finish_assign_articleid_q 10.2 gensim_cat_id=", 
                       gensim_cat_id , ", bodymsg=" ,
                       bodymsg )
                    raise RabbitmqServerExecption(" errorawsassignchildprocesspy") 
                 elif bodymsg['responsestatus'] == 'errorselfdestruct' :
                    print (" ---------------RabbitmqServer_BLOCK ",
                       " self.lock_finish_assign_articleid_q 10.2 gensim_cat_id=", 
                       gensim_cat_id , ", bodymsg=" ,
                       bodymsg )
                    raise RabbitmqServerExecption(" errorselfdestruct") 
                 elif bodymsg['responsestatus'] == 'selfdestructing' :
                    print (" ---------------RabbitmqServer_BLOCK ",
                       " self.lock_finish_assign_articleid_q 10.2 gensim_cat_id=", 
                       gensim_cat_id , ", bodymsg=" ,
                       bodymsg )
                    raise RabbitmqServerExecption(" selfdestructing") 
                    
                 elif bodymsg['responsestatus'] == 'busywithgensim' :
                    print (" ---------------RabbitmqServer_BLOCK ",
                       " self.lock_finish_assign_articleid_q 11 gensim_cat_id=", 
                       gensim_cat_id , ", bodymsg=" ,
                       bodymsg )
                    raise RabbitmqServerExecption(" busywithgensim") 
                 elif bodymsg['responsestatus'] == 'errorstartgensim' :
                    print (" ---------------RabbitmqServer_BLOCK ",
                       " self.lock_finish_assign_articleid_q 11.1 gensim_cat_id=", 
                       gensim_cat_id , ", bodymsg=" ,
                       bodymsg )
                    raise RabbitmqServerExecption(" errorstartgensim") 
 
              else :
                 print (" ---------------RabbitmqServer_BLOCK ",
                       " self.lock_finish_assign_articleid_q 11 gensim_cat_id=", 
                      gensim_cat_id, ",status_code=",
                      response.status_code , ", response.json()=" )
                      #response.json() )
                 errbody = { gensim_cat_id : { "requestbody" : requestbody ,
                                                  "status_code" : response.status_code,
                                                  "time" : int(datetime.now().timestamp()) }  }                                               
                 self.errstartgensim.append(errbody)
     
                 raise RabbitmqServerExecption(" unknown status code") 
         
         except RabbitmqServerExecption as e :
            print ("--------------------RabbitmqServerExecption e.msg=", e.msg)   
             







         try :  
          with self.lock_done_gensim_q :
           # sending request to aws task
           # wait_aws_gensim_to_start

           print (" ---------------RabbitmqServer_BLOCK lock_done_gensim_q 1")
           index=-1
           foundgensim = False
           #                    ldict = OrderedDict()
           #         ldict[int(datetime.now().timestamp())] = \
           #             gensim_cat_id
           #         self.timerjobgensimq.append(ldict)
           for i, ele in enumerate(self.timerjobgensimq) :
             for k,v in ele.items() :
               if v in self.done_gensim_q :
                 index=i
                 foundgensim = True
                 print (" ---------------RabbitmqServer_BLOCK lock_done_gensim_q 1.1",
                   " index=", index)
                 break
             if foundgensim :
               break
           if index != -1 and foundgensim :
             del self.timerjobgensimq[index]

           # delete the older than 1 hr
           #for k,v in self.done_gensim_q.items() :
           #  if int(v['properties']['correlation_id']) > int(datetime.now().timestamp())

           # it should only have 2-3 5-6 7 8 
           if len(self.done_gensim_q) == 4 and \
                '2-3' in self.done_gensim_q and \
                '5-6' in self.done_gensim_q and \
                '7' in self.done_gensim_q and \
                '8' in self.done_gensim_q :
                print (" ---------------RabbitmqServer_BLOCK lock_done_gensim_q 2")
                if len(self.wait_finish_pc_client_q) == 1 :
                   replyclientitem = self.wait_finish_pc_client_q.popitem(last=False)
                   replyclientitem[1]['endtime']= int(datetime.now().timestamp())
                   self.finish_pc_client_q[replyclientitem[0]]=replyclientitem[1]
                   print (" ---------------RabbitmqServer_BLOCK lock_done_gensim_q 3")

                   reasonofreply = { 'reason' : 
                        'done' ,
                        'latestupdatetimelist' :
                        self.latestupdatetimelist }
                   print (" ---------------RabbitmqServer_BLOCK lock_done_gensim_q 3.1",
                     replyclientitem[1]['replytoq'] )
                   print (" ---------------RabbitmqServer_BLOCK lock_done_gensim_q 3.2",
                     replyclientitem[1]['correlationid'] )
                   print (" ---------------RabbitmqServer_BLOCK lock_done_gensim_q 3.3",
                     json.dumps(reasonofreply) )
                   self.rab_pc_client_th.publish('',
                          replyclientitem[1]['replytoq'], #reply q name
                          str(replyclientitem[1]['correlationid']) ,
                          json.dumps(reasonofreply)  ) 

                   print (" ---------------RabbitmqServer_BLOCK lock_done_gensim_q 4")

           else :
             print (" ---------------RabbitmqServer_BLOCK lock_done_gensim_q 4")
                      
         except RabbitmqServerExecption as e :
            print ("--------------------RabbitmqServerExecption e.msg=", e.msg)   
             










         print (" ---------------RabbitmqServer_BLOCK lock_wait_assign_articleid_q error 13 args_sleeptimeout=",
           args_sleeptimeout)
         #start to remove and add timerjob
         #                    ldict = OrderedDict()
         #           ldict[int(datetime.now().timestamp())] = \
         #                { firstsubdomainid : value }
         #           self.timerjobscrapyq.append(ldict)
         #           ldict = OrderedDict()
         #           ldict[int(datetime.now().timestamp())] = \
         #               gensim_cat_id
         #           self.timerjobgensimq.append(ldict)
         removelist = []
         for i, x in enumerate(self.timerjobscrapyq) :
           for k,v in x.items() :
             if k + 3400 < int(datetime.now().timestamp()) :
               #
               removelist.append(i)
               vtup = v.popitem()
               self.timerjobscrapyforgetq.append( { k : { vtup[0] : vtup[1] }})
               self.delWaitAWSTaskToFinishQ(vtup[0])
               self.wait_aws_task_to_start[vtup[0]] = vtup[1]

         print (" ---------------RabbitmqServer_BLOCK lock_wait_assign_articleid_q ",
          "error 13.1 removescrapylist=",
           removelist)
         for x in removelist :
           del self.timerjobscrapyq[x]

         removelist = []
         for i, x in enumerate(self.timerjobgensimq) :
           for k,v in x.items() :
             if k + 3400 < int(datetime.now().timestamp()) :
               #
               removelist.append(i)
               self.delWaitGensimFinishQ(v)
               if '-' in v :
                 two_cat= v.split('-') 
                 self.wait_aws_gensim_to_start[two_cat[0]] = {}
                 self.wait_aws_gensim_to_start[two_cat[1]] = {}
               else :
                 self.wait_aws_gensim_to_start[v] = {}                 

         print (" ---------------RabbitmqServer_BLOCK lock_wait_assign_articleid_q ",
          "error 13.2 removegensimlist=",
           removelist)
         for x in removelist :
           self.timerjobgensimforgetq.append(self.timerjobgensimq[x])
           del self.timerjobgensimq[x]

         sys.stderr.flush()
         sys.stdout.flush()
         time.sleep(args_sleeptimeout)

         print (" ---------------RabbitmqServer_BLOCK lock_wait_assign_articleid_q error 14 args_sleeptimeout=",
           args_sleeptimeout)
   



 
def main():
    logging.basicConfig(level=logging.DEBUG, format=LOG_FORMAT)

    # Connect to localhost:5672 as guest with the password guest and virtual host "/" (%2F)
    awspc_client = RabbitmqServer_BLOCK('amqp://ngogongrabbitmq:abcde12345@localhost:5672/')
    print ("---------------aws-rabbitmq-server.py 1")
    awspc_client.run()
    print ("---------------aws-rabbitmq-server.py 2")


if __name__ == '__main__':
    main()




