A folder with inspection data for Splash IPython kernel.

:file:`splash-auto.json` is generated from reference documentation using
:file:`scripts/rst2inspections.py` script.
