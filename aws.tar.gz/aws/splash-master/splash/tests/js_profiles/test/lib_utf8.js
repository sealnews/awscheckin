//
//  Javascript test library
//
function test_utf8(x){ 
    return x + '®';
}
