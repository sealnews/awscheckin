//
//  Javascript test library
//
function test2(x){ 
    // Calls a function defined in another lib of the same js profile
    return test(x) + test(x);
}
