-- this module is not listed in --lua-sandbox-allowed-modules
local disabled = {
  hello="world"
}
return disabled
