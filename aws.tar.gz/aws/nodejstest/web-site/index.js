console.log("Oh Yeah!")
const express = require('express')
const app = express()
var bodyparser = require('body-parser');
app.use(bodyparser.json());
app.use(bodyparser.urlencoded({ extended: true }))
var testcount = 0
var awstaskstatus = "idle"
console.log("==========> inside index.js ========= ")
var jobInfo = new Map();
var currcorrelationid = Date.now().toString().slice(0,10);
var worklist = new Map();
var worklistcount = 0;
var randomnumbername = Math.floor(Math.random() * Math.floor(10000000));
var servername="servername" + randomnumbername.toString();
var serverstarttime = Date.now().toString().slice(0,10) 
jobInfo.set('servername', servername);
jobInfo.set('server-starttime', serverstarttime);
var os = require('os');
var systemmemorytotalvalue = os.totalmem()
var systemmemoryfreevalue = os.freemem()
jobInfo.set('systemmemorytotalvalue', os.totalmem() );
jobInfo.set('systemmemoryfreevalue', os.freemem() );
// t2.small
// systemmemorytotalvalue	2092408832
// systemmemoryfreevalue	1572478976



function mapToObj(inputMap) {
  let obj = {};

  inputMap.forEach(function (value, key) {
    obj[key] = value
  });

  return obj;
}

app.get('/web', function (req, res) {
  testcount += 1
  console.log("------ /web -----Oh Yeah!", testcount)
  res.send('------ /web -----Hello World!')
})

app.get('/web/hello', function (req, res) {
  testcount += 100
  console.log("------ /web hello -----Oh Yeah!", testcount)
  res.send('------- /web hello ------- hello----Hello World!')
})

app.get('/web/hello1', function (req, res) {
  testcount += 1000
  console.log("------ /web hello -----Oh Yeah!", testcount)
  res.send('------- /web hello ------- hello----Hello World!')
})

app.get('/web/startdatabase', function (req, res) {
  const database = require('./database')
  database.initializeMongo();
  res.send('startdatabase----Hello World!')
})


app.get('/web/testFind', function (req, res) {
  const database = require('./database')
  database.Kitten.find(function (err, kittens) {
    if (err) res.status(500).send({ error: err });
    console.log("the return result ----> --->");
    console.log("hello");
    console.log(kittens);
    res.json(kittens);
  })
})

app.get('/web/taskstatus', function (req, res) {
  testcount += 1000
  console.log("------ /web hello -----Oh Yeah! status=", awstaskstatus);
  res.send('------- /web hello ------- hello----Hello World!' + awstaskstatus);
})

app.get('/web/workliststatus', function (req, res) {
  testcount += 1000;
  var resultobj = mapToObj(worklist);
  console.log("------ /web hello -----Oh Yeah! status=", resultobj);
  res.json(resultobj);
})

app.get('/web/awsstatus', function (req, res) {
  testcount += 1000;
  var bodyresponse = new Map();
  console.log(" --- /web/awstatus ---- 1 " )
  bodyresponse.set("responsestatus", awstaskstatus);
  bodyresponse.set("data", mapToObj(jobInfo));
  bodyresponse.set("worklist", mapToObj(worklist));
  bodyresponse.set("current-servertime", Date.now().toString().slice(0,10));
  var os = require('os');
  var networkinterfaces = os.networkInterfaces();
  bodyresponse.set("networkinterfaces", networkinterfaces);
  res.json(mapToObj(bodyresponse));
  console.log(" --- /web/awstatus ---- 2 " )

})

// curl -d '{"jobid" : "jobid-value",
// "mongodburl" : "mongodburl-val", 
// "firstsubdomaintable_id" : "firstsubdomaintable_id-val", 
// "domaintable_id" : "domaintable_id-val", 
// "categorytable_id" : "categorytable_id-val",
// "latestupdatetime" : "latestupdatetime-val" }' -H "Content-Type: application/json" -X POST http://localhost:3000/web/startscrapy
app.post('/web/startscrapy', function (req, res) {
  var bodyresponse = new Map();
  //var bodyresponse = {};
  console.log(" --- /web/startscrapy ---- 1 body= ")
  console.log(req.body)
  console.log(" --- /web/startscrapy ---- 1.1 body= ")

  if ( (awstaskstatus == "idle") && 
       ( req.body.firstsubdomaintable_id.toString() == "14") &&
       ( systemmemorytotalvalue < 2200000000 )){
        bodyresponse.set("responsestatus", busywithscrapy);
        bodyresponse.set("data", mapToObj(jobInfo))
        res.json(mapToObj(bodyresponse));
        console.log("------ /web/startscrapy hello -----needbiggerram bodyresponse=" + bodyresponse);
        console.log(bodyresponse)
        console.log("------ /web/startscrapy hello -----needbiggerram bodyresponse=" + bodyresponse);
          
  } 


  if (awstaskstatus == "idle") {
    console.log(" --- /web/startscrapy ---- 2 " )
    bodyresponse.set("responsestatus", "willprocess");
    if (req.body.hasOwnProperty("jobid")) {
      console.log(" --- /web/startscrapy ---- jobid=" + req.body.jobid);
      console.log(" --- /web/startscrapy ---- mongodburl=" + req.body.mongodburl);
      console.log(" --- /web/startscrapy ---- firstsubdomaintable_id=" + req.body.firstsubdomaintable_id);
      console.log(" --- /web/startscrapy ---- domaintable_id=" + req.body.domaintable_id);
      console.log(" --- /web/startscrapy ---- categorytable_id=" + req.body.categorytable_id);
      console.log(" --- /web/startscrapy ---- latestupdatetime=" + req.body.latestupdatetime);
      console.log(" --- /web/startscrapy ---- rabbitmqserverurl=" + req.body.rabbitmqserverurl);
      console.log(" --- /web/startscrapy ---- timestart=" + req.body.timestart);
      jobInfo.set('jobid', req.body.jobid);
      jobInfo.set('mongodburl', req.body.mongodburl);
      jobInfo.set('firstsubdomaintable_id', req.body.firstsubdomaintable_id);
      jobInfo.set('domaintable_id', req.body.domaintable_id);
      jobInfo.set('categorytable_id', req.body.categorytable_id);
      jobInfo.set('latestupdatetime', req.body.latestupdatetime);
      jobInfo.set('rabbitmqserverurl', req.body.rabbitmqserverurl);
      jobInfo.set('timestart', req.body.timestart);
      awstaskstatus = "busywithscrapy";
      console.log(" typeof " + typeof awstaskstatus);

      //start the python scrapy process
      const { exec } = require('child_process');
      var execstr = "cd /usr/src/app/python/gong_01 ; " +
        " /usr/src/app/python/gong_01/aws-scrapychildprocess.sh " +
        ` ${req.body.jobid} ${req.body.mongodburl} ` +
        ` ${req.body.firstsubdomaintable_id} ` +
        ` ${req.body.domaintable_id} ` +
        ` ${req.body.categorytable_id} ` +
        ` ${req.body.latestupdatetime} `
        ;
      var worklisttime = Date.now().toString().slice(0,10)  
      worklist.set(worklistcount.toString(), worklisttime + ",,,,," + 
         execstr);
      worklistcount += 1;

      console.log( "execstr = " + execstr)
      console.log( " before exec")
      exec(execstr, {maxBuffer: 1024 * 10000}, (error, stdout, stderr) => {
        if (error) {
          console.error(`exec error 1: ${error}`);
          console.error(`exec error 2 stderr: ${stderr}`);
          console.error(`exec error 3 stdout: ${stdout}`);
          jobInfo.set("error_errmsg", `errorawsscrapychildprocesssh ${error}`)
          jobInfo.set("error_stderrmsg", `errorawsscrapychildprocesssh ${stderr}`)
          jobInfo.set("error_execstr", `errorawsscrapychildprocesssh ${execstr}`)
          awstaskstatus = "errorawsscrapychildprocesssh"
          return;
        }
        // console.log(` --- /web/startscrapy ----stdout: ${stdout}`);
        console.log(`  --- /web/startscrapy ----stderr: ${stderr}`);
      });
    console.log(" --- /web/startscrapy ---- 3 " )
    

    }
    console.log(" --- /web/startscrapy ---- 4 " )
  } else {
    console.log(" --- /web/startscrapy ---- 5 " )
    bodyresponse.set("responsestatus", awstaskstatus);
    bodyresponse.set("data", mapToObj(jobInfo))
  }
  testcount += 1000;
  console.log("------ /web/startscrapy hello -----Oh Yeah! ", testcount);
  //res.json will set the content type correctly, otherwise, use res.send
  // need to set it up for response
  res.json(mapToObj(bodyresponse));
  console.log("------ /web/startscrapy hello -----Oh Yeah! bodyresponse=" + bodyresponse);
  console.log(bodyresponse)
  console.log("------ /web/startscrapy hello -----Oh Yeah! bodyresponse=" + bodyresponse);
})



app.get('/web/donescrapy', function (req, res) {
  testcount += 1000

  // tell rabbitmqserver that we are done scrapy, need to do the
  // assign articleid
  awstaskstatus = "busywaitassignarticleid";

  var amqp = require('amqplib/callback_api');
  //amqp.connect('amqp://ngogongrabbitmq:abcde12345@rabbit-pub-docker:5672/',
  console.log(" /web/donescrapy before connect 1")
  console.log(jobInfo.get('rabbitmqserverurl'))
  console.log(" /web/donescrapy before connect 2")

  var worklisttime1 = Date.now().toString().slice(0,10)  
  worklist.set(worklistcount.toString(), worklisttime1 + ",,,,," + 
     "donescrapy");
  worklistcount += 1;

  if ( (parseInt(jobInfo.get('timestart')) + 3400) < 
     parseInt(Date.now().toString().slice(0,10) ) ) {
     console.error("------ /web/donescrapy overtime ", testcount);
     res.send('------- /web/donescrapy overtime');
     awstaskstatus = "idle";
     jobInfo = new Map();
     jobInfo.set('servername', servername);
     jobInfo.set('server-starttime', serverstarttime);
     jobInfo.set('systemmemorytotalvalue', os.totalmem() );
     jobInfo.set('systemmemoryfreevalue', os.freemem() );


     return
  }

  
  amqp.connect(jobInfo.get('rabbitmqserverurl'),
    function (err, conn) {
      if (err) {
        console.log("xxxxxxxx error /web/donescrapy connect 1 err=" + err + "xxxxxx");
        return err;
      }
      conn.createChannel(function (err, ch) {
        if (err) {
          console.log("xxxxxxxx error /web/donescrapy connect 2  err=" + err + "xxxxxx");
          return err;
        }
        //ch.assertExchange("ngogongrabbitmqexchange", "topic")
        ch.assertQueue('', { durable : false  }, function (err, q) {
          if (err) {
            console.log("xxxxxxxx error /web/donescrapy connect 3  err=" + err + "xxxxxx");
            return err;
          }

          ch.consume(q.queue, function (msg) {
            if (msg.properties.correlationId == currcorrelationid) {
              //rabbitmq reply back, so start assign article id and send it to 
              //mongodb and dynamodb
              console.log(' /web/donescrapy [.] Got %s', msg.content.toString());
              console.log(msg.content);
              console.log(' /web/donescrapy [.] Got %s', msg.content.toString());
              //start the python scrapy process
              var contentstring = msg.content.toString()
              var jsonstr = JSON.parse(contentstring)
              const { exec } = require('child_process');
              var execstr = "cd /usr/src/app/python/gong_01 ; " +
                "/usr/src/app/python/gong_01/aws-assignchildprocess.py " +
                ` ${jobInfo.get("jobid")} ${jobInfo.get("mongodburl")} ` +
                ` ${jobInfo.get("firstsubdomaintable_id")} ` +
                ` ${jobInfo.get("domaintable_id")} ` +
                ` ${jobInfo.get("categorytable_id")} ` +
                ` ${jobInfo.get("totalarticlecount")} ` +
                ` ${jsonstr.articleIDForward} `;
              console.log(' /web/donescrapy jsonstr');
              console.log(jsonstr);
              console.log(' /web/donescrapy jsonstr');
              console.log(' /web/donescrapy execstr');
              console.log(execstr);
              console.log(' /web/donescrapy execstr');

              var worklisttime = Date.now().toString().slice(0,10)  
              worklist.set(worklistcount.toString(), worklisttime + ",,,,," + 
                 execstr);
              worklistcount += 1;
              awstaskstatus = "busyassignarticleid";

                      
              exec(execstr, {maxBuffer: 1024 * 10000}, (error, stdout, stderr) => {
                if (error) {
                  console.error(`exec error 11 : ${error}`);
                  console.error(`exec error 12 stderr: ${stderr}`);
                  console.error(`exec error 13 stdout: ${stdout}`);
                  jobInfo.set("error_errmsg", `errorawsassignchildprocesspy ${error}`)
                  jobInfo.set("error_stderrmsg", `errorawsassignchildprocesspy ${stderr}`)
                  jobInfo.set("error_execstr", `errorawsassignchildprocesspy ${execstr}`)
                  awstaskstatus = "errorawsassignchildprocesspy"
        
                  return;
                }
                //console.log(` /web/donescrapy stdout: ${stdout}`);
                console.log(` /web/donescrapy stderr: ${stderr}`);
              });
              /*  */


              setTimeout(function () { conn.close(); /*process.exit(0)*/ }, 500);
            }
          }, { noAck: true });

          var bodyobj = {};
          bodyobj['prevkey'] = jobInfo.get('firstsubdomaintable_id');
          bodyobj['key'] = jobInfo.get('firstsubdomaintable_id');
          bodyobj['data'] = mapToObj(jobInfo);
          var r_latestupdatetime = Date.now().toString().slice(0,10);
          jobInfo.set('r_latestupdatetime', r_latestupdatetime);

          var finalresult = 999;
          sqlite = require('sqlite');
          const dbPromise = new Promise(function (resolve, reject) {
            const dbprom = sqlite.open('/usr/src/app/python/gong_01/gong.db',
              { Promise });
            var testv1 = "testv1";

            // dbprom -> database promise
            var tresultp1 = dbprom.then(function (result) {
              var rowresult = 0;
              // result is the database after dbprom is done opening
              console.log("  /web/donescrapy before select result=" + result.toString());

              console.error(" r_latestupdattime now =", r_latestupdatetime);
              var test_latestupdatetime = result.each(
                'select firstsubdomaintable.latestupdatetime as latestupdatetime from firstsubdomaintable where firstsubdomaintable.id == ?', 
                [parseInt(jobInfo.get('firstsubdomaintable_id'))],
                 function (err, row) {
                   if (row === undefined) {
                     console.error (" latestupdatetime retrieve err row=undefined");
                   }
                   console.log("  /web/donescrapy  query latesttime 1 err=" + err);
                   console.log("  /web/donescrapy  query latesttime 2 err=" + row.toString());
                   r_latestupdatetime = row.latestupdatetime;
                   jobInfo.set('r_latestupdatetime', r_latestupdatetime);
                 }).then(function(testrowlatestupdate){
                   console.log(" /web/donescrapy  query latesttime 3" + testrowlatestupdate);
                 })
              
              
              //https://github.com/mapbox/node-sqlite3/wiki/API#databaseeachsql-param--callback-complete
              var testrowres1 = result.each('select count(*) as countres from articletable', [],
                function (err, row) {
                  console.log("  /web/donescrapy  4err = " + err);
                  console.log("  /web/donescrapy  4row = " + row.toString());
                  var indval;
                  for (var indname in row) {
                    indval = row[indname];
                    console.log("  /web/donescrapy  4indname=" + indname + ",indval=" + indval);
                  }
                  rowresult = row.countres;
                  finalresult = row.countres;
                  jobInfo.set('totalarticlecount', row.countres);
                  console.log("  /web/donescrapy  4wierd(countres)=rowresult=" + rowresult);
                  return rowresult;
                }).then(function (testrowresult1) {
                  console.log("  /web/donescrapy 3finalresult = " + finalresult);
                  console.log("  /web/donescrapy 3testrowresult1=" + testrowresult1);
                  bodyobj['data']['noofrow'] = finalresult;
                  bodyobj['data']['replyqueuename'] = q.queue;
                  currcorrelationid = Date.now().toString().slice(0,10);
                  bodyobj['data']['correlationid'] = currcorrelationid;
                  bodyobj['data']['latestupdatetime'] = jobInfo.get('r_latestupdatetime').toString();

                  console.log("  /web/donescrapy before sendtoq ")
                  console.log(bodyobj)
                  console.log("  /web/donescrapy before sendtoq ")

                  //send the request to rabbitmq server to get  article id
                  ch.sendToQueue('wait_assign_articleid_q',
                    new Buffer(JSON.stringify(bodyobj)),
                    { correlationId: currcorrelationid, replyTo: q.queue });
                    var worklisttime = Date.now().toString().slice(0,10)                
                    worklist.set(worklistcount.toString(), worklisttime + ",,,," + 
                       JSON.stringify(bodyobj));
                    worklistcount += 1;
              
                });
              return rowresult;
            }).then(function (result1) {
              console.log("    /web/donescrapy 2finalresult = " + finalresult);
              console.log("    /web/donescrapy 2result1=" + result1.toString());
            });
            console.log("   /web/donescrapy 1tresult1 = " + tresultp1);
            console.log("   /web/donescrapy 1finalresult = " + finalresult);
            resolve(testv1);
          });






          /*
          ch.sendToQueue('wait_assign_articleid_q',
            new Buffer(JSON.stringify(bodyobj)),
            { correlationId: corr, replyTo: q.queue });
          */


        });
      });
    });

  console.log("------ /web/donescrapy", testcount)
  res.send('------- /web/donescrapy')

})


app.get('/web/doneassign', function (req, res) {
  testcount += 10000

  // tell rabbitmqserver that we are done scrapy, need to do the
  // assign articleid
  console.log("------ /web/doneassign -----Oh Yeah! done", testcount)

  var amqp = require('amqplib/callback_api');
  //amqp.connect('amqp://ngogongrabbitmq:abcde12345@rabbit-pub-docker:5672/',
  console.log(" /web/doneassign before connect 1")
  console.log(jobInfo.get('rabbitmqserverurl'))
  console.log(" /web/doneassign before connect 2")
  
  if ( (parseInt(jobInfo.get('timestart')) + 7200) < 
    parseInt(Date.now().toString().slice(0,10) ) ) {
    console.error("------ /web/donescrapy overtime ", testcount)
    res.send('------- /web/donescrapy overtime')
    awstaskstatus = "idle";
    jobInfo = new Map();
    jobInfo.set('servername', servername);
    jobInfo.set('server-starttime', serverstarttime);
    jobInfo.set('systemmemorytotalvalue', os.totalmem() );
    jobInfo.set('systemmemoryfreevalue', os.freemem() );


    return
  }
  var worklisttime1 = Date.now().toString().slice(0,10)                
  worklist.set(worklistcount.toString(), worklisttime1 + ",,,," + 
     "doneassign");
  worklistcount += 1;

  amqp.connect(jobInfo.get('rabbitmqserverurl'),
    function (err, conn) {
      if (err) {
        console.log("xxxxxxxx error /web/doneassign connect 1 err=" + err + "xxxxxx");
        return err;
      }
      conn.createChannel(function (err, ch) {
        if (err) {
          console.log("xxxxxxxx error /web/doneassign connect 2  err=" + err + "xxxxxx");
          return err;
        }
        //ch.assertExchange("ngogongrabbitmqexchange", "topic")
        ch.assertQueue('finish_assign_articleid_q' , { durable : false  })
        var bodyobj = {};
        bodyobj['prevkey'] = jobInfo.get('firstsubdomaintable_id');
        bodyobj['key'] = jobInfo.get('firstsubdomaintable_id');
        bodyobj['data'] = mapToObj(jobInfo);
        var currcorrelationid = Date.now().toString().slice(0,10);

        console.log(" /web/doneassign before 3 send")
        console.log(bodyobj)
        console.log(" /web/doneassign before 3 send")
        var worklisttime = Date.now().toString().slice(0,10)                
        worklist.set(worklistcount.toString(), worklisttime + ",,,," + 
           JSON.stringify(bodyobj));
        worklistcount += 1;
  
        ch.sendToQueue('finish_assign_articleid_q',
        new Buffer(JSON.stringify(bodyobj)),
        { correlationId: currcorrelationid  });
        console.log(" /web/doneassign 4")

  
        //start the python scrapy process
        const { exec } = require('child_process');
        var execstr = "cd /usr/src/app/python/gong_01 ; " +
          "/usr/src/app/python/gong_01/aws-selfdestruct.sh " 
          ;
        var worklisttime = Date.now().toString().slice(0,10)  
        worklist.set(worklistcount.toString(), worklisttime + ",,,,," + 
             execstr);
        worklistcount += 1;
  
        awstaskstatus = "selfdestructing";
        exec(execstr, {maxBuffer: 1024 * 10000}, (error, stdout, stderr) => {
          if (error) {
            console.error(`exec error /web/doneassign 1: ${error}`);
            console.error(`exec error /web/doneassign 2 stderr: ${stderr}`);
            console.error(`exec error /web/doneassign 3 stdout: ${stdout}`);
            jobInfo.set("error_errmsg", `errorselfdestruct ${error}`)
            jobInfo.set("error_stderrmsg", `errorselfdestruct ${stderr}`)
            jobInfo.set("error_execstr", `errorselfdestruct ${execstr}`)
            awstaskstatus = "errorselfdestruct"
  
            return;
          }
          //console.log(`/web/doneassign selfdestruct stdout: ${stdout}`);
          console.log(`/web/doneassign selfdestruct stderr: ${stderr}`);
        });
  

      });
    });

  console.log("------ /web/doneassign", testcount)
  res.send('------- /web/doneassign')




})


// curl -d '{"jobid" : "jobid-value",
// "mongodburl" : "mongodburl-val", 
// "firstsubdomaintable_id" : "firstsubdomaintable_id-val", 
// "domaintable_id" : "domaintable_id-val", 
// "categorytable_id" : "categorytable_id-val",
// "latestupdatetime" : "latestupdatetime-val" }' -H "Content-Type: application/json" -X POST http://localhost:3000/web/startscrapy
app.post('/web/startgensim', function (req, res) {
  var bodyresponse = new Map();
  //var bodyresponse = {};
  console.log(" --- /web/startgensim ---- 1 body= ")
  console.log(req.body)
  console.log(" --- /web/startgensim ---- 1.1 body= ")
  if (awstaskstatus == "idle") {
    console.log(" --- /web/startgensim ---- 2 " )
    bodyresponse.set("responsestatus", "willprocessgensim");
    if (req.body.hasOwnProperty("jobid")) {
      console.log(" --- /web/startgensim ---- jobid=" + req.body.jobid);
      console.log(" --- /web/startgensim ---- mongodburl=" + req.body.mongodburl);
      console.log(" --- /web/startgensim ---- categorytable_id=" + req.body.categorytable_id);
      console.log(" --- /web/startgensim ---- rabbitmqserverurl=" + req.body.rabbitmqserverurl);
      console.log(" --- /web/startgensim ---- gensimscript_name=" + req.body.gensimscript_name);
      console.log(" --- /web/startgensim ---- timestart=" + req.body.timestart);
      jobInfo.set('jobid', req.body.jobid);
      jobInfo.set('mongodburl', req.body.mongodburl);
      jobInfo.set('categorytable_id', req.body.categorytable_id);
      jobInfo.set('rabbitmqserverurl', req.body.rabbitmqserverurl);
      jobInfo.set('gensimscript_name', req.body.gensimscript_name);
      jobInfo.set('timestart', req.body.timestart ), 
      awstaskstatus = "busywithgensim";
      console.log(" typeof " + typeof awstaskstatus);

      //start the python scrapy process
      const { exec } = require('child_process');
      var execstr = "cd /usr/src/app/python/gong_01 ; " +
        "/usr/src/app/python/gong_01/" + `${req.body.gensimscript_name} ` +
        ` ${req.body.jobid} ${req.body.mongodburl} ` 
        ;
      var twocat = req.body.categorytable_id.indexOf("-") === -1 ? false : true ;
      if (twocat == true) {
         listoftwocat = req.body.categorytable_id.split("-");
         execstr +=  ` ${listoftwocat[0]} ${listoftwocat[1]} `;
      }
      else {
         execstr += req.body.categorytable_id;
      }
      var worklisttime = Date.now().toString().slice(0,10)  
      worklist.set(worklistcount.toString(), worklisttime + ",,,,," + 
         execstr);
      worklistcount += 1;

      exec(execstr, {maxBuffer: 1024 * 10000}, (error, stdout, stderr) => {
        if (error) {
          console.error(`exec error 21: ${error}`);
          console.error(`exec error 22 stderr: ${stderr}`);
          console.error(`exec error 23 stdout: ${stdout}`);
          jobInfo.set("error_errmsg", `errorstartgensim ${error}`)
          jobInfo.set("error_stderrmsg", `errorstartgensim ${stderr}`)
          jobInfo.set("error_execstr", `errorstartgensim ${execstr}`)
          awstaskstatus = "errorstartgensim"

          return;
        }
        //console.log(`/web/startgensim stdout: ${stdout}`);
        console.log(`/web/startgensim stderr: ${stderr}`);
      });
    console.log(" --- /web/startgensim ---- 3 " )
    

    }
    console.log(" --- /web/startgensim ---- 4 " )
  } else {
    console.log(" --- /web/startgensim ---- 5 " )
    bodyresponse.set("responsestatus", awstaskstatus);
    bodyresponse.set("data", mapToObj(jobInfo))

  }
  testcount += 1000;
  console.log("------ /web/startgensim hello -----Oh Yeah! ", testcount);
  //res.json will set the content type correctly, otherwise, use res.send
  // need to set it up for response
  res.json(mapToObj(bodyresponse));
  console.log("------ /web/startgensim hello -----Oh Yeah! bodyresponse=" + bodyresponse);
  console.log(bodyresponse)
  console.log("------ /web/startgensim hello -----Oh Yeah! bodyresponse=" + bodyresponse);
})


app.get('/web/donegensim', function (req, res) {
  testcount += 10000

  // tell rabbitmqserver that we are done scrapy, need to do the
  // assign articleid
  if (awstaskstatus != "busywithgensim") {
    console.log("------ /web/donegensim -----some thing wrong", testcount)
    var bodyresponse = { "reason" : "it should not be in this state"}
    res.json(bodyresponse);   
    return 
  } else  {
    console.log("------ /web/donegensim -----Oh Yeah! done", testcount)  
    var amqp = require('amqplib/callback_api');
    //amqp.connect('amqp://ngogongrabbitmq:abcde12345@rabbit-pub-docker:5672/',
    console.log(" /web/donegensim before connect 1")
    console.log(jobInfo.get('rabbitmqserverurl'))
    console.log(" /web/donegensim before connect 2")
    
    if ( (parseInt(jobInfo.get('timestart')) + 3400) < 
      parseInt(Date.now().toString().slice(0,10) ) ) {
      console.error("------ /web/donegensim overtime ", testcount)
      res.send('------- /web/donegensim overtime')
      awstaskstatus = "idle";
      jobInfo = new Map();
      jobInfo.set('servername', servername);
      jobInfo.set('server-starttime', serverstarttime);
      jobInfo.set('systemmemorytotalvalue', os.totalmem() );
      jobInfo.set('systemmemoryfreevalue', os.freemem() );

      return
    }
    var worklisttime1 = Date.now().toString().slice(0,10)                
    worklist.set(worklistcount.toString(), worklisttime1 + ",,,," + 
       "donegensim");
    worklistcount += 1;


    amqp.connect(jobInfo.get('rabbitmqserverurl'),
      function (err, conn) {
        if (err) {
          console.log("xxxxxxxx error /web/donegensim connect 1 err=" + err + "xxxxxx");
          return err;
        }
        conn.createChannel(function (err, ch) {
          if (err) {
            console.log("xxxxxxxx error /web/donegensim connect 2  err=" + err + "xxxxxx");
            return err;
          }
          //ch.assertExchange("ngogongrabbitmqexchange", "topic")
          ch.assertQueue('done_gensim_q', { durable : false  } )
          var bodyobj = {};
          bodyobj['prevkey'] = jobInfo.get('categorytable_id');
          bodyobj['key'] = jobInfo.get('categorytable_id');
          bodyobj['data'] = mapToObj(jobInfo);
          var currcorrelationid = Date.now().toString().slice(0,10);
  
          console.log(" /web/donegensim 3")
          console.log(bodyobj)
          console.log(" /web/donegensim 4")
          var worklisttime = Date.now().toString().slice(0,10)                
          worklist.set(worklistcount.toString(), worklisttime + ",,,," + 
             JSON.stringify(bodyobj));
          worklistcount += 1;
  
          ch.sendToQueue('done_gensim_q',
          new Buffer(JSON.stringify(bodyobj)),
          { correlationId: currcorrelationid  });
          awstaskstatus = "idle";
          jobInfo = new Map();
          jobInfo.set('servername', servername);
          jobInfo.set('server-starttime', serverstarttime);
          jobInfo.set('systemmemorytotalvalue', os.totalmem() );
          jobInfo.set('systemmemoryfreevalue', os.freemem() );
          
          console.log(" /web/donegensim 5")
  
        });
      });
    }


  console.log("------ /web/donegensim 6", testcount)
  res.send('------- /web/donegensim')




})



// the following is for testing promise
var message = "";

app.get("/web/testpromise", (req, res) => {

  promise1 = new Promise((resolve, reject) => {
    setTimeout(() => {
      message += "my";
      console.log(" ---- inside promise 1 settimeout=" + message);
      resolve(message);
    }, 20000);
    console.log(" ---- inside promise 1");
  })

  promise2 = new Promise((resolve, reject) => {
    setTimeout(() => {
      message += " first";
      console.log(" ---- inside promise 2 settimeout=" + message);
      resolve(message);
    }, 20000);
    console.log(" ---- inside promise 2");
  })

  promise3 = new Promise((resolve, reject) => {
    setTimeout(() => {
      message += " promise";
      console.log(" ---- inside promise 3 settimeout=" + message);
      const { exec } = require('child_process');
      var teststr1 = "teststr1";
      var teststr2 = 34567;
      var execstr = `/usr/src/app/childprocess.sh ${teststr1} ${teststr2}`
      exec(execstr, (error, stdout, stderr) => {
        if (error) {
          console.error(`exec error: ${error}`);
          return;
        }
        console.log(`stdout: ${stdout}`);
        console.log(`stderr: ${stderr}`);
      });
      console.log(" ---- inside promise 3.1 settimeout=" + message);

      resolve(message);
    }, 20000);
    console.log(" ---- inside promise 3");
  })

  var printResult = (results) => {
    console.log("Results1 = ", results,
      "message = ", message)
  }

  // See the order of promises. Final result will be according to it
  //Promise.all([promise1, promise2, promise3]).then(printResult);
  //Promise.all([promise2, promise1, promise3]).then(printResult);
  Promise.all([promise3]).then(printResult);
  console.log(" the end message=" + message);
  res.send('testpromise  ---- Hello World!')


})


app.get('/web/downloadmongotoaws/:localornot', function (req, res) {
  var bodyresponse = new Map();
  var localornot = req.params.localornot
  //var bodyresponse = {};
  console.log(" --- /web/downloadmongotoaws ---- 1 localornot=" +localornot)
    console.log(" --- /web/downloadmongotoaws ---- 2 " )
    bodyresponse.set("responsestatus", "doingdownloadmongotoaws");

      //start the python scrapy process
      const { exec } = require('child_process');
      var execstr = "cd /usr/src/app/python/gong_01 ; " +
        "/usr/src/app/python/gong_01/aws-downloadmongotoaws.py " + 
        `${localornot} ` ;       


      exec(execstr, {maxBuffer: 1024 * 10000}, (error, stdout, stderr) => {
        if (error) {
          console.error(`exec error 31: ${error}`);
          console.error(`exec error 32 stderr: ${stderr}`);
          console.error(`exec error 33 stdout: ${stdout}`);
          return;
        }
        //console.log(`/web/downloadmongotoaws stdout: ${stdout}`);
        console.log(`/web/downloadmongotoaws stderr: ${stderr}`);
      });
    console.log(" --- /web/downloadmongotoaws ---- 3 " )
  testcount += 1000;
  console.log("------ /web/downloadmongotoaws hello -----Oh Yeah! ", testcount);
  //res.json will set the content type correctly, otherwise, use res.send
  // need to set it up for response
  res.json(mapToObj(bodyresponse));
  console.log("------ /web/downloadmongotoaws hello -----Oh Yeah! bodyresponse=" + bodyresponse);
  console.log(bodyresponse)
  console.log("------ /web/downloadmongotoaws hello -----Oh Yeah! bodyresponse=" + bodyresponse);
})





















app.get('/web/latestupdatetime/:findfirstsubdomain', function (req, res) {
  var bodyresponse = new Map();
  var localornot = req.params.findfirstsubdomain
  //var bodyresponse = {};
  console.log(" --- /web/latestupdatetime ---- 1 localornot=" +findfirstsubdomain)
  console.log(" --- /web/latestupdatetime ---- 2 " )
  bodyresponse.set("responsestatus", "doingdownloadmongotoaws");

      //start the python scrapy process
      const { exec } = require('child_process');
      var execstr = "cd /usr/src/app/python/gong_01 ; " +
        "/usr/src/app/python/gong_01/aws-downloadmongotoaws.py " + 
        `${localornot} ` ;       


      exec(execstr, {maxBuffer: 1024 * 10000}, (error, stdout, stderr) => {
        if (error) {
          console.error(`exec error 31: ${error}`);
          console.error(`exec error 32 stderr: ${stderr}`);
          console.error(`exec error 33 stdout: ${stdout}`);
          return;
        }
        //console.log(`/web/downloadmongotoaws stdout: ${stdout}`);
        console.log(`/web/downloadmongotoaws stderr: ${stderr}`);
      });
    console.log(" --- /web/downloadmongotoaws ---- 3 " )
  testcount += 1000;
  console.log("------ /web/downloadmongotoaws hello -----Oh Yeah! ", testcount);
  //res.json will set the content type correctly, otherwise, use res.send
  // need to set it up for response
  res.json(mapToObj(bodyresponse));
  console.log("------ /web/downloadmongotoaws hello -----Oh Yeah! bodyresponse=" + bodyresponse);
  console.log(bodyresponse)
  console.log("------ /web/downloadmongotoaws hello -----Oh Yeah! bodyresponse=" + bodyresponse);
})




var totalarticleid = 0;
app.get('/web/testsqlite', function (req, res) {
  var finalresult = 999;
  sqlite = require('sqlite');
  const dbPromise = new Promise(function (resolve, reject) {
    const dbprom = sqlite.open('/usr/src/app/python/gong_01/gong.db',
      { Promise });
    var testv1 = "testv1";
    var tresultp1 = dbprom.then(function (result) {
      var rowresult = 0;
      console.log("before select result=" + result.toString());
      var testrowres1 = result.each('select count(*) as countres from articletable', [],
        function (err, row) {
          console.log("    4err = " + err);
          console.log("    4row = " + row.toString());
          var indval;
          for (var indname in row) {
            indval = row[indname];
            console.log("    4indname=" + indname + ",indval=" + indval);
          }
          rowresult = row.countres;
          finalresult = row.countres;
          console.log("    4wierd(countres)=rowresult=" + rowresult);
          return rowresult;
        }).then(function (testrowresult1) {
          console.log("   3finalresult = " + finalresult);
          console.log("   3testrowresult1=" + testrowresult1);
        });
      return rowresult;
    }).then(function (result1) {
      console.log("  2finalresult = " + finalresult);
      console.log("  2result1=" + result1.toString());
    });
    console.log(" 1tresult1 = " + tresultp1);
    console.log(" 1finalresult = " + finalresult);
    resolve(testv1);
  });
  /*
    dbPromise.then(function (response) {
      console.log("0response=" + response);
    })
  */

  /*
  const dbPromise = Promise.resolve().then (
         ()=> sqlite.open('/usr/src/app/python/gong_01/gong.db', 
            { Promise }) ).then( 
              sqlitedb => console.log("resultsqlitedb="+    
              sqlitedb.get( 'select count(*) from articletable')
              
            ));
  */
  console.log(" testsqlite --- dbPromise=" + dbPromise);
  res.send('testsqlite ----Hello World!')
})




app.listen(3000, function () {
  console.log('Example app listening on port 3000!')
})
app.listen(8001, function () {
  console.log('Example app listening on port 8001!')
})
