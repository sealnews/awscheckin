#! /usr/bin/env python3
import sys
import gensim
from gensim import corpora
import time
import json
from datetime import datetime, timedelta,timezone
from gensim import corpora, models, similarities
from collections import defaultdict
from collections import OrderedDict
import re
from gong_01_db import GongAllTable
import os
import operator
from pprint import pprint
import data_helpers
#from oauth2client import tools


nowTime = datetime.now(timezone(timedelta(hours=8)))
print ("start time for gensim = ", nowTime )


import requests
import pymongo
import boto3
import argparse

parser = argparse.ArgumentParser()
parser.add_argument('inputarg', nargs='*')
argument = parser.parse_args()

print ("argument.inputarg = " , argument.inputarg )

jobid = int(argument.inputarg[0])
startjobid = int(argument.inputarg[1])

#dynamodb_client = boto3.client('dynamodb', endpoint_url='http://localhost:8000', region_name='us-east-2')
if jobid == 99999 :
  dynamodb_client = boto3.client('dynamodb',
    aws_secret_access_key='vEItH0g8VC5otwQ2Fy6zwXxpgOu2NnkLjjB854M4',
    aws_access_key_id="AKIAJWZT7VQHKKHY2BTQ",
    endpoint_url='http://localhost:8000', region_name='us-east-2')
else :
  dynamodb_client = boto3.client('dynamodb',
    aws_secret_access_key='vEItH0g8VC5otwQ2Fy6zwXxpgOu2NnkLjjB854M4',
    aws_access_key_id="AKIAJWZT7VQHKKHY2BTQ",
    region_name='us-east-2')

queryresult = dynamodb_client.list_tables()
if ( queryresult['ResponseMetadata']['HTTPStatusCode'] != 200 ) or ( \
     'articlecollection' not in queryresult['TableNames'] ):
   print(" gong_01 assignchildprocess error list_tables httpstatuscode="+
      queryresult['ResponseMetadata']['HTTPStatusCode'] )
   print(" gong_01 aws-gonggensim error list_tables ="+
      queryresult['TableNames'] )
   exit(-1)

#get the data from dynamodb
def deleteAWSItem ( list_items , in_dynamodb_client, startdeljobid ):
  for x in list_items :
    #delete the item in dynamodb
    if int(x['id']['N']) > startdeljobid : 
       in_dynamodb_client.delete_item ( Key={
         'categorytable_id' : {'N' : x['categorytable_id']['N'] } ,
         'id' : { 'N' : x['id']['N'] }  },
         TableName='articlecollection' )
       time.sleep(0.9)
       print ('delete id = ', x['id']['N'])
       continue

from botocore.exceptions import ClientError
RETRY_EXCEPTIONS = ('ProvisionedThroughputExceededException',
                    'ThrottlingException')

def getAWSItems ( finalqueryresult , categorytable_id) :
  endquery = True
  queryresult = {}
  sleep_retry = 1
  while (endquery) :
   try :
    if len(finalqueryresult) == 0 :
      queryresult = dynamodb_client.query( TableName='articlecollection',
        KeyConditionExpression=' id > :X1 AND categorytable_id = :X2 ',
        ExpressionAttributeValues={ ':X1' : { 'N' : '0' }, ':X2' : { "N" : str(categorytable_id)  } })
    else :
      queryresult = dynamodb_client.query( TableName='articlecollection',
        KeyConditionExpression=' id > :X1 AND categorytable_id = :X2 ',
        ExpressionAttributeValues={ ':X1' : { 'N' : '0' }, ':X2' : { "N" : str(categorytable_id) } },
      ExclusiveStartKey=queryresult['LastEvaluatedKey'] )
    if 'Items' in queryresult and len(queryresult['Items']) > 0 :
      finalqueryresult += queryresult['Items']
    else :
      print ("error error , it should have something")
      #exit(-1)
    if 'LastEvaluatedKey' not in queryresult :
      endquery=False
   except ClientError as err  :
    if err.response['Error']['Code'] not in RETRY_EXCEPTIONS:
      raise
    print ("need to sleep for retrieve")
    time.sleep(sleep_retry)
    sleep_retry += 1




awsqueryresult_2 =[]
awsqueryresult_3 =[]
awsqueryresult_5 =[]
awsqueryresult_6 =[]
awsqueryresult_7 =[]
awsqueryresult_8 =[]
#for sport only one category
getAWSItems ( awsqueryresult_2 , 2)
getAWSItems ( awsqueryresult_3 , 3)
getAWSItems ( awsqueryresult_5 , 5)
getAWSItems ( awsqueryresult_6 , 6)
getAWSItems ( awsqueryresult_7 , 7)
getAWSItems ( awsqueryresult_8 , 8)


# a ordereddict contains same category of articles, key is article id number,
# value is a dict which contain all the information
deleteAWSItem ( awsqueryresult_2 + awsqueryresult_3 + 
                 awsqueryresult_5 + awsqueryresult_6 +
                 awsqueryresult_7 + awsqueryresult_8 , 
                 dynamodb_client,
                 startjobid )
print (" gong_01 aws-deletegreaterthan end")

os._exit(0)









