#!/bin/sh

./hournews1.sh
./dailynews.sh




