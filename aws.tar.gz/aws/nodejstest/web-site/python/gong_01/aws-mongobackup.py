#! /usr/bin/env python3

from __future__ import print_function
import httplib2
import os
from collections import OrderedDict

from datetime import datetime, timedelta, timezone, date
from pprint import pprint
from gong_01_db import GongAllTable
import sys
import os

import time
import json
import lxml.html


import requests
import argparse
import pymongo
import boto3

from pymongo.errors import BulkWriteError

parser = argparse.ArgumentParser()
parser.add_argument('inputarg', nargs='*')
argument = parser.parse_args()

print ("argument.inputarg = " , argument.inputarg )

if len(argument.inputarg) == 0 :
  print ("you need either backup or restore " )
  os._exit(0) 

mongodb_client = pymongo.MongoClient("mongodb+srv://normaluser:abcde12345@cluster0-q3gf2.mongodb.net")
#mongodb_client = pymongo.MongoClient(mongodburl)
mongodb_db = mongodb_client.mongodblab
mongodb_articlecollection = mongodb_db.articlecollection
#mongodb_db.create_collection("articlecollectionback")
mongodb_articlecollection_back = mongodb_db.articlecollectionback
if argument.inputarg[0] == 'backup' :
  from_collection = mongodb_articlecollection
  to_collection = mongodb_articlecollection_back
else :
  from_collection = mongodb_articlecollection_back
  to_collection = mongodb_articlecollection


download_mongodbarticlelist = []
# copy data from mongodb to dynamodb because it is new
# original the output of .find is cursor, however,
# when i use += with list, it become a list of dict,
# each dict is one document
download_mongodbarticlelist +=  from_collection.find( \
         { "$or" : [ { 'categorytable_id' : { "$eq" : 2 } },
         { 'categorytable_id' : { "$eq" : 3 } } ] } )

download_mongodbarticlelist +=  from_collection.find( \
         { "$or" : [ { 'categorytable_id' : { "$eq" : 5 } },
         { 'categorytable_id' : { "$eq" : 6 } } ] } )

download_mongodbarticlelist +=  from_collection.find( \
         { 'categorytable_id' : { "$eq" : 7 } } )

download_mongodbarticlelist +=  from_collection.find( \
         { 'categorytable_id' : { "$eq" : 8 } } )

result=0
writetry=True
writetrycount=0
while writetry and writetrycount <4:
  try :
    result = to_collection.remove({})
    result = to_collection.insert_many(
       download_mongodbarticlelist)
    writetry=False
  except BulkWriteError as err :
    print ("mongobackup BulkWriteError as err  1 ")
    print (err.details)
    print ("mongobackup BulkWriteError as err  2 ")
    writetrycount += 1
    time.sleep(10)
    continue

print(" gong_01 mongobackup 2")
if result == 0 or len(download_mongodbarticlelist) != len(result.inserted_ids) :
   print(" gong_01 mongobackup error len does not match")
   exit(-1)



