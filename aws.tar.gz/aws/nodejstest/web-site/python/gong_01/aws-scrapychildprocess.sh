#!/bin/bash

#for i in a,b c,d ; do
#  IFS=",";
#  set $i;
#  echo $1 $2;
#done
echo " ----> in scrapychildprocess.sh.... going to sleep 15 " ",arg1=$1" ", arg2=$2 " ",arg3=$3" ",arg4=$4" ",arg5=$5" ",arg6=$6" 
echo " ----> calling scrapy "
#sleep 10
#curl -d '{"jobid" : "jobid-value", "mongodburl" : "mongodburl-val", "firstsubdomaintable_id" : "firstsubdomaintable_id-val", "domaintable_id" : "domaintable_id-val", "categorytable_id" : "categorytable_id-val"}' -H "Content-Type: application/json" -X POST http://localhost:3000/web/startscrapy

#first kill the scrapy image
#echo "kill -9 -1 " | nc splash-local 9898
#echo "kill -9 -1 " | nc $AWSSPLASHURL 9898

echo " ----> after kill splash-local, going to sleep "
cp gong_aws.db gong.db
sleep 10
echo " ----> after kill splash-local, after sleep, going to call scrapy crawl "

# aws-scrapychildprocess.sh 99 "mongodb+srv://normaluser:abcde12345@cluster0-q3gf2.mongodb.net" 16 14 3 1531186501
# scrapy crawl gong_01 -a firstsubdomain=16 -a domaintorun=hk01 -a newstypetorun=latestnews  -a latestupdatetime=1531186501
scrapy crawl gong_01 -a firstsubdomain=$3 -a domaintorun=$4 -a newstypetorun=$5 -a latestupdatetime=$6 -a awssplashurl=$AWSSPLASHURL

cp -f gong.db gong.$3.db
curl http://localhost:3000/web/donescrapy

echo " ----> done calling curl "

exit 0
