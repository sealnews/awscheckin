
import sqlalchemy
from sqlalchemy.orm import relationship, aliased
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import Column, Integer, String, Text, Table
from sqlalchemy import ForeignKey
from CommonBase import Base
#from SentenceTable import SentenceTable


#Base=declarative_base()


class EntityTable(Base):
  __tablename__ = 'entitytable'

  id=Column(Integer, primary_key=True)
  organization=Column(Text)
  title=Column(Text)
  name=Column(Text)
  nickname=Column(Text)
  previoustitle=Column(Text)
  hasfirebasetable=Column(Integer, default=0)
  checkrelatedcaselist=Column(Text)


#  sentenceT=aliased(SentenceTable)

  activerole_list=relationship( "SentenceTable", 
    foreign_keys="SentenceTable.activeentity_id", 
    back_populates='activeentity_table', 
    cascade="all ,delete, delete-orphan")
  passiverole_list=relationship( "SentenceTable", 
    foreign_keys="SentenceTable.passiveentity_id", 
    back_populates='passiveentity_table', 
    cascade="all, delete, delete-orphan")

  def __repr__(self):
    return "<EntityTable(id='%d', organization='%s', title='%s', name='%s', nickname='%s', previoustitle='%s', hasirebasetable='%d' ,)>" % (self.id, self.organization, self.title, self.name, self.nickname, self.previoustitle, self.hasfirebasetable)

