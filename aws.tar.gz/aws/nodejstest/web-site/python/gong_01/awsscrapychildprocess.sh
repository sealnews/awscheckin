#!/bin/bash

#for i in a,b c,d ; do
#  IFS=",";
#  set $i;
#  echo $1 $2;
#done
echo " ----> in scrapychildprocess.sh.... going to sleep 15 " ",arg1=$1" ", arg2=$2 " ",arg3=$3" ",arg4=$4" ",arg5=$5" ",arg6=$6" 
echo " ----> calling scrapy "
sleep 10
#curl -d '{"jobid" : "jobid-value", "mongodburl" : "mongodburl-val", "firstsubdomaintable_id" : "firstsubdomaintable_id-val", "domaintable_id" : "domaintable_id-val", "categorytable_id" : "categorytable_id-val"}' -H "Content-Type: application/json" -X POST http://localhost:3000/web/startscrapy

curl http://localhost:3000/web/donescrapy

echo " ----> done calling curl "

exit 0
