#! /usr/bin/env python

from __future__ import print_function
import httplib2
import os
from collections import OrderedDict

from datetime import datetime, timedelta, timezone, date
import firebase_admin
from firebase_admin import credentials
from firebase_admin import db
from pprint import pprint
from gong_01_db import GongAllTable

import io
from apiclient import discovery
from apiclient.http import MediaUpload
from apiclient.http import MediaFileUpload
from apiclient.http import MediaIoBaseDownload
from oauth2client import client
from oauth2client import tools
from oauth2client.file import Storage

#here is for tensorflow
import tensorflow as tf
import numpy as np
import os
import time
import datetime
import data_helpers
from text_cnn import TextCNN
from tensorflow.contrib import learn
import csv
from datetime import datetime, timedelta,timezone

import sys

import time
import json
import lxml.html

try:
    import argparse
    parser = argparse.ArgumentParser(parents=[tools.argparser])
    parser.add_argument('--updatecategory', action='store_true')
    parser.add_argument('--updatedomain', action='store_true')
    parser.add_argument('--updatefirstsubdomain', action='store_true')
    parser.add_argument('--sheetapi', action='store_true')
    parser.add_argument('--gdriveupload', action='store_true')
    parser.add_argument('--gdriveuploadwithcurrentdate', action='store_true')
    parser.add_argument('--gdrivedownload', action='store_true')
    parser.add_argument('--updatetable', action='store_true')
    parser.add_argument('--arclatestnoofentry', nargs=1, type=int, default=0 )
    parser.add_argument('--createtable', action='store_true')
    parser.add_argument('--updateentfragtable', action='store_true')
    parser.add_argument('--updatesportfragtable', action='store_true')
    parser.add_argument('--updatefinfragtable', action='store_true')
    parser.add_argument('--updatefinlatestfragtable', action='store_true')
    parser.add_argument('--updatehkfragtable', action='store_true')
    parser.add_argument('--updatetabletwocat', action='store_true')
    parser.add_argument('--checknoofentry', action='store_true')
    parser.add_argument('--updateindtable', action='store_true')
    flags = parser.parse_args()
    
except ImportError:
    flags = None



ENTRYPERSHEET = 33000
SHEETSTARTNAME = "article"
SEPERATENAME = "ZZ"
VALUE_INPUT_OPTION = 'RAW' 
NOOFENTRYPERPAGE =20
NOOFPAGINATION = 6
EMPTYSTRINGVALUE = 'EMPTYSTRINGVALUE'
BATCHUPDATESIZE=5500

CHECKPOINT_DIR = './runs/1503856968/checkpoints'

cred = credentials.Certificate('/media/sf_xubuntu-01-share/tensorflowOrgExamplePython/firebase/friendlychat-d1a66-firebase-adminsdk-eq7ke-c3ae44c287.json' )
default_app = firebase_admin.initialize_app(cred, {
        'databaseURL' : 'https://friendlychat-d1a66.firebaseio.com',
   })

gong=GongAllTable('gong.db')
session=gong.init_all_table()
nowTime= datetime.now(timezone(timedelta(hours=8)))

SCOPES = 'https://www.googleapis.com/auth/spreadsheets'
CLIENT_SECRET_FILE = 'client_secret.json'
APPLICATION_NAME = 'FriendlyCharPythonUpdate'

def get_credentials():
    """Gets valid user credentials from storage.

    If nothing has been stored, or if the stored credentials are invalid,
    the OAuth2 flow is completed to obtain the new credentials.

    Returns:
        Credentials, the obtained credential.
    """
    credential_dir = os.path.join('/media', 'sf_xubuntu-01-share/tensorflowOrgExamplePython/scrapy-tutorial/gong_01/credentials-ngogong')
    if not os.path.exists(credential_dir):
        os.makedirs(credential_dir)
    credential_path = os.path.join(credential_dir,
    #                               'client_secret.json')
                                   'sheets.googleapis.com-python-quickstart.json')

    #home_dir = os.path.expanduser('~')
    #credential_dir = os.path.join(home_dir, '.credentials')
    #if not os.path.exists(credential_dir):
    #    os.makedirs(credential_dir)
    #credential_path = os.path.join(credential_dir,
    #                               'sheets.googleapis.com-python-quickstart.json')


    print ('credential_path 1 = ', credential_path)
    store = Storage(credential_path)
    print ('credential_path 2 = ', credential_path)
    credentials = store.get()
    print ('credential_path 3 = ', credential_path)

    if not credentials or credentials.invalid:
        print ('credential_path 4 = ', credential_path)
        flow = client.flow_from_clientsecrets(CLIENT_SECRET_FILE, SCOPES)
        print ('credential_path 5 = ', credential_path)
        flow.user_agent = APPLICATION_NAME

        #if flags:
        credentials = tools.run_flow(flow, store, flags)
        #else: # Needed only for compatibility with Python 2.6
        #    credentials = tools.run(flow, store)

        print('Storing credentials to ' + credential_path)

    return credentials



def get_credentials_gdrive ():
    """Gets valid user credentials from storage.

    If nothing has been stored, or if the stored credentials are invalid,
    the OAuth2 flow is completed to obtain the new credentials.

    Returns:
        Credentials, the obtained credential.
    """
    SCOPES = 'https://www.googleapis.com/auth/drive'
    CLIENT_SECRET_FILE = 'client_secret.json'
    APPLICATION_NAME = 'FriendlyCharPythonUpdate_GDRIVE'

    credential_dir = os.path.join('/media', 'sf_xubuntu-01-share/tensorflowOrgExamplePython/scrapy-tutorial/gong_01/credentials')
    if not os.path.exists(credential_dir):
        os.makedirs(credential_dir)
    credential_path = os.path.join(credential_dir,
    #                               'client_secret.json')
                                   'gdrive.googleapis.com-python-quickstart.json')

    #home_dir = os.path.expanduser('~')
    #credential_dir = os.path.join(home_dir, '.credentials')
    #if not os.path.exists(credential_dir):
    #    os.makedirs(credential_dir)
    #credential_path = os.path.join(credential_dir,
    #                               'sheets.googleapis.com-python-quickstart.json')


    print ('credential_path 1 = ', credential_path)
    store = Storage(credential_path)
    print ('credential_path 2 = ', credential_path)
    credentials = store.get()
    print ('credential_path 3 = ', credential_path)

    if not credentials or credentials.invalid:
        print ('credential_path 4 = ', credential_path)
        flow = client.flow_from_clientsecrets(CLIENT_SECRET_FILE, SCOPES)
        print ('credential_path 5 = ', credential_path)
        flow.user_agent = APPLICATION_NAME

        #if flags:
        credentials = tools.run_flow(flow, store, flags)
        #else: # Needed only for compatibility with Python 2.6
        #    credentials = tools.run(flow, store)

        print('Storing credentials to ' + credential_path)

    return credentials








def updatecategorytable () :
  categoryresult = gong.getCategoryDict()
  noofentry = len(categoryresult)
  categorytable_ref = db.reference().child('categorytable')
  result = categorytable_ref.get()
  if result is None :
    #create the table
    print (' noofentry = ', noofentry)
    categorytable_ref.set({ 'noofentry' : noofentry , 'lastupdatetime' : int(nowTime.timestamp())})
    categorytableNoofEntry_ref = categorytable_ref.child('noofentry')
    categorytableLastUpdate_ref = categorytable_ref.child('lastupdatetime')
    categorytableEntry_ref = categorytable_ref.child('entry')
    for entry in categoryresult :
      print (' entry= ' , entry)
      categorytableEntry_ref.child(str(entry.id)).set({ 'id' : entry.id , 'chi_name' : entry.chi_name , 'eng_name' : entry.eng_name } )
 
  else :
    categorytableRntry_ref = categorytable_ref.child('entry')
    categorytableNoofEntry_ref = categorytable_ref.child('noofentry')
    categorytableLastUpdate_ref = categorytable_ref.child('lastupdatetime')
    if ( noofentry != categorytableNoofEntry_ref.get() ) or ( int(nowTime.timestamp())  < categorytableLastUpdate_ref.get() ) :
      print(' need to update ')
      categorytable_ref.update({ 'noofentry' : noofentry , 'lastupdatetime' : int(nowTime.timestamp())})
      categorytableEntry_ref = categorytable_ref.child('entry')
      for entry in categoryresult :
        print (' entry= ' , entry)
        if categorytable_ref.child('entry'+'/'+str(entry.id)).get() is None :
          categorytableEntry_ref.child(str(entry.id)).set({ 'id' : entry.id , 'chi_name' : entry.chi_name , 'eng_name' : entry.eng_name } )
        else :
          categorytableEntry_ref.child(str(entry.id)).update({ 'id' : entry.id , 'chi_name' : entry.chi_name , 'eng_name' : entry.eng_name } )

    else :
      print(' nothing to update in categorytable ')
  


def updatedomaintable () :
  domainresult = gong.getDomainDict()
  noofentry = len(domainresult)
  domaintable_ref = db.reference().child('domaintable')
  result = domaintable_ref.get()
  if result is None :
    #create the table
    print (' noofentry = ', noofentry)
    domaintable_ref.set({ 'noofentry' : noofentry , 'lastupdatetime' : int(nowTime.timestamp())})
    domaintableNoofEntry_ref = domaintable_ref.child('noofentry')
    domaintableLastUpdate_ref = domaintable_ref.child('lastupdatetime')
    domaintableEntry_ref = domaintable_ref.child('entry')
    for entry in domainresult :
      print (' entry= ' , entry)
      domaintableEntry_ref.child(str(entry.id)).set({ 'id' : entry.id , 'baseurl' : entry.baseurl , 'chi_name' : entry.chi_name , 'eng_name' : entry.eng_name } )
  else :
    domaintableRntry_ref = domaintable_ref.child('entry')
    domaintableNoofEntry_ref = domaintable_ref.child('noofentry')
    domaintableLastUpdate_ref = domaintable_ref.child('lastupdatetime')
    if ( noofentry != domaintableNoofEntry_ref.get() ) or ( int(nowTime.timestamp())  < domaintableLastUpdate_ref.get() ) :
      print(' need to update ')
      domaintable_ref.update({ 'noofentry' : noofentry , 'lastupdatetime' : int(nowTime.timestamp())})
      domaintableEntry_ref = domaintable_ref.child('entry')
      for entry in domainresult :
        print (' entry= ' , entry)
        if domaintable_ref.child('entry'+'/'+str(entry.id)).get() is None :
          domaintableEntry_ref.child(str(entry.id)).set({ 'id' : entry.id , 'baseurl' : entry.baseurl , 'chi_name' : entry.chi_name , 'eng_name' : entry.eng_name } )
        else :
          domaintableEntry_ref.child(str(entry.id)).update({ 'id' : entry.id ,  'baseurl' : entry.baseurl , 'chi_name' : entry.chi_name , 'eng_name' : entry.eng_name } )
    else :
      print(' nothing to update in domaintable ')
  

def updatefirstsubdomaintable () :
  firstsubdomainresult = gong.getFirstSubDomainDict()
  noofentry = len(firstsubdomainresult)
  firstsubdomaintable_ref = db.reference().child('firstsubdomaintable')
  result = firstsubdomaintable_ref.get()
  if result is None :
    #create the table
    print (' noofentry = ', noofentry)
    firstsubdomaintable_ref.set({ 'noofentry' : noofentry , 'lastupdatetime' : int(nowTime.timestamp())})
    firstsubdomaintableNoofEntry_ref = firstsubdomaintable_ref.child('noofentry')
    firstsubdomaintableLastUpdate_ref = firstsubdomaintable_ref.child('lastupdatetime')
    firstsubdomaintableEntry_ref = firstsubdomaintable_ref.child('entry')
    for entry in firstsubdomainresult :
      print (' entry= ' , entry)
      firstsubdomaintableEntry_ref.child(str(entry.id)).set({ 'id' : entry.id ,
            'domaintable_id' : entry.domaintable_id, 
            'categorytable_id' : entry.categorytable_id, 
            'latestupdatetime' : entry.latestupdatetime.replace(tzinfo=timezone(timedelta(hours=8))).timestamp(), 
            'latestupdateurl' : entry.latestupdateurl ,
            'sourceiconurl' : entry.sourceiconurl 
      } )
  else :
    firstsubdomaintableRntry_ref = firstsubdomaintable_ref.child('entry')
    firstsubdomaintableNoofEntry_ref = firstsubdomaintable_ref.child('noofentry')
    firstsubdomaintableLastUpdate_ref = firstsubdomaintable_ref.child('lastupdatetime')
    if ( noofentry != firstsubdomaintableNoofEntry_ref.get() ) or ( int(nowTime.timestamp())  < firstsubdomaintableLastUpdate_ref.get() ) :
      print(' need to update ')
      firstsubdomaintable_ref.update({ 'noofentry' : noofentry , 'lastupdatetime' : int(nowTime.timestamp())})
      firstsubdomaintableEntry_ref = firstsubdomaintable_ref.child('entry')
      for entry in firstsubdomainresult :
        print (' entry= ' , entry)
        if firstsubdomaintable_ref.child('entry'+'/'+str(entry.id)).get() is None :
          firstsubdomaintableEntry_ref.child(str(entry.id)).set({ 'id' : entry.id ,
            'domaintable_id' : entry.domaintable_id, 
            'categorytable_id' : entry.categorytable_id, 
            'latestupdatetime' : entry.latestupdatetime.replace(tzinfo=timezone(timedelta(hours=8))).timestamp(), 
            'latestupdateurl' : entry.latestupdateurl ,
            'sourceiconurl' : entry.sourceiconurl 
          } )
        else :
          firstsubdomaintableEntry_ref.child(str(entry.id)).update({ 'id' : entry.id ,
            'domaintable_id' : entry.domaintable_id, 
            'categorytable_id' : entry.categorytable_id, 
            'latestupdatetime' : entry.latestupdatetime.replace(tzinfo=timezone(timedelta(hours=8))).timestamp(), 
            'latestupdateurl' : entry.latestupdateurl ,
            'sourceiconurl' : entry.sourceiconurl 
          } )

    else :
      print(' nothing to update in firstsubdomaintable ')
  


def updatearticletable () :
  articleresult = gong.getArticleDict()
  noofentry = len(articleresult)
  articletable_ref = db.reference().child('articletable')
  result = articletable_ref.get()
  if result is None :
    #create the table
    print (' noofentry = ', noofentry)
    articletable_ref.set({ 'noofentry' : noofentry , 'lastupdatetime' : int(nowTime.timestamp())})
    articletableNoofEntry_ref = articletable_ref.child('noofentry')
    articletableLastUpdate_ref = articletable_ref.child('lastupdatetime')
    articletableEntry_ref = articletable_ref.child('entry')
    #testcount=0
    for entry in articleresult :
      #testcount += 1
      #if testcount >10 :
      #  break
      #print (' entry= ' , entry)
      articletableEntry_ref.child(str(entry.id)).set({ 'id' : entry.id ,
            'firstsubdomaintable_id' : entry.firstsubdomaintable_id, 
            'finalurl' : entry.finalurl, 
            'timestampondoc' : entry.timestampondoc.replace(tzinfo=timezone(timedelta(hours=8))).timestamp(), 
            'timestamponretrieve' : entry.timestamponretrieve.replace(tzinfo=timezone(timedelta(hours=8))).timestamp(), 
            'title' : entry.title ,
            'content' : entry.content ,
            'imageurl' : entry.imageurl if ((entry.imageurl is not None) and ( len(entry.imageurl) > 0) ) else EMPTYSTRINGVALUE ,
            'similaritieslist' : entry.similaritieslist if (( entry.similaritieslist is not None) and ( len(entry.similaritieslist) > 0 ) ) else EMPTYSTRINGVALUE,
            'similaritiescount' : entry.similaritiescount if (entry.similaritiescount is not None) else 0 
      } )
  else :
    articletableRntry_ref = articletable_ref.child('entry')
    articletableNoofEntry_ref = articletable_ref.child('noofentry')
    articletableLastUpdate_ref = articletable_ref.child('lastupdatetime')
    if ( noofentry > articletableNoofEntry_ref.get() ) :
      #print(' need to update ')
      articletable_ref.update({ 'noofentry' : noofentry , 'lastupdatetime' : int(nowTime.timestamp())})
      articletableEntry_ref = articletable_ref.child('entry')
      for entry in articleresult :
        #print (' entry= ' , entry)
        if articletable_ref.child('entry'+'/'+str(entry.id)).get() is None :
          #new entry
          articletableEntry_ref.child(str(entry.id)).set({ 'id' : entry.id ,
            'firstsubdomaintable_id' : entry.firstsubdomaintable_id, 
            'finalurl' : entry.finalurl, 
            'timestampondoc' : entry.timestampondoc.replace(tzinfo=timezone(timedelta(hours=8))).timestamp(), 
            'timestamponretrieve' : entry.timestamponretrieve.replace(tzinfo=timezone(timedelta(hours=8))).timestamp(), 
            'title' : entry.title ,
            'content' : entry.content ,
            'imageurl' : entry.imageurl if ((entry.imageurl is not None) and ( len(entry.imageurl) > 0) ) else EMPTYSTRINGVALUE ,
            'similaritieslist' : entry.similaritieslist if (( entry.similaritieslist is not None) and ( len(entry.similaritieslist) > 0 ) ) else EMPTYSTRINGVALUE,
            'similaritiescount' : entry.similaritiescount if (entry.similaritiescount is not None) else 0 
          } )
        elif entry.updatetofirebase == 1  :
          #update entry
          articletableEntry_ref.child(str(entry.id)).update({ 'id' : entry.id ,
            'firstsubdomaintable_id' : entry.firstsubdomaintable_id, 
            'finalurl' : entry.finalurl, 
            'timestampondoc' : entry.timestampondoc.replace(tzinfo=timezone(timedelta(hours=8))).timestamp(), 
            'timestamponretrieve' : entry.timestamponretrieve.replace(tzinfo=timezone(timedelta(hours=8))).timestamp(), 
            'title' : entry.title ,
            'content' : entry.content ,
            'imageurl' : entry.imageurl if ((entry.imageurl is not None) and ( len(entry.imageurl) > 0) ) else EMPTYSTRINGVALUE ,
            'similaritieslist' : entry.similaritieslist if (( entry.similaritieslist is not None) and ( len(entry.similaritieslist) > 0 ) ) else EMPTYSTRINGVALUE,
            'similaritiescount' : entry.similaritiescount if (entry.similaritiescount is not None) else 0 
          } )

    else :
      print(' nothing to update in articletable ')
  


def updatelatestnewstable () :
  articleresult = gong.getArticleDict()
  firstsubdomainresult = gong.getFirstSubDomainDict()
  noofentry = 0
  latestnewstable_ref = db.reference().child('latestnewstable')
  result = latestnewstable_ref.get()
  if result is None :
    
    #create the table
    print (' noofentry = ', noofentry)
    latestnewstable_ref.update({ 'lastupdatetime' : int(nowTime.timestamp())})
    latestnewstableLastUpdate_ref = latestnewstable_ref.child('lastupdatetime')
    latestnewstableEntry_ref = latestnewstable_ref.child('entry')
    #testcount=0
    print (' articleresult length = ', len(articleresult))
    articleresult.reverse()
    testcount =0
    for entry in articleresult :
      testcount += 1
      if testcount >200 :
        break
      #print (' entry= ' , entry)
      print ('--------- testcount= ' , testcount)
      print ('--------- categorytable_id= ' , firstsubdomainresult[entry.firstsubdomaintable_id - 1].categorytable_id  )
      print ('--------- entry.firstsubdomaintable_id= ' , entry.firstsubdomaintable_id  )
      print ('--------- entry.id= ' , entry.id  )
      if (firstsubdomainresult[entry.firstsubdomaintable_id - 1].categorytable_id == 3) :
        noofentry += 1
        print (' ========================= noofentry = ', noofentry)
        latestnewstableNoofEntry_ref = latestnewstable_ref.child('noofentry')
        latestnewstable_ref.update({ 'noofentry' : noofentry })
        latestnewsdatestamp = entry.timestampondoc.replace(hour=0,minute=0,second=0,microsecond=0).timestamp()  
        latestnewstableEntry_ref.child(str(int(latestnewsdatestamp))) \
          .child("+".join([str(int(entry.timestampondoc.replace(tzinfo=timezone(timedelta(hours=8))).timestamp())), entry.id]))\
          .update({ 'id' : entry.id ,
            'firstsubdomaintable_id' : entry.firstsubdomaintable_id, 
            'finalurl' : entry.finalurl, 
            'title' : entry.title ,
            'imageurl' : entry.imageurl if ((entry.imageurl is not None) and ( len(entry.imageurl) > 0) ) else EMPTYSTRINGVALUE ,
            'similaritiescount' : entry.similaritiescount if (entry.similaritiescount is not None) else 0 
          } )
        if entry.similaritiescount > 0 :
          for similarentryid in entry.similaritieslist.strip().split() :
            similarentry = gong.getIndArticleEntry(similarentryid)
            latestnewstableEntry_ref.child(str(int(latestnewsdatestamp))) \
              .child(".".join([str(int(entry.timestampondoc.replace(tzinfo=timezone(timedelta(hours=8))).timestamp())), entry.id ]))\
              .child("entry").child(".".join([str(int(similarentry.timestampondoc.replace(tzinfo=timezone(timedelta(hours=8))).timestamp())), similarentry.id]))\
              .update({ 'id' : similarentry.id ,
                     'firstsubdomaintable_id' : similarentry.firstsubdomaintable_id, 
                     'finalurl' : similarentry.finalurl, 
                     'title' : similarentry.title ,
                     'imageurl' : similarentry.imageurl if ((similarentry.imageurl is not None) and ( len(similarentry.imageurl) > 0) ) else EMPTYSTRINGVALUE ,
                } )




def updatelatestnewstableTwo () :
  articleresult = gong.getArticleDict()
  firstsubdomainresult = gong.getFirstSubDomainDict()
  noofentry = 0
  latestnewstable_ref = db.reference().child('latestnewstable')
  result = latestnewstable_ref.get()
  if result is not None :
    
    #create the table
    print (' noofentry = ', noofentry)
    #testcount=0
    print (' articleresult length = ', len(articleresult))
    articleresult.reverse()
    testcount =0
    noofentryperpage =20
    noofpagination = 6
    startpagerange = 1
    stoppagerange = noofentryperpage
    for entry in articleresult :
      testcount += 1
      if testcount >200 :
        break
      #print (' entry= ' , entry)
      print ('--------- testcount= ' , testcount)
      print ('--------- categorytable_id= ' , firstsubdomainresult[entry.firstsubdomaintable_id - 1].categorytable_id  )
      print ('--------- entry.firstsubdomaintable_id= ' , entry.firstsubdomaintable_id  )
      print ('--------- entry.id= ' , entry.id  )
      if (firstsubdomainresult[entry.firstsubdomaintable_id - 1].categorytable_id == 3) :
        noofentry += 1
        print (' ========================= noofentry = ', noofentry)




        #paginationumber start from 0
        latestnewspagination_ref = latestnewstable_ref.child("pagination")
        paginationnumber = int((noofentry-1) / noofentryperpage) 
        sectionname = str(int(startpagerange + (paginationnumber * noofentryperpage)) ) + \
                      "to" + \
                      str(int(stoppagerange + (paginationnumber * noofentryperpage)) )
        latestnewspaginationsec_ref = latestnewspagination_ref.child(sectionname)
        latestnewspaginationsec_ref.update({ "noofentry" : ((noofentry-1)  % noofentryperpage ) +1  })
        latestnewspaginationsec_ref.update({ 'lastupdatetime' : int(nowTime.timestamp())})
        paginationsecentry_ref = latestnewspaginationsec_ref.child("entry")
        paginationsecentry_ref.child('Z'.join([str(int(entry.timestampondoc.replace(tzinfo=timezone(timedelta(hours=8))).timestamp())), str(entry.id).zfill(10) ]))\
          .update({ 'id' : entry.id ,
            'firstsubdomaintable_id' : entry.firstsubdomaintable_id, 
            'finalurl' : entry.finalurl, 
            'title' : entry.title ,
            'imageurl' : entry.imageurl if ((entry.imageurl is not None) and ( len(entry.imageurl) > 0) ) else EMPTYSTRINGVALUE ,
            'similaritiescount' : entry.similaritiescount if (entry.similaritiescount is not None) else 0 
          } )
        if entry.similaritiescount > 0 :
          for similarentryid in entry.similaritieslist.strip().split() :
            similarentry = gong.getIndArticleEntry(similarentryid)
            paginationsecentry_ref.child('Z'.join([str(int(entry.timestampondoc.replace(tzinfo=timezone(timedelta(hours=8))).timestamp())), str(entry.id).zfill(10) ]))\
              .child("entry").child('Z'.join([str(int(similarentry.timestampondoc.replace(tzinfo=timezone(timedelta(hours=8))).timestamp())), str(similarentry.id).zfill(10) ]))\
              .update({ 'id' : similarentry.id ,
                     'firstsubdomaintable_id' : similarentry.firstsubdomaintable_id, 
                     'finalurl' : similarentry.finalurl, 
                     'title' : similarentry.title ,
                     'imageurl' : similarentry.imageurl if ((similarentry.imageurl is not None) and ( len(similarentry.imageurl) > 0) ) else EMPTYSTRINGVALUE ,
                } )




        #archive  0
        latestnewsarchive_ref = latestnewstable_ref.child("archive")
        latestnewsarchive_ref.update({ 'lastupdatetime' : int(nowTime.timestamp())})
        latestnewsarchive_ref.update({ 'noofentry' : noofentry })


        latestnewsarchiveentry_ref = latestnewsarchive_ref.child("entry")
        latestnewsarchiveentry_ref.child('Z'.join([str(int(entry.timestampondoc.replace(tzinfo=timezone(timedelta(hours=8))).timestamp())), str(entry.id).zfill(10) ]))\
          .update({ 
            'firstsubdomaintable_id' : entry.firstsubdomaintable_id, 
            'title' : entry.title ,
            'similaritiescount' : entry.similaritiescount if (entry.similaritiescount is not None) else 0 
          } )
        if entry.similaritiescount > 0 :
          for similarentryid in entry.similaritieslist.strip().split() :
            similarentry = gong.getIndArticleEntry(similarentryid)
            latestnewsarchiveentry_ref.child('Z'.join([str(int(entry.timestampondoc.replace(tzinfo=timezone(timedelta(hours=8))).timestamp())), str(entry.id).zfill(10) ]))\
              .child("entry").child('Z'.join([str(int(similarentry.timestampondoc.replace(tzinfo=timezone(timedelta(hours=8))).timestamp())), str(similarentry.id).zfill(10) ]))\
              .update({ 
                     'firstsubdomaintable_id' : similarentry.firstsubdomaintable_id, 
                     'title' : similarentry.title ,
                } )



def updatearticlelookuptable () :
  articlelookuptable_ref = db.reference().child('articlelookuptable')
  #result = domaintable_ref.get()
  result = 'hello'
  #create the table
  articlelookuptable_ref.update({ 'noofentry' : 0 , 'lastupdatetime' : int(nowTime.timestamp())})


#session.query(hello).filter(articletable.id.in_([ f.id for f in friends ] ).all

def siftOlderArticle( fulllistarticle , rangeTime=None) :
  siftResultList = [] 
  if rangeTime is None:
    #just sift thur the list for now
    for index, indArticle in enumerate(fulllistarticle) :
      if ( hasattr(indArticle, 'sithout')) or  \
         ( indArticle.similaritiescount is None) or \
         ( indArticle.similaritiescount == 0) or \
         ( index+1 == len(fulllistarticle) ) :
        #print ("does not need to sift indArticle.id=",indArticle.id)
        continue
              
      #print (" need to sift indArticle.id=",indArticle.id, 
      #      ",similaritiescount=", indArticle.similaritiescount)
      for checkArticle in fulllistarticle[index+1:] :
        if str(checkArticle.id) in indArticle.similaritieslist.strip().split() :
          checkArticle.sithout = True      
          
    for indArticle in fulllistarticle :
      if hasattr(indArticle, 'sithout') :
        continue
      siftResultList.append(indArticle)

    print ("len(siftresultlist)=",len(siftResultList),
           ", len(fulllistarticle)=", len(fulllistarticle))
    return siftResultList




def downloadgongdbAtGDrive () :
    credentials = get_credentials_gdrive()
    http = credentials.authorize(httplib2.Http())
    service = discovery.build('drive', 'v3', http=http)
    gongdb_fileid = '0B94TCc20s2zmUGx1WkFGbnN6TWc'
    request =  service.files().get_media(fileId=gongdb_fileid)
    #fh = io.BytesIO()
    fh = io.FileIO('gong.db','wb')
    downloader = MediaIoBaseDownload ( fh, request)
    done = False
    while done is False :
       status, done = downloader.next_chunk()
       print ("Download %d%%." % int(status.progress() * 100))


def updategongdbAtGDrive () :
    credentials = get_credentials_gdrive()
    http = credentials.authorize(httplib2.Http())
    service = discovery.build('drive', 'v3', http=http)
    file_metadata = {'name': 'gong.db'}
    media = MediaFileUpload('gong.db',
                        mimetype='application/x-sqlite3')
    gongdb_fileid = '0B94TCc20s2zmUGx1WkFGbnN6TWc'
    file =  service.files().update(fileId=gongdb_fileid,
                                    body=file_metadata,
                                    media_body=media,
                                    fields='id').execute()
    print ('File ID: %s' % file.get('id'))

def creategongdbAtGDrive () :
    credentials = get_credentials_gdrive()
    http = credentials.authorize(httplib2.Http())
    service = discovery.build('drive', 'v3', http=http)
    file_metadata = {'name': 'gong.db'}
    media = MediaFileUpload('gong.db',
                        mimetype='application/x-sqlite3')
    file =  service.files().create(body=file_metadata,
                                    media_body=media,
                                    fields='id').execute()
    print ('File ID: %s' % file.get('id'))


def creategongdbAtGDrivewithcurrentdate () :
    credentials = get_credentials_gdrive()
    http = credentials.authorize(httplib2.Http())
    service = discovery.build('drive', 'v3', http=http)
    nowTime = datetime.now(timezone(timedelta(hours=8)))
    namestr = 'gong.db' + '.' + \
              str(nowTime.year) + '.' + \
              str(nowTime.month) + '.' + \
              str(nowTime.day) + '.' + \
              str(nowTime.hour) + '.' + \
              str(nowTime.minute) 
    file_metadata = {'name': namestr }
    media = MediaFileUpload('gong.db',
                        mimetype='application/x-sqlite3')
    file =  service.files().create(body=file_metadata,
                                    media_body=media,
                                    fields='id').execute()
    print ('File ID: %s' % file.get('id'))


def listAtGDrive () :
    credentials = get_credentials_gdrive()
    http = credentials.authorize(httplib2.Http())
    service = discovery.build('drive', 'v3', http=http)

    results = service.files().list(
        pageSize=100,fields="nextPageToken, files(id, name)").execute()
    items = results.get('files', [])
    if not items:
        print('No files found.')
    else:
        print('Files:')
        for item in items:
            print('{0} ({1})'.format(item['name'], item['id']))





def getSheetEntries(tableName, archiveName, numToRetrieve ) :
  class ArticleInfo(object):
    pass


  #first get how many 
  table_ref = db.reference().child(tableName)
  tableNoofEntry_ref = table_ref.child(archiveName).child('noofentry')
  tableentry_ref = table_ref.child(archiveName).child('entry')
  noofentry = tableNoofEntry_ref.get()
  remainNumToRetrieve = numToRetrieve

  #total_articlelisttostore = len(articlelisttostore) + noofentry #how many entry will add

  if ( numToRetrieve > 0 ) :
    credentials = get_credentials()
    http = credentials.authorize(httplib2.Http())
    discoveryUrl = ('https://sheets.googleapis.com/$discovery/rest?'
                    'version=v4')
    service = discovery.build('sheets', 'v4', http=http,
                              discoveryServiceUrl=discoveryUrl)

    #first find which sheet should start update  
    startsheetid = 1+ (int(noofentry/ENTRYPERSHEET) * ENTRYPERSHEET) 
    endsheetid = ENTRYPERSHEET + (int(noofentry/ENTRYPERSHEET) * ENTRYPERSHEET) 
    sheetname = str(int(startsheetid)).zfill(10) + SEPERATENAME + str(int(endsheetid)).zfill(10)
    lookupsheetID = tableentry_ref.child(sheetname.strip()).get()
    currententryidPos = noofentry #point to the element has just used
    currentSheetPos = int( currententryidPos % ENTRYPERSHEET) #point to the element is going to use
    updatelistPos =0 #point to the element is going to use
    print ('begin -> startsheetid =',startsheetid,',endsheetid=',
            endsheetid,',sheetname=',sheetname,
            'lookupsheetID=',lookupsheetID,
            'currententryidPos=',currententryidPos,
            'currentSheetPos=',currentSheetPos,
            'updatelistPos=',updatelistPos,
            )
   
    #start the work
    #result = gong.getArticleTableRange(0,4659)
    #result = gong.getArticleTableRange(noofentry)
    #result = articlelisttostore
    resultList = []
    while remainNumToRetrieve > 0 :
      if remainNumToRetrieve <= currentSheetPos :
        #this is last sheet
        read_range_name = 'Sheet1!A' +  \
          str(1 + currentSheetPos - remainNumToRetrieve) + \
          ':H' + \
          str( currentSheetPos )
        result = service.spreadsheets().values().get(
                    spreadsheetId=lookupsheetID, 
                    range=read_range_name
                    ).execute()
        values = result.get('values', [])

        if not values:
          print (" ----> ????? remainNumToRetrieve <= currentSheetPos no data found ???? ")
        else :
          values.reverse() 
          for row in values:
            entry = ArticleInfo()
            entry.id = int(row[0])
            entry.firstsubdomaintable_id= int(row[1])
            entry.finalurl= row[2]
            entry.imageurl= row[3]
            entry.similaritiescount= int(row[4])
            entry.timestampondoc= datetime.fromtimestamp(int(row[5])).replace(tzinfo=timezone(timedelta(hours=8)))
            entry.title= row[6]
            entry.entryjsonStr = row[7]
            oneentry = gong.getIndArticleEntry(entry.id)
            entry.similaritieslist = oneentry.similaritieslist
            resultList.append(entry)
        print ( "remainNumToRetrieve <= currentSheetPos len(resultlist)=",len(resultList))
        break           
      elif (remainNumToRetrieve >= currentSheetPos) :
        read_range_name = 'Sheet1!A' +  \
          str(1) + \
          ':H' + \
          str( currentSheetPos )
        result = service.spreadsheets().values().get(
                    spreadsheetId=lookupsheetID, 
                    range=read_range_name
                    ).execute()
        values = result.get('values', [])

        if not values:
          print (" ----> ????? remainNumToRetrieve > currentSheetPos no data found ???? ")
        else :
          values.reverse() 
          for row in values:
            entry = ArticleInfo()
            entry.id = int(row[0])
            entry.firstsubdomaintable_id= int(row[1])
            entry.finalurl= row[2]
            entry.imageurl= row[3]
            entry.similaritiescount= int(row[4])
            entry.timestampondoc= datetime.fromtimestamp(int(row[5])).replace(tzinfo=timezone(timedelta(hours=8)))
            entry.title= row[6]
            entry.entryjsonStr = row[7]
            oneentry = gong.getIndArticleEntry(entry.id)
            entry.similaritieslist = oneentry.similaritieslist
            resultList.append(entry)
        remainNumToRetrieve -= currentSheetPos
        
        print ( "remainNumToRetrieve <= currentSheetPos len(resultlist)=",len(resultList))
        break           
      else : 
        print ('xxxxxx  ->  else problem remainNumToRetrieve > 0 ')
    return resultList 





   

def updateSheetArchivetable (tableName, archiveName, articlelisttostore) :

  print ("updateSheetArchivetable tableName,=",tableName,
      ",archiveName=",archiveName,
      ",len(articlelisttostore)=", len(articlelisttostore) )
  #first get how many 
  table_ref = db.reference().child(tableName)
  tableNoofEntry_ref = table_ref.child(archiveName).child('noofentry')
  tableentry_ref = table_ref.child(archiveName).child('entry')
  noofentry = tableNoofEntry_ref.get()
  total_articlelisttostore = len(articlelisttostore) + noofentry #how many entry will add
  print ("updateSheetArchivetable total_articlelisttostore=",
     total_articlelisttostore )
  if ( len(articlelisttostore) > 0 ) :
    credentials = get_credentials()
    http = credentials.authorize(httplib2.Http())
    discoveryUrl = ('https://sheets.googleapis.com/$discovery/rest?'
                    'version=v4')
    service = discovery.build('sheets', 'v4', http=http,
                              discoveryServiceUrl=discoveryUrl)

    #first find which sheet should start update  
    startsheetid = 1+ (int(noofentry/ENTRYPERSHEET) * ENTRYPERSHEET) 
    endsheetid = ENTRYPERSHEET + (int(noofentry/ENTRYPERSHEET) * ENTRYPERSHEET) 
    sheetname = str(int(startsheetid)).zfill(10) + SEPERATENAME + str(int(endsheetid)).zfill(10)
    lookupsheetID = tableentry_ref.child(sheetname.strip()).get()
    currententryidPos = noofentry #point to the element has just used
    currentSheetPos = int(1+ (currententryidPos % ENTRYPERSHEET)) #point to the element is going to use
    updatelistPos =0 #point to the element is going to use
    print ('begin -> startsheetid =',startsheetid,',endsheetid=',
            endsheetid,',sheetname=',sheetname,
            'lookupsheetID=',lookupsheetID,
            'currententryidPos=',currententryidPos,
            'currentSheetPos=',currentSheetPos,
            'updatelistPos=',updatelistPos,
            )
   
    #start the work
    result = articlelisttostore
    updateList = []
    for entry in result :
      #A1:J1
      entryValue = [ entry.id, entry.firstsubdomaintable_id,
                       entry.finalurl,
                       entry.imageurl if ((entry.imageurl is not None) and ( len(entry.imageurl) > 0) ) else EMPTYSTRINGVALUE ,
                       entry.similaritiescount if (entry.similaritiescount is not None) else 0 ,
                       entry.timestampondoc.replace(tzinfo=timezone(timedelta(hours=8))).timestamp(),
                       entry.title,
                       entry.entryjsonStr if ((entry.entryjsonStr is not None) and (len(entry.entryjsonStr) > 0)) else EMPTYSTRINGVALUE ]
      updateList.append(entryValue)
    
    while currententryidPos < total_articlelisttostore :
      print (" currententryidPos=", currententryidPos,
        ", total_articlelisttostore=" , total_articlelisttostore)
      if (endsheetid  >= total_articlelisttostore ) :
        batchcount =0
        numEntrytoUpdate = total_articlelisttostore - \
          currententryidPos
        while ( numEntrytoUpdate > BATCHUPDATESIZE ) :
          #last sheetID to update
          write_range_name = 'Sheet1!A' +  \
              str(currentSheetPos) + \
              ':H' + \
              str( currentSheetPos + BATCHUPDATESIZE -1) 
          body = { 'values' : updateList[ \
                             updatelistPos: updatelistPos + \
                             BATCHUPDATESIZE ] }
          print ('before append -> ',
            'lookupsheetID=',lookupsheetID,
            'currententryidPos=',currententryidPos,
            'currentSheetPos=',currentSheetPos,
            'currentSheetPos+BATCHUPDATESIZE=',currentSheetPos+BATCHUPDATESIZE,
            'updatelistPos=',updatelistPos,
            'updatelistPos+BATCHUPDATESIZE=',updatelistPos+BATCHUPDATESIZE,
            ',write_range=',write_range_name
            )
   
          result = service.spreadsheets().values().append(
                    spreadsheetId=lookupsheetID, 
                    range=write_range_name,
                    valueInputOption=VALUE_INPUT_OPTION, 
                    body=body).execute()
          print ('endsheetid  >= total_articlelisttostore result=',
                result)
          numEntrytoUpdate -= BATCHUPDATESIZE
          currentSheetPos += BATCHUPDATESIZE
          updatelistPos += BATCHUPDATESIZE
          print ('numEntrytoUpdate=',numEntrytoUpdate,
                 'currentSheetPos=',currentSheetPos,
                 'updatelistPos=',updatelistPos)


        #last sheetID to update
        write_range_name = 'Sheet1!A' +  \
          str(currentSheetPos) + \
          ':H' + \
          str( currentSheetPos + (total_articlelisttostore - \
               currententryidPos ) )  
        body = { 'values' : updateList[ \
                             updatelistPos: updatelistPos + \
                              (total_articlelisttostore - \
                               currententryidPos ) ] }
        result = service.spreadsheets().values().append(
                    spreadsheetId=lookupsheetID, 
                    range=write_range_name,
                    valueInputOption=VALUE_INPUT_OPTION, 
                    body=body).execute()
        print ('endsheetid  >= total_articlelisttostore result=', 
                result)
        break
      elif (total_articlelisttostore > endsheetid) :
        numEntrytoUpdate = ENTRYPERSHEET - currentSheetPos + 1
        currententryidPos += numEntrytoUpdate
        while (numEntrytoUpdate > BATCHUPDATESIZE ):
          write_range_name = 'Sheet1!A' +  \
              str(currentSheetPos) + \
              ':H' + \
              str( currentSheetPos + BATCHUPDATESIZE -1 )
          body = { 'values' : updateList[ \
                             updatelistPos: updatelistPos + \
                              BATCHUPDATESIZE ] }
          result = service.spreadsheets().values().append(
                    spreadsheetId=lookupsheetID,
                    range=write_range_name,
                    valueInputOption=VALUE_INPUT_OPTION,
                    body=body).execute()
          print ('total_articlelisttostore > endsheetid result=',
                result)

          updatelistPos += BATCHUPDATESIZE
          currentSheetPos += BATCHUPDATESIZE
          numEntrytoUpdate -= BATCHUPDATESIZE

          print ('doing -> startsheetid =',startsheetid,',endsheetid=',
            endsheetid,',sheetname=',sheetname,
            'lookupsheetID=',lookupsheetID,
            'currententryidPos=',currententryidPos,
            'currentSheetPos=',currentSheetPos,
            'updatelistPos=',updatelistPos,
            )


        write_range_name = 'Sheet1!A' +  \
          str(currentSheetPos) + \
          ':H' + \
          str( ENTRYPERSHEET )
        body = { 'values' : updateList[ \
                             updatelistPos: updatelistPos + \
                              (ENTRYPERSHEET - \
                               currentSheetPos + 1 ) ] }
        result = service.spreadsheets().values().append(
                    spreadsheetId=lookupsheetID,
                    range=write_range_name,
                    valueInputOption=VALUE_INPUT_OPTION,
                    body=body).execute()
        print ('total_articlelisttostore > endsheetid result=',
                result)
        updatelistPos += ENTRYPERSHEET - currentSheetPos + 1

        currentSheetPos = 1
        startsheetid = int(1+ (int(currententryidPos/ENTRYPERSHEET) * \
                       ENTRYPERSHEET))
        endsheetid = int(ENTRYPERSHEET + \
                       (int(currententryidPos/ENTRYPERSHEET) * \
                         ENTRYPERSHEET) )
        sheetname =  str(startsheetid).zfill(10) + \
                     SEPERATENAME + \
                     str(endsheetid).zfill(10)
        lookupsheetID = tableentry_ref.child(sheetname.strip()).get()
        print ('doing -> startsheetid =',startsheetid,',endsheetid=',
            endsheetid,',sheetname=',sheetname,
            'lookupsheetID=',lookupsheetID,
            'currententryidPos=',currententryidPos,
            'currentSheetPos=',currentSheetPos,
            'updatelistPos=',updatelistPos,
            )

      else : 
        print ('xxxxxx  ->  else problem!!! ')

    noofentry = total_articlelisttostore
    table_ref.child(archiveName).update({ 'noofentry' : noofentry , 'lastupdatetime' : int(nowTime.timestamp())})
    #table_ref.update({ 'noofentry' : 0 , 'lastupdatetime' : int(nowTime.timestamp())})
     



def updateSheetarticlelookuptable () :
  #first get how many 
  total_articleFromdatabase = gong.getArticleTableCount()
  articlelookuptable_ref = db.reference().child('articlelookuptable')
  articlelookuptableNoofEntry_ref = articlelookuptable_ref.child('noofentry')
  articlelookuptableentry_ref = articlelookuptable_ref.child('entry')
  noofentry = articlelookuptableNoofEntry_ref.get()
  print (" updateSheetarticlelookuptable total_articleFromdatabase=", 
    total_articleFromdatabase, ",noofentry=", noofentry)
  if ( total_articleFromdatabase > noofentry ) :
    credentials = get_credentials()
    http = credentials.authorize(httplib2.Http())
    discoveryUrl = ('https://sheets.googleapis.com/$discovery/rest?'
                    'version=v4')
    service = discovery.build('sheets', 'v4', http=http,
                              discoveryServiceUrl=discoveryUrl)

    #first find which sheet should start update  
    startsheetid = 1+ (int(noofentry/ENTRYPERSHEET) * ENTRYPERSHEET) 
    endsheetid = ENTRYPERSHEET + (int(noofentry/ENTRYPERSHEET) * ENTRYPERSHEET) 
    sheetname = str(int(startsheetid)).zfill(10) + SEPERATENAME + str(int(endsheetid)).zfill(10)
    lookupsheetID = articlelookuptableentry_ref.child(sheetname.strip()).get()
    currententryidPos = noofentry #point to the element has just used
    currentSheetPos = int(1+ (currententryidPos % ENTRYPERSHEET)) #point to the element is going to use
    updatelistPos =0 #point to the element is going to use
    print ('begin -> startsheetid =',startsheetid,',endsheetid=',
            endsheetid,',sheetname=',sheetname,
            'lookupsheetID=',lookupsheetID,
            'currententryidPos=',currententryidPos,
            'currentSheetPos=',currentSheetPos,
            'updatelistPos=',updatelistPos,
            )
   
    #start the work
    #result = gong.getArticleTableRange(0,4659)
    result = gong.getArticleTableRange(noofentry)
    updateList = []
    for entry in result :
      #A1:J1
      if len(entry.content) > 5000 :
        root = lxml.html.fromstring(entry.content)
        stripHTMLtagString = root.xpath("//text()") 
        preparedContent = '<br>'.join(stripHTMLtagString)   
      else :
        preparedContent = entry.content
      if len(preparedContent) > 50000 :
        preparedContent =  preparedContent[:40000]
      entryValue = [ entry.id, entry.firstsubdomaintable_id,
                       entry.finalurl,
                       entry.timestampondoc.replace(tzinfo=timezone(timedelta(hours=8))).timestamp(),
                       entry.timestamponretrieve.replace(tzinfo=timezone(timedelta(hours=8))).timestamp(),
                       entry.title,
                       preparedContent,
                       entry.imageurl if ((entry.imageurl is not None) and ( len(entry.imageurl) > 0) ) else EMPTYSTRINGVALUE ,
                       entry.similaritieslist if ((entry.similaritieslist is not None) and ( len(entry.similaritieslist) > 0) ) else EMPTYSTRINGVALUE, 
                       entry.similaritiescount if (entry.similaritiescount is not None) else 0 ]
      updateList.append(entryValue)
    
    while currententryidPos < total_articleFromdatabase :
      if (endsheetid  >= total_articleFromdatabase ) :
        batchcount =0
        numEntrytoUpdate = total_articleFromdatabase - \
          currententryidPos
        while ( numEntrytoUpdate > BATCHUPDATESIZE ) :
          #last sheetID to update
          write_range_name = 'Sheet1!A' +  \
            str(currentSheetPos) + \
            ':J' + \
            str( currentSheetPos + BATCHUPDATESIZE -1)
          body = { 'values' : updateList[ \
                             updatelistPos: updatelistPos + BATCHUPDATESIZE ] }
          #result = service.spreadsheets().values().update(
          result = service.spreadsheets().values().append(
                    spreadsheetId=lookupsheetID,
                    range=write_range_name,
                    valueInputOption=VALUE_INPUT_OPTION,
                    body=body).execute()
          print ('endsheetid  >= total_articleFromdatabase result=',
                result)
          numEntrytoUpdate -= BATCHUPDATESIZE
          currentSheetPos += BATCHUPDATESIZE
          updatelistPos += BATCHUPDATESIZE
          print ('numEntrytoUpdate=',numEntrytoUpdate,
                 'currentSheetPos=',currentSheetPos,
                 'updatelistPos=',updatelistPos)


        write_range_name = 'Sheet1!A' +  \
            str(currentSheetPos) + \
            ':J' + \
            str( currentSheetPos + (total_articleFromdatabase - \
               currententryidPos ) )
        body = { 'values' : updateList[ \
                             updatelistPos: updatelistPos + \
                              (total_articleFromdatabase - \
                               currententryidPos ) ] }
        result = service.spreadsheets().values().append(
                    spreadsheetId=lookupsheetID,
                    range=write_range_name,
                    valueInputOption=VALUE_INPUT_OPTION,
                    body=body).execute()
        print ('endsheetid  >= total_articleFromdatabase final result=',
                result)
        print ('numEntrytoUpdate=',numEntrytoUpdate,
                 'currentSheetPos=',currentSheetPos,
                 'updatelistPos=',updatelistPos)
        break

      elif (total_articleFromdatabase > endsheetid) :
        batchcount =0
        numEntrytoUpdate = ENTRYPERSHEET - currentSheetPos + 1
        currententryidPos += numEntrytoUpdate
        while (numEntrytoUpdate > BATCHUPDATESIZE ): 
      
          write_range_name = 'Sheet1!A' +  \
              str(currentSheetPos) + \
              ':J' + \
              str( currentSheetPos + BATCHUPDATESIZE -1 ) 
          body = { 'values' : updateList[ \
                             updatelistPos: updatelistPos + \
                              BATCHUPDATESIZE ] }
          result = service.spreadsheets().values().append(
                    spreadsheetId=lookupsheetID, 
                    range=write_range_name,
                    valueInputOption=VALUE_INPUT_OPTION, 
                    body=body).execute()
          print ('total_articleFromdatabase > endsheetid result=', 
                result)

          updatelistPos += BATCHUPDATESIZE 
          currentSheetPos += BATCHUPDATESIZE
          numEntrytoUpdate -= BATCHUPDATESIZE 
          
          print ('doing while loop total_articleFromdatabase > endsheetid  -> startsheetid =',startsheetid,',endsheetid=',
            endsheetid,',sheetname=',sheetname,
            'lookupsheetID=',lookupsheetID,
            'currententryidPos=',currententryidPos,
            'currentSheetPos=',currentSheetPos,
            'updatelistPos=',updatelistPos,
            )
       
        write_range_name = 'Sheet1!A' +  \
          str(currentSheetPos) + \
          ':J' + \
          str( ENTRYPERSHEET ) 
        body = { 'values' : updateList[ \
                             updatelistPos: updatelistPos + \
                              (ENTRYPERSHEET - \
                               currentSheetPos + 1) ] }
        result = service.spreadsheets().values().append(
                    spreadsheetId=lookupsheetID, 
                    range=write_range_name,
                    valueInputOption=VALUE_INPUT_OPTION, 
                    body=body).execute()
        print ('total_articleFromdatabase > endsheetid result=', 
                result)
        updatelistPos += ENTRYPERSHEET - currentSheetPos + 1
        
        currentSheetPos = 1
        startsheetid = int(1+ (int(currententryidPos/ENTRYPERSHEET) * \
                       ENTRYPERSHEET)) 
        endsheetid = int(ENTRYPERSHEET + \
                       (int(currententryidPos/ENTRYPERSHEET) * \
                         ENTRYPERSHEET) )
        sheetname =  str(startsheetid).zfill(10) + \
                     SEPERATENAME + \
                     str(endsheetid).zfill(10)
        lookupsheetID = articlelookuptableentry_ref.child(sheetname.strip()).get()
        print ('doing total_articleFromdatabase > endsheetid  `-> startsheetid =',startsheetid,',endsheetid=',
            endsheetid,',sheetname=',sheetname,
            'lookupsheetID=',lookupsheetID,
            'currententryidPos=',currententryidPos,
            'currentSheetPos=',currentSheetPos,
            'updatelistPos=',updatelistPos,
            )
   

      else : 
        print ('xxxxxx  ->  else problem!!! ')

    noofentry = total_articleFromdatabase
    articlelookuptable_ref.update({ 'noofentry' : noofentry , 'lastupdatetime' : int(nowTime.timestamp())})
    #articlelookuptable_ref.update({ 'noofentry' : 0 , 'lastupdatetime' : int(nowTime.timestamp())})
     


def updatetableThree (checkinInfo) :
  table_ref = db.reference().child(checkinInfo['firebasetable_name'])
  tableNoofEntry_ref = table_ref.child('noofentry')
  totalFromFirebase = tableNoofEntry_ref.get()

  newTotalFromDatabase = gong.getSumOfArticleWithCategory(checkinInfo['category_name'])

  articleresult = gong.getArticleWithCategoryAndOffset( checkinInfo['category_name'], 
                  totalFromFirebase )
  firstsubdomainresult = gong.getFirstSubDomainDict()
  noofentry = 0
  result = table_ref.get()
  resultlist = []
  print (" updatetable 0 len(articleresult)=", len(articleresult)) 
  for entry in articleresult :
    prep_list=[]
    prep_dict={}
    if (entry.similaritiescount is not None) and (entry.similaritiescount >0 ) :
      for sim_id in entry.similaritieslist.split() :
        sim_id_entry = gong.getIndArticleEntry(sim_id)
        addToListEntry = {}
        addToListEntry['id'] = sim_id_entry.id
        addToListEntry['firstsubdomaintable_id'] = sim_id_entry.firstsubdomaintable_id
        addToListEntry['finalurl'] = sim_id_entry.finalurl
        addToListEntry['imageurl'] = sim_id_entry.imageurl
        addToListEntry['timestampondoc'] = int(sim_id_entry.timestampondoc.replace(tzinfo=timezone(timedelta(hours=8))).timestamp())
        addToListEntry['title'] = sim_id_entry.title
        timestampondocandid = 'Z'.join([str(int(sim_id_entry.timestampondoc.replace(tzinfo=timezone(timedelta(hours=8))).timestamp())), str(sim_id_entry.id).zfill(10) ])
        addToListEntry['timestampondocandid'] = timestampondocandid


        #prep_list.append({ timestampondocandid : addToListEntry })
        prep_dict[timestampondocandid] = addToListEntry  

        
        #if len(json.dumps(prep_list)) > 50000 :
        if len(json.dumps(prep_dict)) > 40000 :
           #print ("wow... too big for json cell entry.id=", entry.id , " sim_id_entry.id=", sim_id_entry.id, "len(prep_list)=",len(prep_list), ",entry.similaritiescount=", entry.similaritiescount) 
           #prep_list = prep_list[:-1]
           print ("wow... too big for json cell entry.id=", entry.id , " sim_id_entry.id=", sim_id_entry.id, "len(prep_dict)=",len(prep_dict), ",entry.similaritiescount=", entry.similaritiescount) 
           del prep_dict[timestampondocandid]
           break 
    
      #entry.entryjsonStr = json.dumps(prep_list)
      #entry.similaritiescount = len(prep_list)
      orderDict = OrderedDict(sorted(prep_dict.items()))
      entry.entryjsonStr = json.dumps(orderDict)
      entry.similaritiescount = len(orderDict)
    else :
      entry.entryjsonStr = EMPTYSTRINGVALUE


  #do the tensorflow part
  vocab_path = os.path.join(CHECKPOINT_DIR , "..", "vocab")
  vocab_processor = learn.preprocessing.VocabularyProcessor.restore(vocab_path)
  entityListDict = gong.getEntityDictEmptyList()
  checkpoint_file = tf.train.latest_checkpoint(CHECKPOINT_DIR)
  graph = tf.Graph()
  with graph.as_default():
    session_conf = tf.ConfigProto(
      allow_soft_placement=True,
      log_device_placement=False )
    sess = tf.Session( config=session_conf)
    with sess.as_default():
        # Load the saved meta graph and restore variables
        saver = tf.train.import_meta_graph("{}.meta".format(checkpoint_file))
        saver.restore(sess, checkpoint_file)

        # Get the placeholders from the graph by name
        input_x = graph.get_operation_by_name("input_x").outputs[0]
        # input_y = graph.get_operation_by_name("input_y").outputs[0]
        dropout_keep_prob = graph.get_operation_by_name("dropout_keep_prob").outputs[0]
        # Tensors we want to evaluate
        predictions = graph.get_operation_by_name("output/predictions").outputs[0]
        
        for entry in articleresult :
          for key in entityListDict :
            tokenSenList = gong.getTokenSenCaseList( entry.id ) 
            if (tokenSenList is None) or (len(tokenSenList) ==0) :
              print ("error error tokenSenList ==0 or none entry.id=", entry.id)
              break 
      
            transformTokenArray = np.array(list(vocab_processor.transform(tokenSenList)))
            # Generate batches for one epoch
            batches = data_helpers.batch_iter(list(transformTokenArray), 
                        64, 1, shuffle=False)
            # Collect the predictions here
            all_predictions = []
            for x_test_batch in batches:
              batch_predictions = sess.run(predictions, {input_x: x_test_batch, dropout_keep_prob: 1.0})
              all_predictions = np.concatenate([all_predictions, batch_predictions])
            all_predictions_list = [ int(x) for x in all_predictions.tolist()]
            #print (" all_predictions_list=", all_predictions_list)
            entityName = key.split('ZZ')[0].strip('0')
            entityID = key.split('ZZ')[1].strip('0')
            foundthecase=False
            for checkCase in  entityListDict[key]['checkrelatedcaseList']  :
              for i, checkValue in enumerate(all_predictions_list) :
                #if there is a case , check name then
                #print (" i=",i," checkValue=",checkValue,",checkCase=",checkCase, ", checkValue==checkCase", checkValue ==checkCase )
                if ( ( checkValue == checkCase ) and ( entry.content.find(entityName) > -1 ) )  :
                  entityListDict[key]['relatedarticleList'].append(entry) 
                  foundthecase=True 
                  break
              if (foundthecase) :
                break
              
  #let put the list to drive 
  #first put the list to entity
  for key in entityListDict :
    print (" for loop entityListDict key=",key)
    updateSheetArchivetable ('entitytable',
             key, 
             entityListDict[key]['relatedarticleList']) 
  
  #exit for now 
  #if len(articleresult) >= 0 :
  #  print (" exit for now")
  #  return 
  #return

  #now put the list to archive 
  print (" updatetable 1") 
  if len(articleresult) > 0 :
    print (" updatetable 1.1") 
    updateSheetArchivetable (checkinInfo['firebasetable_name'],
             checkinInfo['archivename'], 
             articleresult) 
  print (" updatetable 2") 
  print (" updatetable 2 articleresult[0].id=", 
       articleresult[0].id ,
       "articleresult[-1].id=", 
       articleresult[-1].id)

  siftResultList = siftOlderArticle( articleresult ) 
  print (" updatetable 3 siftResultList[0].id=", 
       siftResultList[0].id ,
       "siftResultList[-1].id=", 
       siftResultList[-1].id)

  siftListlen = len(siftResultList)
  
  if siftListlen < (NOOFENTRYPERPAGE * NOOFPAGINATION) :
    #addback entry if needed for pagination 
    print (" updatetable 4") 
    getBackList = getSheetEntries( checkinInfo['firebasetable_name'],
             checkinInfo['pagearchivetable_name'],
             (NOOFENTRYPERPAGE * NOOFPAGINATION) - siftListlen,
             ) 
    if (len(getBackList) > 0 ) :
      print (" updatetable 4.1=", len(getBackList)) 
      for x in getBackList :
        #add back to a full list to update pagination table
        siftResultList.append(x)



  #update database
  print (" updatetable 5 ") 
  if len(siftResultList) > 0 :
    print (" updatetable 5.1 ") 
    updateSheetArchivetable (checkinInfo['firebasetable_name'],
             checkinInfo['pagearchivetable_name'],
             siftResultList) 
  print (" updatetable 6") 
  

 
  if len(siftResultList) > 0 :
    print (" updatetable 8") 
    pagination_ref = table_ref.child(checkinInfo['paginationtable_name'])
    pagination_ref.delete()
    startpagerange = 1
    stoppagerange = NOOFENTRYPERPAGE
    pagination_ref = table_ref.child(checkinInfo['paginationtable_name'])
    noofentry=0
    print (" updatetable 8.1 siftResultList[0].id=", 
       siftResultList[0].id ,
       "siftResultList[-1].id=", 
       siftResultList[-1].id)
    siftResultList.reverse()
    print (" updatetable 8.2 siftResultList[0].id=", 
       siftResultList[0].id ,
       "siftResultList[-1].id=", 
       siftResultList[-1].id)
    for entry in siftResultList[:(NOOFENTRYPERPAGE * NOOFPAGINATION)] :
      print ('--------- entry.id= ' , entry.id  )
      noofentry += 1
      print (' ========================= noofentry = ', noofentry)

      #paginationumber start from 0
      paginationnumber = int((noofentry-1) / NOOFENTRYPERPAGE) 
      sectionname = str(int(startpagerange + \
                      (paginationnumber * NOOFENTRYPERPAGE)) ) + \
                      "to" + \
                      str(int(stoppagerange + \
                        (paginationnumber * NOOFENTRYPERPAGE)) )
      paginationsec_ref = pagination_ref.child(sectionname)
      paginationsec_ref.update({ "noofentry" : ((noofentry-1)  % NOOFENTRYPERPAGE ) +1  })
      paginationsec_ref.update({ 'lastupdatetime' : int(nowTime.timestamp())})
      paginationsecentry_ref = paginationsec_ref.child("entry")
      paginationsecentry_ref.child('Z'.join(  
            [str(int(entry.timestampondoc.replace( \
                tzinfo=timezone(timedelta(hours=8))).timestamp())),
            str(entry.id).zfill(10) ]))\
            .update({ 'id' : entry.id ,
            'firstsubdomaintable_id' : entry.firstsubdomaintable_id, 
            'finalurl' : entry.finalurl, 
            'title' : entry.title ,
            'imageurl' : entry.imageurl if ((entry.imageurl is not None) and ( len(entry.imageurl) > 0) ) else EMPTYSTRINGVALUE ,
            'similaritiescount' : entry.similaritiescount if (entry.similaritiescount is not None) else 0 
            } )
      if (entry.similaritiescount is not None) and (entry.similaritiescount > 0) :
        for similarentryid in entry.similaritieslist.strip().split() :
          similarentry = gong.getIndArticleEntry(similarentryid)
          paginationsecentry_ref.child('Z'.join([str(int(entry.timestampondoc.replace(tzinfo=timezone(timedelta(hours=8))).timestamp())), str(entry.id).zfill(10) ]))\
              .child("entry").child('Z'.join([str(int(similarentry.timestampondoc.replace(tzinfo=timezone(timedelta(hours=8))).timestamp())), str(similarentry.id).zfill(10) ]))\
              .update({ 'id' : similarentry.id ,
                     'firstsubdomaintable_id' : similarentry.firstsubdomaintable_id, 
                     'finalurl' : similarentry.finalurl, 
                     'title' : similarentry.title ,
                     'imageurl' : similarentry.imageurl if ((similarentry.imageurl is not None) and ( len(similarentry.imageurl) > 0) ) else EMPTYSTRINGVALUE ,
                } )

  table_ref.update({ 'noofentry' : newTotalFromDatabase , 'lastupdatetime' : int(nowTime.timestamp())})






def updatetableFour (checkinInfo) :
  table_ref = db.reference().child(checkinInfo['firebasetable_name'])
  tableNoofEntry_ref = table_ref.child(checkinInfo['fragarchivetable_name']
                      ).child('noofentry')
  totalFromFirebase = tableNoofEntry_ref.get()

  newTotalFromDatabase = gong.getSumOfArticleWithCategory(checkinInfo['category_name'])

  articleresult = gong.getArticleWithCategoryAndOffset( checkinInfo['category_name'], 
                  totalFromFirebase )
  firstsubdomainresult = gong.getFirstSubDomainDict()
  noofentry = 0
  result = table_ref.get()
  resultlist = []
  print (" updatetable 0 len(articleresult)=", len(articleresult)) 
  for entry in articleresult :
    prep_list=[]
    prep_dict={}
    if (entry.similaritiescount is not None) and (entry.similaritiescount >0 ) :
      for sim_id in entry.similaritieslist.split() :
        sim_id_entry = gong.getIndArticleEntry(sim_id)
        addToListEntry = {}
        addToListEntry['id'] = sim_id_entry.id
        addToListEntry['firstsubdomaintable_id'] = sim_id_entry.firstsubdomaintable_id
        addToListEntry['finalurl'] = sim_id_entry.finalurl
        addToListEntry['imageurl'] = sim_id_entry.imageurl
        addToListEntry['timestampondoc'] = int(sim_id_entry.timestampondoc.replace(tzinfo=timezone(timedelta(hours=8))).timestamp())
        addToListEntry['title'] = sim_id_entry.title
        timestampondocandid = 'Z'.join([str(int(sim_id_entry.timestampondoc.replace(tzinfo=timezone(timedelta(hours=8))).timestamp())), str(sim_id_entry.id).zfill(10) ])
        addToListEntry['timestampondocandid'] = timestampondocandid


        #prep_list.append({ timestampondocandid : addToListEntry })
        prep_dict[timestampondocandid] = addToListEntry  

        
        #if len(json.dumps(prep_list)) > 50000 :
        if len(json.dumps(prep_dict)) > 50000 :
           #print ("wow... too big for json cell entry.id=", entry.id , " sim_id_entry.id=", sim_id_entry.id, "len(prep_list)=",len(prep_list), ",entry.similaritiescount=", entry.similaritiescount) 
           #prep_list = prep_list[:-1]
           print ("wow... too big for json cell entry.id=", entry.id , " sim_id_entry.id=", sim_id_entry.id, "len(prep_dict)=",len(prep_dict), ",entry.similaritiescount=", entry.similaritiescount) 
           del prep_dict[timestampondocandid]
           break 
    
      #entry.entryjsonStr = json.dumps(prep_list)
      #entry.similaritiescount = len(prep_list)
      orderDict = OrderedDict(sorted(prep_dict.items()))
      entry.entryjsonStr = json.dumps(orderDict)
      entry.similaritiescount = len(orderDict)
    else :
      entry.entryjsonStr = EMPTYSTRINGVALUE


  
  #exit for now 
  #if len(articleresult) >= 0 :
  #  print (" exit for now")
  #  return 
  #return

  #now put the list to archive 
  print (" updatetable 1") 
  if len(articleresult) > 0 :
    print (" updatetable 1.1") 
    updateSheetArchivetable (checkinInfo['firebasetable_name'],
             checkinInfo['fragarchivetable_name'], 
             articleresult) 
  print (" updatetable 2") 
  print (" updatetable 2 articleresult[0].id=", 
       articleresult[0].id ,
       "articleresult[-1].id=", 
       articleresult[-1].id)

  siftResultList = siftOlderArticle( articleresult ) 
  print (" updatetable 3 siftResultList[0].id=", 
       siftResultList[0].id ,
       "siftResultList[-1].id=", 
       siftResultList[-1].id)


  #update database
  print (" updatetable 5 ") 
  if len(siftResultList) > 0 :
    print (" updatetable 5.1 ") 
    updateSheetArchivetable (checkinInfo['firebasetable_name'],
             checkinInfo['fragtable_name'],
             siftResultList) 
  print (" updatetable 6") 
 





def updatetabletwocat (checkinInfo) :
  table_ref = db.reference().child(checkinInfo['firebasetable_name'])
  tableNoofEntry_ref = table_ref.child(checkinInfo['archivename']).child('noofentry')
  totalFromFirebase = tableNoofEntry_ref.get()

  tableNoofEntry_ref2 = db.reference().child(checkinInfo['firebasetable_name2']).child(checkinInfo['archivename2']).child('noofentry')
  totalFromFirebase_2 = tableNoofEntry_ref2.get()
  

  newTotalFromDatabase = gong.getSumOfArticleWithCategory(checkinInfo['category_name'])

  articleresult = gong.getArticleWithCategoryAndOffset( checkinInfo['category_name'], 
                  totalFromFirebase,
                  checkinInfo['category_eng_name2'],
                  totalFromFirebase_2 )
  firstsubdomainresult = gong.getFirstSubDomainDict()
  noofentry = 0
  result = table_ref.get()
  resultlist = []
  print (" updatetable 0 len(articleresult)=", len(articleresult)) 
  for entry in articleresult :
    prep_list=[]
    prep_dict={}
    if (entry.similaritiescount is not None) and (entry.similaritiescount >0 ) :
      for sim_id in entry.similaritieslist.split() :
        sim_id_entry = gong.getIndArticleEntry(sim_id)
        addToListEntry = {}
        addToListEntry['id'] = sim_id_entry.id
        addToListEntry['firstsubdomaintable_id'] = sim_id_entry.firstsubdomaintable_id
        addToListEntry['finalurl'] = sim_id_entry.finalurl
        addToListEntry['imageurl'] = sim_id_entry.imageurl
        addToListEntry['timestampondoc'] = int(sim_id_entry.timestampondoc.replace(tzinfo=timezone(timedelta(hours=8))).timestamp())
        addToListEntry['title'] = sim_id_entry.title
        timestampondocandid = 'Z'.join([str(int(sim_id_entry.timestampondoc.replace(tzinfo=timezone(timedelta(hours=8))).timestamp())), str(sim_id_entry.id).zfill(10) ])
        addToListEntry['timestampondocandid'] = timestampondocandid


        #prep_list.append({ timestampondocandid : addToListEntry })
        prep_dict[timestampondocandid] = addToListEntry  

        
        #if len(json.dumps(prep_list)) > 50000 :
        if len(json.dumps(prep_dict)) > 50000 :
           #print ("wow... too big for json cell entry.id=", entry.id , " sim_id_entry.id=", sim_id_entry.id, "len(prep_list)=",len(prep_list), ",entry.similaritiescount=", entry.similaritiescount) 
           #prep_list = prep_list[:-1]
           print ("wow... too big for json cell entry.id=", entry.id , " sim_id_entry.id=", sim_id_entry.id, "len(prep_dict)=",len(prep_dict), ",entry.similaritiescount=", entry.similaritiescount) 
           del prep_dict[timestampondocandid]
           break 
    
      #entry.entryjsonStr = json.dumps(prep_list)
      #entry.similaritiescount = len(prep_list)
      orderDict = OrderedDict(sorted(prep_dict.items()))
      entry.entryjsonStr = json.dumps(orderDict)
      entry.similaritiescount = len(orderDict)
    else :
      entry.entryjsonStr = EMPTYSTRINGVALUE


  #do the tensorflow part
  vocab_path = os.path.join(CHECKPOINT_DIR , "..", "vocab")
  vocab_processor = learn.preprocessing.VocabularyProcessor.restore(vocab_path)
  entityListDict = gong.getEntityDictEmptyList()
  checkpoint_file = tf.train.latest_checkpoint(CHECKPOINT_DIR)
  graph = tf.Graph()
  with graph.as_default():
    session_conf = tf.ConfigProto(
      allow_soft_placement=True,
      log_device_placement=False )
    sess = tf.Session( config=session_conf)
    with sess.as_default():
        # Load the saved meta graph and restore variables
        saver = tf.train.import_meta_graph("{}.meta".format(checkpoint_file))
        saver.restore(sess, checkpoint_file)

        # Get the placeholders from the graph by name
        input_x = graph.get_operation_by_name("input_x").outputs[0]
        # input_y = graph.get_operation_by_name("input_y").outputs[0]
        dropout_keep_prob = graph.get_operation_by_name("dropout_keep_prob").outputs[0]
        # Tensors we want to evaluate
        predictions = graph.get_operation_by_name("output/predictions").outputs[0]
        
        for entry in articleresult :
          tokenSenList = gong.getTokenSenCaseList( entry.id ) 
          if (tokenSenList is None) or (len(tokenSenList) ==0) :
            print ("error error tokenSenList ==0 or none entry.id=", entry.id)
            continue 
          for key in entityListDict :
      
            transformTokenArray = np.array(list(vocab_processor.transform(tokenSenList)))
            # Generate batches for one epoch
            batches = data_helpers.batch_iter(list(transformTokenArray), 
                        64, 1, shuffle=False)
            # Collect the predictions here
            all_predictions = []
            for x_test_batch in batches:
              batch_predictions = sess.run(predictions, {input_x: x_test_batch, dropout_keep_prob: 1.0})
              all_predictions = np.concatenate([all_predictions, batch_predictions])
            all_predictions_list = [ int(x) for x in all_predictions.tolist()]
            #print (" all_predictions_list=", all_predictions_list)
            entityName = key.split('ZZ')[0].strip('0')
            entityID = key.split('ZZ')[1].strip('0')
            foundthecase=False
            for checkCase in  entityListDict[key]['checkrelatedcaseList']  :
              for i, checkValue in enumerate(all_predictions_list) :
                #if there is a case , check name then
                #print (" i=",i," checkValue=",checkValue,",checkCase=",checkCase, ", checkValue==checkCase", checkValue ==checkCase )
                if ( ( checkValue == checkCase ) and ( entry.content.find(entityName) > -1 ) )  :
                  entityListDict[key]['relatedarticleList'].append(entry) 
                  foundthecase=True 
                  break
              if (foundthecase) :
                break
              
  #let put the list to drive 
  #first put the list to entity
  for key in entityListDict :
    print (" for loop entityListDict key=",key)
    updateSheetArchivetable ('entitytable',
             key, 
             entityListDict[key]['relatedarticleList']) 



 
  #retrieve again 
  articleresult = gong.getArticleWithCategoryAndOffset( checkinInfo['category_name'], 
                  totalFromFirebase )
  noofentry = 0
  result = table_ref.get()
  resultlist = []
  print (" updatetable 0.1 len(articleresult)=", len(articleresult)) 
  for entry in articleresult :
    prep_list=[]
    prep_dict={}
    if (entry.similaritiescount is not None) and (entry.similaritiescount >0 ) :
      for sim_id in entry.similaritieslist.split() :
        sim_id_entry = gong.getIndArticleEntry(sim_id)
        addToListEntry = {}
        addToListEntry['id'] = sim_id_entry.id
        addToListEntry['firstsubdomaintable_id'] = sim_id_entry.firstsubdomaintable_id
        addToListEntry['finalurl'] = sim_id_entry.finalurl
        addToListEntry['imageurl'] = sim_id_entry.imageurl
        addToListEntry['timestampondoc'] = int(sim_id_entry.timestampondoc.replace(tzinfo=timezone(timedelta(hours=8))).timestamp())
        addToListEntry['title'] = sim_id_entry.title
        timestampondocandid = 'Z'.join([str(int(sim_id_entry.timestampondoc.replace(tzinfo=timezone(timedelta(hours=8))).timestamp())), str(sim_id_entry.id).zfill(10) ])
        addToListEntry['timestampondocandid'] = timestampondocandid


        #prep_list.append({ timestampondocandid : addToListEntry })
        prep_dict[timestampondocandid] = addToListEntry  

        
        #if len(json.dumps(prep_list)) > 50000 :
        if len(json.dumps(prep_dict)) > 50000 :
           #print ("wow... too big for json cell entry.id=", entry.id , " sim_id_entry.id=", sim_id_entry.id, "len(prep_list)=",len(prep_list), ",entry.similaritiescount=", entry.similaritiescount) 
           #prep_list = prep_list[:-1]
           print ("wow... too big for json cell entry.id=", entry.id , " sim_id_entry.id=", sim_id_entry.id, "len(prep_dict)=",len(prep_dict), ",entry.similaritiescount=", entry.similaritiescount) 
           del prep_dict[timestampondocandid]
           break 
    
      #entry.entryjsonStr = json.dumps(prep_list)
      #entry.similaritiescount = len(prep_list)
      orderDict = OrderedDict(sorted(prep_dict.items()))
      entry.entryjsonStr = json.dumps(orderDict)
      entry.similaritiescount = len(orderDict)
    else :
      entry.entryjsonStr = EMPTYSTRINGVALUE


 
  #exit for now 
  #if len(articleresult) >= 0 :
  #  print (" exit for now")
  #  return 
  #return

  #now put the list to archive 
  print (" updatetable 1") 
  if len(articleresult) > 0 :
    print (" updatetable 1.1") 
    updateSheetArchivetable (checkinInfo['firebasetable_name'],
             checkinInfo['archivename'], 
             articleresult) 
  print (" updatetable 2") 
  print (" updatetable 2 articleresult[0].id=", 
       articleresult[0].id ,
       "articleresult[-1].id=", 
       articleresult[-1].id)

  siftResultList = siftOlderArticle( articleresult ) 
  print (" updatetable 3 siftResultList[0].id=", 
       siftResultList[0].id ,
       "siftResultList[-1].id=", 
       siftResultList[-1].id)

  siftListlen = len(siftResultList)
  
  if siftListlen < (NOOFENTRYPERPAGE * NOOFPAGINATION) :
    #addback entry if needed for pagination 
    print (" updatetable 4") 
    getBackList = getSheetEntries( checkinInfo['firebasetable_name'],
             checkinInfo['pagearchivetable_name'],
             (NOOFENTRYPERPAGE * NOOFPAGINATION) - siftListlen,
             ) 
    if (len(getBackList) > 0 ) :
      print (" updatetable 4.1=", len(getBackList)) 
      for x in getBackList :
        #add back to a full list to update pagination table
        siftResultList.append(x)



  #update database
  print (" updatetable 5 ") 
  if len(siftResultList) > 0 :
    print (" updatetable 5.1 ") 
    updateSheetArchivetable (checkinInfo['firebasetable_name'],
             checkinInfo['pagearchivetable_name'],
             siftResultList) 
  print (" updatetable 6") 
  

 
  if len(siftResultList) > 0 :
    print (" updatetable 8") 
    pagination_ref = table_ref.child(checkinInfo['paginationtable_name'])
    pagination_ref.delete()
    startpagerange = 1
    stoppagerange = NOOFENTRYPERPAGE
    pagination_ref = table_ref.child(checkinInfo['paginationtable_name'])
    noofentry=0
    print (" updatetable 8.1 siftResultList[0].id=", 
       siftResultList[0].id ,
       "siftResultList[-1].id=", 
       siftResultList[-1].id)
    siftResultList.reverse()
    print (" updatetable 8.2 siftResultList[0].id=", 
       siftResultList[0].id ,
       "siftResultList[-1].id=", 
       siftResultList[-1].id)
    for entry in siftResultList[:(NOOFENTRYPERPAGE * NOOFPAGINATION)] :
      print ('--------- entry.id= ' , entry.id  )
      noofentry += 1
      print (' ========================= noofentry = ', noofentry)

      #paginationumber start from 0
      paginationnumber = int((noofentry-1) / NOOFENTRYPERPAGE) 
      sectionname = str(int(startpagerange + \
                      (paginationnumber * NOOFENTRYPERPAGE)) ) + \
                      "to" + \
                      str(int(stoppagerange + \
                        (paginationnumber * NOOFENTRYPERPAGE)) )
      paginationsec_ref = pagination_ref.child(sectionname)
      paginationsec_ref.update({ "noofentry" : ((noofentry-1)  % NOOFENTRYPERPAGE ) +1  })
      paginationsec_ref.update({ 'lastupdatetime' : int(nowTime.timestamp())})
      paginationsecentry_ref = paginationsec_ref.child("entry")
      paginationsecentry_ref.child('Z'.join(  
            [str(int(entry.timestampondoc.replace( \
                tzinfo=timezone(timedelta(hours=8))).timestamp())),
            str(entry.id).zfill(10) ]))\
            .update({ 'id' : entry.id ,
            'firstsubdomaintable_id' : entry.firstsubdomaintable_id, 
            'finalurl' : entry.finalurl, 
            'title' : entry.title ,
            'imageurl' : entry.imageurl if ((entry.imageurl is not None) and ( len(entry.imageurl) > 0) ) else EMPTYSTRINGVALUE ,
            'similaritiescount' : entry.similaritiescount if (entry.similaritiescount is not None) else 0 
            } )
      if (entry.similaritiescount is not None) and (entry.similaritiescount > 0) :
        for similarentryid in entry.similaritieslist.strip().split() :
          similarentry = gong.getIndArticleEntry(similarentryid)
          paginationsecentry_ref.child('Z'.join([str(int(entry.timestampondoc.replace(tzinfo=timezone(timedelta(hours=8))).timestamp())), str(entry.id).zfill(10) ]))\
              .child("entry").child('Z'.join([str(int(similarentry.timestampondoc.replace(tzinfo=timezone(timedelta(hours=8))).timestamp())), str(similarentry.id).zfill(10) ]))\
              .update({ 'id' : similarentry.id ,
                     'firstsubdomaintable_id' : similarentry.firstsubdomaintable_id, 
                     'finalurl' : similarentry.finalurl, 
                     'title' : similarentry.title ,
                     'imageurl' : similarentry.imageurl if ((similarentry.imageurl is not None) and ( len(similarentry.imageurl) > 0) ) else EMPTYSTRINGVALUE ,
                } )

  table_ref.update({ 'noofentry' : newTotalFromDatabase , 'lastupdatetime' : int(nowTime.timestamp())})


def main():
  
  print ("\n\n", "executing ......... " , sys.argv[0]," ",sys.argv[1], "\n\n" )


  checktime = datetime.now(timezone(timedelta(hours=8)))
  print ('checktime firebase-update-2 start', checktime)
  if flags.updatecategory :
    updatecategorytable()
  if flags.updatedomain :
    updatedomaintable()
  if flags.updatefirstsubdomain :
    updatefirstsubdomaintable()
  #updatearticletable()
  #updatelatestnewstable() 
  #updatelatestnewstableTwo() 
  #updatearticlelookuptable()
  if flags.sheetapi :
    print ("hello sheetapi")
    #articlelookuptable_ref = db.reference().child('articlelookuptable')
    #articlelookuptableNoofEntry_ref = articlelookuptable_ref.child('noofentry')
    #articlelookuptableentry_ref = db.reference().child('entry')
    #noofentry = articlelookuptableNoofEntry_ref.get()
    #print ('entry',articlelookuptableentry_ref.get())
    #print ('whole',articlelookuptable_ref.get())
    updateSheetarticlelookuptable ()


  if flags.gdriveuploadwithcurrentdate :
    #listAtGDrive ()
    creategongdbAtGDrivewithcurrentdate ()
    #updategongdbAtGDrive () 

  if flags.gdriveupload :
    #listAtGDrive ()
    #creategongdbAtGDrive ()
    updategongdbAtGDrive () 

  if flags.gdrivedownload :
    #listAtGDrive ()
    #creategongdbAtGDrive ()
    downloadgongdbAtGDrive () 


  if flags.updatetable :
    checkinDict = { 'archivename' : 'archivelatestnews',
     'category_name' : 'latestnews',
     'firebasetable_name' : 'latestnewstable',
     'pagearchivetable_name' : 'pagearchivelatestnews',
     'paginationtable_name' : 'pagination'
     }
    updatetableThree (checkinDict) 

  if flags.updateindtable :
    credentials = get_credentials()
    http = credentials.authorize(httplib2.Http())
    discoveryUrl = ('https://sheets.googleapis.com/$discovery/rest?'
                    'version=v4')
    service = discovery.build('sheets', 'v4', http=http,
                              discoveryServiceUrl=discoveryUrl)
    write_range_name = 'Sheet1!B' + str(232) + ':B' + str(233)   
    updateList = []
    for x in range(0,2) :
      # 232 :9 , 233 :18
      updateList.append([1])
    print (' len updateList=', len(updateList))
    body = { 'values' : updateList }
    result = service.spreadsheets().values().update(
                    #spreadsheetId='1yZrCppFqk1uYBnyjU4xEEOGg8bj8rYb3fIINQI0cmJo', 
                    spreadsheetId='1zZFKw6wagojFABOtpTl6OMTE-7sDne9DT8c8AuRROZI', 
                    range=write_range_name,
                    valueInputOption=VALUE_INPUT_OPTION, 
                    body=body).execute()
    print (' updateindtable  result=', result)





  if flags.updatetabletwocat :
    checkinDict = { 
     'archivename' : 'archivelatestnews',
     'category_name' : 'latestnews',
     'firebasetable_name' : 'latestnewstable',
     'pagearchivetable_name' : 'pagearchivelatestnews',
     'paginationtable_name' : 'pagination',
     'category_eng_name2' : 'dailynews',
     'firebasetable_name2' : 'fragmenttable',
     'archivename2' : 'hknewsarchivetable',
     }
    updatetabletwocat (checkinDict) 


  if flags.updateentfragtable :
    checkinDict = { 'fragtable_name' : 'entnewstable',
     'fragarchivetable_name' : 'entnewsarchivetable',
     'category_name' : 'entertainmentnews',
     'firebasetable_name' : 'fragmenttable',
     }
    updatetableFour (checkinDict) 

  if flags.updatesportfragtable :
    checkinDict = { 'fragtable_name' : 'sportsnewstable',
     'fragarchivetable_name' : 'sportsnewsarchivetable',
     'category_name' : 'sportsnews',
     'firebasetable_name' : 'fragmenttable',
     }
    updatetableFour (checkinDict) 

  if flags.updatefinfragtable :
    checkinDict = { 'fragtable_name' : 'finnewstable',
     'fragarchivetable_name' : 'finnewsarchivetable',
     'category_name' : 'financialnews',
     'firebasetable_name' : 'fragmenttable',
     }
    updatetableFour (checkinDict) 

  if flags.updatefinlatestfragtable :
    checkinDict = { 'fragtable_name' : 'finlatestnewstable',
     'fragarchivetable_name' : 'finlatestnewsarchivetable',
     'category_name' : 'latestfinnews',
     'firebasetable_name' : 'fragmenttable',
     }
    updatetableFour (checkinDict) 

  if flags.updatehkfragtable :
    checkinDict = { 'fragtable_name' : 'hknewstable',
     'fragarchivetable_name' : 'hknewsarchivetable',
     'category_name' : 'dailynews',
     'firebasetable_name' : 'fragmenttable',
     }
    updatetableFour (checkinDict) 



  if ( type(flags.arclatestnoofentry) is list ) :
    print ("arclatestnoofentry = ", flags.arclatestnoofentry)
    if flags.arclatestnoofentry[0] > 1 :
      checkinDict = { 'archivename' : 'archivelatestnews',
         'category_name' : 'latestnews',
         'firebasetable_name' : 'latestnewstable',
         'pagearchivetable_name' : 'pagearchivelatestnews',
         'paginationtable_name' : 'pagination'
         }
      table_ref = db.reference().child(checkinDict['firebasetable_name'])
      tableFirstNoofEntry_ref = table_ref.child('noofentry')
      tableSecondNoofEntry_ref = table_ref.child(checkinDict['archivename']).child('noofentry')
      print ("firstlevel  before noofentry", tableFirstNoofEntry_ref.get())
      print ("secondlevel  before noofentry", tableSecondNoofEntry_ref.get())
      tableSecond_ref = table_ref.child(checkinDict['archivename'])
      table_ref.update({ 'noofentry' : flags.arclatestnoofentry[0] , 'lastupdatetime' : int(nowTime.timestamp())})
      tableSecond_ref.update({ 'noofentry' : flags.arclatestnoofentry[0] , 'lastupdatetime' : int(nowTime.timestamp())})
      print ("firstlevel after noofentry", tableFirstNoofEntry_ref.get())
      print ("secondlevel after noofentry", tableSecondNoofEntry_ref.get())




  if flags.createtable :
    print ("creating table")
    table_ref = db.reference().child('v2').child('articlelookuptable')
    table_ref.set({ 'noofentry' : 0 , 'lastupdatetime' : int(nowTime.timestamp())})
    table_ref = table_ref.child('entry')
    table_ref.set({ '0000000001ZZ0000011000' : '1csl7gLBTefdm-bNhUYWjkMkTktCerLyNnbp84OzCKwU' ,
       '0000011001ZZ0000022000' : '1Qd6Ec5d2IzGHgYSYfUNh0_bzT1QLD1eW0xfqZ5pP2_k',
       '0000022001ZZ0000033000' : '1vg3Vk4uR4weL2prZBqkVBS2PITi6UGOd0k0UlSWkat0',
       '0000033001ZZ0000044000' : '17rms2PKHcGcpJ5jHFwUSUJSuv9I2p-pOPBC2Ytu3XtI',
       '0000044001ZZ0000055000' : '11QQY63a4MwpXAzul1WTjDjAycmnLAKk135hNJqKNnh8',
       '0000055001ZZ0000066000' : '1vp4re2bAhwfvWiCwJeOXJ4lT42feOezn2hKzVjMaP1Q',
       '0000066001ZZ0000077000' : '1Yr-X8PPFDN_m4u3byk9zxwB8vsjm_OAPpz7_kzISpgs',
       '0000077001ZZ0000088000' : '1NTkWkDtZHCBMfkwGC3nxSeqjRS9XYHoO0I78F9cs-C8',
       '0000088001ZZ0000099000' : '1NJXVPomJx0wAPd6FBzHm2MHxtklVH-l8PUbguO7dVkI',
       '0000099001ZZ0000110000' : '1_H4VKYEbFXuzIL0ujEy21whJ_T7wLJA7MT9lmpIZOQg',
       '0000110001ZZ0000121000' : '11l_FgO8F19xNInHhMSPgQiVNlJJbKtGfR_157kJbKZQ',
       '0000121001ZZ0000132000' : '1SnezGUperH-03ptH1kMy9ke8obtgNCAOeoYsKHj8yd8',
       '0000132001ZZ0000143000' : '1keZglGWV37qkOytQkN3dCjIkPPIK__OCafHUkG6_-20',
       '0000143001ZZ0000154000' : '1hL4XNCXaROGq32IBiMJmWWMYRhhq_UJC15kyEzNf3MM',
       '0000154001ZZ0000165000' : '183-6KCb_MU_7wfU0ii6Y2hoK4SYTnLBfFjRcKe6BSWc',
       '0000165001ZZ0000176000' : '1O4LwZf_mD2x4xj-Nf_DgCtrKpWCxq_lkYTvjtqCMgoo',
       '0000176001ZZ0000187000' : '1vIpx7-D9QHIaGMO3I2meQE7lbMxde69f3jAUbeYs-RQ',
       '0000187001ZZ0000198000' : '15goSH3fAvuFKSyhVhX4gY1EaQ9Tu-ydk83YQTcbhyOE',
       '0000198001ZZ0000209000' : '1bWhYiY4olc_LeaC5NxWbFHz1-Ss4VxqIiVLFzHBvJE8',
       '0000209001ZZ0000220000' : '1dqQUpWB3skGXfeWUlQLBHVKMbpk9xxkOoMS-fWBfq24',
       '0000220001ZZ0000231000' : '1IdEJnhK-YkQ_QcBqNq2NcXEsITkDocHLnRDxX5jZ0G8',
       '0000231001ZZ0000242000' : '17s-sKgVqL8J980a2PZmJ4yS89Yx7xnom0t8YQ-83hzY'})


    table_ref = db.reference().child('v2').child('fragmenttable').child('entnewsarchivetable')
    table_ref.set({ 'noofentry' : 0 , 'lastupdatetime' : int(nowTime.timestamp())})
    table_ref = table_ref.child('entry')
    table_ref.set({ '0000000001ZZ0000011000' : '1Hy5ggxwsALXaa4GHqFQ71EG1eu6cHXToNRU4DOnz-Io' ,
       '0000011001ZZ0000022000' : '1O6Wl01py_9dML0pcrUyua1EMn7WQMEf-BYBWDekW3Mw',
       '0000022001ZZ0000033000' : '1Nyph_sR-7AasBxLkk164R0VN-uJAO88R1AK7ba88iPY',
       '0000033001ZZ0000044000' : '1utB1QCPuLy9HH4XUoL-qJHdYZjQKublQW046Jn0ISfI',
       '0000044001ZZ0000055000' : '1zoDL8WFOACzFOzbeq_qy3igRS1PA7mC59hlOruMKxnE',
       '0000055001ZZ0000066000' : '15rBnW4SdfnFxmYjK06A4TvpyN9A7AJ1q8qVPz60EXus',
       '0000066001ZZ0000077000' : '1cPZUhajergxUtwrwbEdgUM34BRa-MNE6Ft4dDiDvkiE',
       '0000077001ZZ0000088000' : '15H4D7eRm8MWWBagkhiI-bx6TiIf3yoW5HQGLac6UUzY',
       '0000088001ZZ0000099000' : '1zJ7j11ZIeLTNubW_dtUsxt_tE95N1KQpox81e-WGMmA',
       '0000099001ZZ0000110000' : '1XJQihiepVOt5RbUeYncR7eq6uNOILc9tczEhqzbPD-I'  })

    table_ref = db.reference().child('v2').child('fragmenttable').child('entnewstable')
    table_ref.set({ 'noofentry' : 0 , 'lastupdatetime' : int(nowTime.timestamp())})
    table_ref = table_ref.child('entry')
    table_ref.set({ '0000000001ZZ0000011000' : '1uV2MCX8UMyemPzmKg4uG6KIiK28JLt602AOeddnaaLQ' ,
       '0000011001ZZ0000022000' : '1zIPFdhJeoPOqricwfuOiaCFuzQZi7utJujp0T0L5WB4',
       '0000022001ZZ0000033000' : '1Ts1pdu4zhACB5sPDCa-T2_Im8UU_C8fcwAmpbTYEfG8',
       '0000033001ZZ0000044000' : '12czA1jdVZAmKbht0qE76iAcz9EC0t2I2i9wIONqUAQA',
       '0000044001ZZ0000055000' : '1JCAIkd1zr2YGP52TjnB3y6XKWS6b2P-NB3t8mHekHqo',
       '0000055001ZZ0000066000' : '1AIM4aNSKZzQulDM_a7vVFrAxpA0wGD3Ns1C47YHR9GU',
       '0000066001ZZ0000077000' : '1ztG6mjeU6KVX2MyRqo3YQI5jn01GY57KRXKfZaxG-q0',
       '0000077001ZZ0000088000' : '1pdc9tGvh-lRB9XraRznO7aGHMQHaESSx4nKqQniBGNo',
       '0000088001ZZ0000099000' : '1V946-P5n51xQNW-qgzstCk_dXnuxSlQ5QV0pcGDzDw0',
       '0000099001ZZ0000110000' : '1ksB-2iEuBbA8R-89PbVn6P7eLG0nJgjFIXzKbyeZt2A'  })

    table_ref = db.reference().child('v2').child('fragmenttable').child('finlatestnewsarchivetable')
    table_ref.set({ 'noofentry' : 0 , 'lastupdatetime' : int(nowTime.timestamp())})
    table_ref = table_ref.child('entry')
    table_ref.set({ '0000000001ZZ0000011000' : '1ZthaohjoeVjzv9JqjNxlHjYJTiNIJAkD3MzVvXnOXn8' ,
       '0000011001ZZ0000022000' : '1YVpjZFgWEW0tllpK0q3J0-eU905vKLTDdpHZxXVCxYA',
       '0000022001ZZ0000033000' : '139eKfr0NcPU8uW0nthHIqTT56A_mK7tyJz6wQL0ulCo',
       '0000033001ZZ0000044000' : '1JeqV7MIigyYO2ItErqHZPezVKHR2rw17ooGCV5ENg7A',
       '0000044001ZZ0000055000' : '1KQdVb74znUZG-JnAJtMSdFnfiYtYR7_KKlxeSo9KjwI',
       '0000055001ZZ0000066000' : '1Yz3YKOVhs3H-55Q06VgNjtfgMeu_rnFiP70WhcWWheY',
       '0000066001ZZ0000077000' : '1umNTUd0zib7blgnyVg1fbc7qrb3T_rilpHE8Bxk6eOA',
       '0000077001ZZ0000088000' : '1T6laXpQEItU6WIsPUrmph8x7camrWjhC1Rs0HUj0VL4',
       '0000088001ZZ0000099000' : '1EeCCKkikOm1HuP4CLxPIZbwvp2Dcq0SyO6vOXXbjwv8',
       '0000099001ZZ0000110000' : '1ITQ_NvyBu6aEj5uY-KYI2OOU7zNM85XMG-1khVrYLOE'  })

    table_ref = db.reference().child('v2').child('fragmenttable').child('finlatestnewstable')
    table_ref.set({ 'noofentry' : 0 , 'lastupdatetime' : int(nowTime.timestamp())})
    table_ref = table_ref.child('entry')
    table_ref.set({ '0000000001ZZ0000011000' : '1fIlrHViIUzkZeyhMJQw7pKJeBbR98NnLFPOyoKIbBac' ,
       '0000011001ZZ0000022000' : '1leXXKz9s8qKcf_7iLefhbQnCHIEdIZ7nMnylpW0_TqM',
       '0000022001ZZ0000033000' : '1FJ-V-pyKTINhJkBdR-7q4EIO3nBqU1_r_SihZiAomWU',
       '0000033001ZZ0000044000' : '1VlVwI9JgdZaJ1Z2NddDC2WH7rx_cu3F4RCVCykHSeu8',
       '0000044001ZZ0000055000' : '1MEz9PZl57o5efDQXM4stwdnrYFh8QRgGGcsAh7T3KpI',
       '0000055001ZZ0000066000' : '1gNYlyONtshpESsWzxpW1wtF7JgI2RDe0scDhpLCvxAo',
       '0000066001ZZ0000077000' : '1-bW39rUYVS84Q6HDMsE-fdTDEC0qMd6xgE2M0q8vSDs',
       '0000077001ZZ0000088000' : '1A8EQkHIRauvFHgMLOpWxjVJorImN2k1MoeJ2JUopW0Q',
       '0000088001ZZ0000099000' : '1nZ1LgMfzQnNHT-6SIA-QdjSvtCSOkMCiiBmSP7uXyqk',
       '0000099001ZZ0000110000' : '17sSOECFxcBDrLp_9H6OmFlnwF6axCOC5y9Jz6KBMjVk'  })

    table_ref = db.reference().child('v2').child('fragmenttable').child('finnewsarchivetable')
    table_ref.set({ 'noofentry' : 0 , 'lastupdatetime' : int(nowTime.timestamp())})
    table_ref = table_ref.child('entry')
    table_ref.set({ '0000000001ZZ0000011000' : '1zlcxsS2WRHNs7BpbSidOPoFD17-X4dZ0dOzhi1y4fN8' ,
       '0000011001ZZ0000022000' : '1IohQrlim2PfNlS_qYURj4FU0PqpuCUgQ7-1m0M3P0LI',
       '0000022001ZZ0000033000' : '1I9fxgSGCC3acSKqjx41tamvBwjY4dIc6B5Q9FyVaFcg',
       '0000033001ZZ0000044000' : '1rgyd-26XQcQnR7k1URuMPE8AWpIwjhipqXUoZg8fMPk',
       '0000044001ZZ0000055000' : '1li9p9meUmTBnZjPZaFLjAjMH78I5U9lDxt-I5FHgA1k',
       '0000055001ZZ0000066000' : '1EmJAII8o1mPoQYSp2un-uT3igzoDwp796qyUpZatyKY',
       '0000066001ZZ0000077000' : '1NFZ4X2mp65ggnqUz0FROK1o0rHyMSv3WxWLXgnYtvUk',
       '0000077001ZZ0000088000' : '134Vq2qClhv3rJgSq-bw6G3hE5jy8z_raCHx9RBsfS2A',
       '0000088001ZZ0000099000' : '1O36vL0dpHDJa97A4BUI-4acGJnzBkNenJq9COWrZEAo',
       '0000099001ZZ0000110000' : '1MV0vq_fE2p0-wk6ReavRjMezW91oeO_Uk-SrlKYVcdM'  })

    table_ref = db.reference().child('v2').child('fragmenttable').child('finnewstable')
    table_ref.set({ 'noofentry' : 0 , 'lastupdatetime' : int(nowTime.timestamp())})
    table_ref = table_ref.child('entry')
    table_ref.set({ '0000000001ZZ0000011000' : '1hDvjyVKWkFRnrWKYqW9B2IZW6C5XgBMwUrT63929hQE' ,
       '0000011001ZZ0000022000' : '13j1p1Kx5PWvwYEAUawuunw-9i1DmO5MV4dWlBHlxFBs',
       '0000022001ZZ0000033000' : '1VyParmtj3YJjjlZS9xhu7CGI5Qe-giG6a5a68H442ZY',
       '0000033001ZZ0000044000' : '1IBx-b_Vieor1viYQnirxmyGzwKdq0rWd3tPLCbvofOw',
       '0000044001ZZ0000055000' : '1A7jTM7PedQk5noQUk3rihUaXWfq9rLsO0r9xZOdnBPQ',
       '0000055001ZZ0000066000' : '1oqXlIrMl_VUl9GHRJD5NXdsiCWRVeF3WDkFfTiirP3U',
       '0000066001ZZ0000077000' : '1bL3ZGYMPBi15k5_NEBvEYeYNIRhx0XgR1jYuhiDmPpM',
       '0000077001ZZ0000088000' : '1355Adz3T2lDc-LO4pt4WXDOrBG387jUCDMEGDqwpNx8',
       '0000088001ZZ0000099000' : '1w36-DqY39XeiEWVnPzpAGAsuW67Dk_00TFo45ftJnKo',
       '0000099001ZZ0000110000' : '1DyY2tJaIF2hWD4WRypdSzIMLG9wq8H7v-gp7ZInt14I'  })

    table_ref = db.reference().child('v2').child('fragmenttable').child('hknewsarchivetable')
    table_ref.set({ 'noofentry' : 0 , 'lastupdatetime' : int(nowTime.timestamp())})
    table_ref = table_ref.child('entry')
    table_ref.set({ '0000000001ZZ0000011000' : '' ,
       '0000011001ZZ0000022000' : '',
       '0000022001ZZ0000033000' : '19lxYfP4bMeREgg1RDIxJPDjiIU3mjnRvcrHK2g2n3dg',
       '0000033001ZZ0000044000' : '1uFhT6IfY0-9ztxOkEnlEf3jib4s12oR5ztyzJdOgJmw',
       '0000044001ZZ0000055000' : '1IFXoDmlb2TBaXnrYSJNKa_amwpKnb8kdSYZqor9Mzf0',
       '0000055001ZZ0000066000' : '1qJrjUGZYJIv53MqxEIx_SeBQQGvFRMIGghAiMCcmaEU',
       '0000066001ZZ0000077000' : '1qH7-XKYOZp4uIKiCRClplhi2-fJKxihEBgYlxEKE1JQ',
       '0000077001ZZ0000088000' : '1bs9Me_3UAeFD9LXaUUDABEncDyg17njqxPmw3wyH5H4',
       '0000088001ZZ0000099000' : '1CYVpeHKjholi8wPHLItZv5JPRLph8gxQ5jpzbd6VubU',
       '0000099001ZZ0000110000' : '1tQsI1cWbp6xk227bVY18u3hK8bDeWHgW1PREZ5pFt6o'  })

    table_ref = db.reference().child('v2').child('fragmenttable').child('hknewstable')
    table_ref.set({ 'noofentry' : 0 , 'lastupdatetime' : int(nowTime.timestamp())})
    table_ref = table_ref.child('entry')
    table_ref.set({ '0000000001ZZ0000011000' : '1u3t4NCTp_5jqkdQRzep8c3oTWpPidBDcFIF_8OXvG3I' ,
       '0000011001ZZ0000022000' : '1FcugQdhK912n0Ls9NFjj5I5Gyj0hJQd7GmzRFrFS2oI',
       '0000022001ZZ0000033000' : '1JXTEebPJXvgHNNOAAk0l3iNBTBSxwy5MswUErFAmFt0',
       '0000033001ZZ0000044000' : '1WfJuKiunyQW-IXbeGex_0syVv_X4YNdo7Fn9Bte0xy4',
       '0000044001ZZ0000055000' : '1t7rbmVQDztf-C2CPTDaEf7JQIqh7x-rTFubwLgIfhAI',
       '0000055001ZZ0000066000' : '1HAAYlgSKzdnfUGDi6SDSq1sCb7P-OcrkGl02FSNBjcI',
       '0000066001ZZ0000077000' : '1w4TBi2J-_5gpXuh1UZrVEuZS6Qsdg2ADD11s8TG6kYU',
       '0000077001ZZ0000088000' : '1OM2eAvWixhU9M07i2cXz1ez2iq5ORZNU6VvVWSr8bq4',
       '0000088001ZZ0000099000' : '1-3s1AjaugDwr9MxEHHNaj3qslxhdIM8E2Z3lI5XcDbU',
       '0000099001ZZ0000110000' : '1PMR0M4AOwy7Kbo98hEAOrHJbddc-DjDRu4dxF_AKvlw'  })

    table_ref = db.reference().child('v2').child('fragmenttable').child('sportsnewsarchivetable')
    table_ref.set({ 'noofentry' : 0 , 'lastupdatetime' : int(nowTime.timestamp())})
    table_ref = table_ref.child('entry')
    table_ref.set({ '0000000001ZZ0000011000' : '1ROFMM-Him1cQZ5HsjrcBcGGUkP6lDpKhv1Yvt5NRMH4' ,
       '0000011001ZZ0000022000' : '1QZbQKfDVEMjtwF2xOePPsWuVqemYxSxJx_fyXzCY68w',
       '0000022001ZZ0000033000' : '1arFYJeOkLk5m7lVXT_L_JSCYbnN61TLSTja7a-lZd9c',
       '0000033001ZZ0000044000' : '1yZUvdfV-j4wjmCgr_4yvVwWUIpFBuDSwLhJMT5zh7ak',
       '0000044001ZZ0000055000' : '16uVbz7PHFg24eDw2SEvk2EzTfC6ZjY2eVJH2aJsq1_k',
       '0000055001ZZ0000066000' : '1KhAomVhKvReK3GMAwwCLWo3X9EWaKtqTJf2WA34849w',
       '0000066001ZZ0000077000' : '19Wb40OCMAyHmleNwUJusG1JTp6t96zcIaZmAo8H0K-8',
       '0000077001ZZ0000088000' : '1BRRNczB1xweIHmJ0sdVmNbHNzbrSEiOVSg_N4vc7dK8',
       '0000088001ZZ0000099000' : '1_uRsI_QO_MfVVro74cFQChWu1wQxmO49WacKl4Z8-BY',
       '0000099001ZZ0000110000' : '1cz5FlxX8S4qAw9pPl1Jt0OoYwVyYE5DfimDhQu3mmgk'  })

    table_ref = db.reference().child('v2').child('fragmenttable').child('sportsnewstable')
    table_ref.set({ 'noofentry' : 0 , 'lastupdatetime' : int(nowTime.timestamp())})
    table_ref = table_ref.child('entry')
    table_ref.set({ '0000000001ZZ0000011000' : '1sLR9rGY1lZNd1G2fSHFEpnp8gRqC6ULLJXfiNRO5DFo' ,
       '0000011001ZZ0000022000' : '1iUYqfoBJMbVECx_xJVdlPUfXcGvIfANqSuM9eluIA1Y',
       '0000022001ZZ0000033000' : '15LlGaeoDrgtn1xww59YEw-Obt1lCo4Og00kd4qGZY0s',
       '0000033001ZZ0000044000' : '1ookaHM52Ivf5MUg_VEBMpwyQ1PtmThKS9xKiNwFDA1k',
       '0000044001ZZ0000055000' : '1z2srdG3lS3dyRdi6XfQBMd3jvTvE0emi4U_cSM2KiBA',
       '0000055001ZZ0000066000' : '1JCvFLBxVK3ABX81EHtOpX7gLtv-rKjJ6cdP-EtRVnS8',
       '0000066001ZZ0000077000' : '1xNZgiTrrlqrb2I_Y1AcO6wIHUaTpTqtldGTY5mimbG0',
       '0000077001ZZ0000088000' : '1KPmdODPIK2J23ncX_iL-tUkzPt3qk-JRQnyGn3YgP7g',
       '0000088001ZZ0000099000' : '1iqPm5jEzFebAdnIvg89C-FCtf2q4FoIL2eKoiZVyLfY',
       '0000099001ZZ0000110000' : '1s0ym4xNzA68e3IH0U6KYoPymIjKfy19kYSDVMzj_-ro'  })












    table_ref = db.reference().child('v2').child('latestnewstable').child('archivelatestnews')
    table_ref.set({ 'noofentry' : 0 , 'lastupdatetime' : int(nowTime.timestamp())})
    table_ref = table_ref.child('entry')
    table_ref.set({ '0000000001ZZ0000011000' : '16PLWtBLsJgmOoetcEqM5N6Elu272QPo-X6RKY4zNtnw' ,
       '0000011001ZZ0000022000' : '1yJaCVffykdubzen5Kmn-uInGpTJGQiDtpl9uOFhCaKk',
       '0000022001ZZ0000033000' : '1kqWP9NUE59kkwqtlliZuoSVKhl14Ttk25bq6WG_5_Vw',
       '0000033001ZZ0000044000' : '1TZ_Y8EU5GDVOPMTZVcSIoeivvW0sSQpS8rAKQMQRXKk',
       '0000044001ZZ0000055000' : '1bultBjALtmfGI2pIG3Da7emyPxTCg-DrJDV8eC8DQhY',
       '0000055001ZZ0000066000' : '1gZmW7mx61c60RKoR-JKeqpNMzctSqTAuyRvWK-BCn_k',
       '0000066001ZZ0000077000' : '1s9xtZaTzXxqSVVRMs7M6xtcW_EJLOA4D4Bz-jEhba3U',
       '0000077001ZZ0000088000' : '1ERfJMGfVezHZRom0-xLaqDxmrhgxzI3ghhOx2neSEkE',
       '0000088001ZZ0000099000' : '16qRSNGIO3Kp51QtqCbW2wMplOUpGsD0rVZyhsSGyvWY',
       '0000099001ZZ0000110000' : '1k4N_L_tHO65E2tejB-qHrqZBsz4Sv0oQ0qiXPEikggs',
       '0000110001ZZ0000121000' : '1JTwIbD1aBpQJ3YoXTm6LBYdUtLVLgreXeRmaM2EZdWs',
       '0000121001ZZ0000132000' : '14WsJkSHrfjjvzHxAy1z3v89BuwyV9qaBv_bQ2fkue-A',
       '0000132001ZZ0000143000' : '1mxTVjxtZa_kQWK583c49VfKZ3iQTk3RzRuxOFuzsRhI',
       '0000143001ZZ0000154000' : '1O8S4d274dhjkDX0Wb-GR6cqwXN192g2JiKH2dyNrsec',
       '0000154001ZZ0000165000' : '1ywK_QZSvi78fwcIJKC5XQJNUK1VettVG2o00k8_ohn0',
       '0000165001ZZ0000176000' : '1HOFZsnhWiC4s5QCP4pfu8B2Gf5625gLn9EWiYhHIWLM',
       '0000176001ZZ0000187000' : '1CVOuxbXYErEcCMnEhwGkyyxe5hEEgSvcuCGUztF1q1M',
       '0000187001ZZ0000198000' : '1ovAsO2nK7Zw5M9Y0p1sVZYUtgqvaRP_s36ROS4-NpsA',
       '0000198001ZZ0000209000' : '1gzCNzzmk7cpsjX9bLTuciZtJyEAM8OzHJ9N-a8gN8SM'  })



    table_ref = db.reference().child('v2').child('latestnewstable').child('pagearchivelatestnews')
    table_ref.set({ 'noofentry' : 0 , 'lastupdatetime' : int(nowTime.timestamp())})
    table_ref = table_ref.child('entry')
    table_ref.set({ '0000000001ZZ0000011000' : '1A_5FmlziOg_ytXZjve1zZVGz4xFatmuRqz00YhtZpl0' ,
       '0000011001ZZ0000022000' : '1fuaHSTicic9LslPqaxowJrKyTxRihGnhGZYGrqbJsFE',
       '0000022001ZZ0000033000' : '1Of8dXhnS1sg40erZLVSTeOyGYAaGtnSwbuMh0wSU5qg',
       '0000033001ZZ0000044000' : '1gNb3C-__f-7dPidlzRnIM3c1M-fz_rYcauZaZ4sZBac',
       '0000044001ZZ0000055000' : '1K3y1Cwav-bqt96QRHSCSwp0xxM4zM7belcss_2mkoyw',
       '0000055001ZZ0000066000' : '1EKdAEamHdrnnumDKqT5eZhT0rxXR_FUibeN1LlkVRL0',
       '0000066001ZZ0000077000' : '14RujbP6WbZqomAZzfywocgJidQIrStzFZTNZTG_r6V0',
       '0000077001ZZ0000088000' : '14gQLkSa5esXIcwBnBOpL2b1SK_VvEBVpfURdwcy36po',
       '0000088001ZZ0000099000' : '1lGDyZ-HLF72dWmm1X3MV18hMnOleBsiVcG6bB7_Ey48',
       '0000099001ZZ0000110000' : '1Tw11wBMhHAKqDKELLvXWJ_ZvFA9hwLpJIWNDcetX550',
       '0000110001ZZ0000121000' : '1ySjiwTHhSAluBAAyVSZRyDQJR54f7KqJr_uoP-kK3qo',
       '0000121001ZZ0000132000' : '1m1E9uDzP9mG2IpxaFDgF2hIQUW8lpqTc9OKIeYSkAJ4',
       '0000132001ZZ0000143000' : '1zcr9kj30akwn0ub0NVHGsIfsrN0aNGFL8zZKO6m4JlE'})



    #   '0000143001ZZ0000154000' : '',
    #   '0000154001ZZ0000165000' : '',
    #   '0000165001ZZ0000176000' : '',
    #   '0000176001ZZ0000187000' : '',
    #   '0000187001ZZ0000198000' : '',
    #   '0000198001ZZ0000209000' : '',
    #   '0000209001ZZ0000220000' : '',
    #   '0000220001ZZ0000231000' : '',
    #   '0000022001ZZ0000033000' : '' })
    table_ref = db.reference().child('v2').child('entitytable').child('0000000何君堯ZZ0000000119')
    table_ref.set({ 'noofentry' : 0 ,
       'sourceiconurl' : 'https://gdb.voanews.com/A0265A9A-396D-4EE4-BFD1-74E853DEEC72_w250_r0_s.jpg',
       'lastupdatetime' : int(nowTime.timestamp())})
    table_ref = table_ref.child('entry')
    table_ref.set({ '0000000001ZZ0000011000' : '1mqKLOrblp0Z2Y7XtptJW7Pwemv_-l2yc9jfa5VU6LoE' ,
       '0000011001ZZ0000022000' : '1EmKLIpfUS98prWNPDO2Yg6DSGXJ6jJcMA2sSdHSYu2Q',
       '0000022001ZZ0000033000' : '1KuogtAyGM5WqjW6JhGzamY1xpT2VuzkJuKSCm2ksDIc' })

    table_ref = db.reference().child('v2').child('entitytable').child('0000000劉怡翔ZZ0000000009')
    table_ref.set({ 'noofentry' : 0 ,
       'sourceiconurl' : 'https://www.gov.hk/en/about/govdirectory/po/images/Mr-James-Henry-Lau-Jr.jpg',
       'lastupdatetime' : int(nowTime.timestamp())})
    table_ref = table_ref.child('entry')
    table_ref.set({ '0000000001ZZ0000011000' : '1ix7caUPUUHw6CaEu6q3gtjofQjgOt7LtahjqpPEVZ-g' ,
       '0000011001ZZ0000022000' : '1LUQyuz9nuwLfoR4sd84m7KEEO2-lsHJlQG6YuW5si8I',
       '0000022001ZZ0000033000' : '1k2J0UFCxoddxnE_rEnIlfekXxhow6PNLwWEW9GTnsHg' })

    table_ref = db.reference().child('v2').child('entitytable').child('0000000張建宗ZZ0000000014')
    table_ref.set({ 'noofentry' : 0 ,
       'sourceiconurl' : 'https://www.gov.hk/en/about/govdirectory/po/images/matthew_cheung.jpg',
       'lastupdatetime' : int(nowTime.timestamp())})
    table_ref = table_ref.child('entry')
    table_ref.set({ '0000000001ZZ0000011000' : '14wJP8qJiGvbu9adinqJDUxHHnXRo98z1sBkBPacmgDc' ,
       '0000011001ZZ0000022000' : '1tXWlZny1-ah_Xsk0F3hnhfm09k-fqyssDAn5_gDLL5w',
       '0000022001ZZ0000033000' : '1QY-W080Vh5uoCN8IRScJmMve8OwYHN8uxAzOei62T0U' })

    table_ref = db.reference().child('v2').child('entitytable').child('0000000朱凱迪ZZ0000000091')
    table_ref.set({ 'noofentry' : 0 ,
       'sourceiconurl' : 'https://gdb.voanews.com/7D954E9A-74B7-4856-A16E-0FB833A14119_w650_r0_s.jpg',
       'lastupdatetime' : int(nowTime.timestamp())})
    table_ref = table_ref.child('entry')
    table_ref.set({ '0000000001ZZ0000011000' : '1CccMkyPYrqJcQ3bLP1exAwI1x9ttgqwDFYvbeqGjiKs' ,
       '0000011001ZZ0000022000' : '1p2ufT08WObVgpuGgWBfbVonlgYIEJkZxriBdcAJxEeI',
       '0000022001ZZ0000033000' : '1qrotnrm18pXYbl74Q0F94j_zm9xGpEiTYf_y-WOlNSk' })

    table_ref = db.reference().child('v2').child('entitytable').child('0000000林卓廷ZZ0000000242')
    table_ref.set({ 'noofentry' : 0 ,
       'sourceiconurl' : 'http://newsstatic.rthk.hk/images/mfile_1336695_1_L_20170617214235.jpg',
       'lastupdatetime' : int(nowTime.timestamp())})
    table_ref = table_ref.child('entry')
    table_ref.set({ '0000000001ZZ0000011000' : '1Y_vaJdqZ2CDfMsdTADny_H8PDhYahiRxs1DUIsx6alk' ,
       '0000011001ZZ0000022000' : '1A_q7thtJ_tllKTpLXMSB5ZMz0qgPwyYR_4zNPtxnbko',
       '0000022001ZZ0000033000' : '1qxF5ks07lDyIiJY9PhUiuJv25i2OoVKTKewbe-gqCC0' })

    table_ref = db.reference().child('v2').child('entitytable').child('0000000梁君彥ZZ0000000337')
    table_ref.set({ 'noofentry' : 0 ,
       'sourceiconurl' : 'https://gdb.voanews.com/6790B6C2-FBF2-44EF-9CD5-D2DF8F722428_w250_r1_s.jpg',
       'lastupdatetime' : int(nowTime.timestamp())})
    table_ref = table_ref.child('entry')
    table_ref.set({ '0000000001ZZ0000011000' : '1PIWSvgoYQFvRajpuJDBWusoUpYD5dt7oekONSxhbSUQ' ,
       '0000011001ZZ0000022000' : '1baDXn99C9GOam_CytnTN6mZo0TJxpWljUb3tNpVkxgs',
       '0000022001ZZ0000033000' : '1GQmF-dTTStqYiMJQ9PpN6tV0sSjUwM-_YG-PTCQ0Ko8' })

    table_ref = db.reference().child('v2').child('entitytable').child('0000000楊岳橋ZZ0000000109')
    table_ref.set({ 'noofentry' : 0 ,
       'sourceiconurl' : 'https://gdb.voanews.com/9763DDC0-8D9C-4C6B-9069-3FA091FC7E2C_w250_r0_s.jpg',
       'lastupdatetime' : int(nowTime.timestamp())})
    table_ref = table_ref.child('entry')
    table_ref.set({ '0000000001ZZ0000011000' : '1x2qBGL15tl2N3vXqLGp1m0zKxiD1z-KsJ-dcRWV5ezk' ,
       '0000011001ZZ0000022000' : '1bm_Wq4IoFwxOnSuXFqbg_mtTrs6B_3MmrQ9NpcXaKuQ',
       '0000022001ZZ0000033000' : '1J3_FMEXXzs7sWazP3Ms3ExSxcJCqO53bEPGS313ZNPU' })

    table_ref = db.reference().child('v2').child('entitytable').child('0000000楊潤雄ZZ0000000078')
    table_ref.set({ 'noofentry' : 0 ,
       'sourceiconurl' : 'https://www.gov.hk/en/about/govdirectory/po/images/Mr-Kevin-Yeung-Yun-hung.jpg',
       'lastupdatetime' : int(nowTime.timestamp())})
    table_ref = table_ref.child('entry')
    table_ref.set({ '0000000001ZZ0000011000' : '1Rw6DqZWnwxOLxmMCcp4DNtrNgM5wLXierHqHGqRxGIs' ,
       '0000011001ZZ0000022000' : '1kBlh1aeKNqOzzUInLRH8hrr2ai0z1-HBHMmhE7OvDiE',
       '0000022001ZZ0000033000' : '1ji9dXwMojxo4tJZsiciOl19G340CArrqNUFQsPVoaxs' })

    table_ref = db.reference().child('v2').child('entitytable').child('0000000涂謹申ZZ0000000067')
    table_ref.set({ 'noofentry' : 0 ,
       'sourceiconurl' : 'http://newsstatic.rthk.hk/images/mfile_1339731_1_L_20170703114048.jpg',
       'lastupdatetime' : int(nowTime.timestamp())})
    table_ref = table_ref.child('entry')
    table_ref.set({ '0000000001ZZ0000011000' : '18jHhW0jLk1nDFunbe9zfmd3w89GeoEv21AAK2cOT0mU' ,
       '0000011001ZZ0000022000' : '1ijI4WGgll24X2XuE4kTP46cf-GozFniBevkvGBytYas',
       '0000022001ZZ0000033000' : '1O1tpIJKtGWGnaon0dYcbIpTt9CT0g-ivjVvwRJ7pRmc' })

    table_ref = db.reference().child('v2').child('entitytable').child('0000000羅致光ZZ0000000082')
    table_ref.set({ 'noofentry' : 0 ,
       'sourceiconurl' : 'https://www.gov.hk/en/about/govdirectory/po/images/Mr-Law-Chi-kwong.jpg',
       'lastupdatetime' : int(nowTime.timestamp())})
    table_ref = table_ref.child('entry')
    table_ref.set({ '0000000001ZZ0000011000' : '1IP6zBErJFcNt6jr_d0Zd00SbzIWAwVhcETP1Utmq33M' ,
       '0000011001ZZ0000022000' : '1tQ-c8g6-vq53WAiXbVVG1vAO7K1Jn-z0a81YqCzLyUk',
       '0000022001ZZ0000033000' : '1ubqowmZBpr_RCiC-gnS0vdcgVaaRry6D934-FNI-lTE' })

    table_ref = db.reference().child('v2').child('entitytable').child('0000000胡志偉ZZ0000000099')
    table_ref.set({ 'noofentry' : 0 ,
       'sourceiconurl' : 'https://gdb.voanews.com/A1D0F548-34F1-4772-B674-EE44E249645D_w650_r0_s.jpg',
       'lastupdatetime' : int(nowTime.timestamp())})
    table_ref = table_ref.child('entry')
    table_ref.set({ '0000000001ZZ0000011000' : '1Q9oZTpYb1Np0dArzGSGiz7aCqLv1O9fnq4HB5toc9eU' ,
       '0000011001ZZ0000022000' : '1JntTAf_eGmvg0y5TPgMyJ481K6-wLlNfpiOEuw5Gwz4',
       '0000022001ZZ0000033000' : '15wUy9m2KiF5x550blEvQFyHA6wNXowcf5jKUhPC4uaY' })

    table_ref = db.reference().child('v2').child('entitytable').child('0000000袁國強ZZ0000000215')
    table_ref.set({ 'noofentry' : 0 ,
       'sourceiconurl' : 'https://upload.wikimedia.org/wikipedia/commons/thumb/0/0d/%E8%A2%81%E5%9C%8B%E5%BC%B7.jpg/800px-%E8%A2%81%E5%9C%8B%E5%BC%B7.jpg',
       'lastupdatetime' : int(nowTime.timestamp())})
    table_ref = table_ref.child('entry')
    table_ref.set({ '0000000001ZZ0000011000' : '1VS4YCmEc5bDw8BN1PMpgn8ifajtjhwFkFK6gH8ntFbg' ,
       '0000011001ZZ0000022000' : '1e2ZGWkbcLtmMBNAvjFrR_0yKyyYnyhfm-xSNeeozafU',
       '0000022001ZZ0000033000' : '1DnVAwS23Cq4uNvb12wnL03azED2jxGfdcP6nBNLVKvQ' })

    table_ref = db.reference().child('v2').child('entitytable').child('0000000許智峯ZZ0000000112')
    table_ref.set({ 'noofentry' : 0 ,
       'sourceiconurl' : 'http://newsstatic.rthk.hk/images/mfile_1362107_1_L_20171030193126.jpg',
       'lastupdatetime' : int(nowTime.timestamp())})
    table_ref = table_ref.child('entry')
    table_ref.set({ '0000000001ZZ0000011000' : '1DkrrTGAVzjQRRtQxJhL5ZOrwQipAbInjLa8EplE4Pms' ,
       '0000011001ZZ0000022000' : '1rn5s8HmIwK6H-GwrfIYhIv06moTlNgmUAxiw_HHZhxY',
       '0000022001ZZ0000033000' : '1WN36XyNKscipLZg4zkY7iN4igMBltP1amP6Cm6M1bN4' })

    table_ref = db.reference().child('v2').child('entitytable').child('0000000謝偉俊ZZ0000000059')
    table_ref.set({ 'noofentry' : 0 ,
       'sourceiconurl' : 'http://image.wenweipo.com/2016/10/16/a03c.jpg',
       'lastupdatetime' : int(nowTime.timestamp())})
    table_ref = table_ref.child('entry')
    table_ref.set({ '0000000001ZZ0000011000' : '15QXdAsd-O9EWsarcLvKWJtIqj9Jss2w8lrQbMcL0N4s' ,
       '0000011001ZZ0000022000' : '1t0LWRvAKANbIe_suuqe0e_TBikP-cwwd3vOo2v-dZ9Q',
       '0000022001ZZ0000033000' : '1ksg9mkvenPnp2yPdZJMjow9NOYxz-C0EuFIeVVEJ3ek' })

    table_ref = db.reference().child('v2').child('entitytable').child('0000000邱騰華ZZ0000000338')
    table_ref.set({ 'noofentry' : 0 ,
       'sourceiconurl' : 'https://www.gov.hk/en/about/govdirectory/po/images/Mr-Edward-Yau-Tang-wah.jpg',
       'lastupdatetime' : int(nowTime.timestamp())})
    table_ref = table_ref.child('entry')
    table_ref.set({ '0000000001ZZ0000011000' : '1U_k1d2_2QFkoK_AbsKRE5t37j8E5u_9y-OAuEC9cUsA' ,
       '0000011001ZZ0000022000' : '14AC5DZWFfGgvoZJBlB2rm_VtN6YhnIR_TFg5L9FZYKQ',
       '0000022001ZZ0000033000' : '1Tc5Ib6RLLbdTULtEe87EZlASQAAODVfYKOcJ8gAUQqs' })

    table_ref = db.reference().child('v2').child('entitytable').child('0000000郭家麒ZZ0000000077')
    table_ref.set({ 'noofentry' : 0 ,
       'sourceiconurl' : 'https://upload.wikimedia.org/wikipedia/commons/thumb/8/8e/Kwok_Ka-ki_in_2016.jpg/400px-Kwok_Ka-ki_in_2016.jpg',
       'lastupdatetime' : int(nowTime.timestamp())})
    table_ref = table_ref.child('entry')
    table_ref.set({ '0000000001ZZ0000011000' : '1GQ6Uy_x22ywQgHwj5a5-vNtxeaMqz3MIeU7nBiACr_4' ,
       '0000011001ZZ0000022000' : '1yFr4C4FK2UP-vlQFblzOzYwR8esJjgqpQUI7WdLzZwE',
       '0000022001ZZ0000033000' : '1uLVbt9buDxCVKHn1y-oeoeRBnTA17AshXUYCh6ON234' })

    table_ref = db.reference().child('v2').child('entitytable').child('0000000鄭松泰ZZ0000000336')
    table_ref.set({ 'noofentry' : 0 ,
       'sourceiconurl' : 'https://gdb.voanews.com/613729FC-A742-4A9D-AC15-F23399C391CE_w250_r1_s.jpg',
       'lastupdatetime' : int(nowTime.timestamp())})
    table_ref = table_ref.child('entry')
    table_ref.set({ '0000000001ZZ0000011000' : '1VvCHwjAK6_NyauvhFxPlESul4_ipL7o8ZZcZhLwpPbQ' ,
       '0000011001ZZ0000022000' : '1Nw9OPDwKSaZRFrTTodKMbiVl6vhPuN9DMhHiJHx1vq4',
       '0000022001ZZ0000033000' : '119wisvLKqG_NO7XnPs3_XotMz3fbqrd9BnMmVOboimg' })

    table_ref = db.reference().child('v2').child('entitytable').child('0000000鄭若驊ZZ0000000339')
    table_ref.set({ 'noofentry' : 0 ,
       'sourceiconurl' : 'http://newsstatic.rthk.hk/images/mfile_1374468_1_L_20180110193111.jpg',
       'lastupdatetime' : int(nowTime.timestamp())})
    table_ref = table_ref.child('entry')
    table_ref.set({ '0000000001ZZ0000011000' : '1QkWd6N9Nr_TLPebEGNIwzVw4eNRwk2gMtffsUgPy3Ek' ,
       '0000011001ZZ0000022000' : '1dWg0fdESVPeO7R-JMkH0fR_DZuzhoa8-5umSLsJ2li0',
       '0000022001ZZ0000033000' : '1z6x6rxANULVH3RVyIZSZmanpLOlsDLG3TxYCkF6XAMM' })

    table_ref = db.reference().child('v2').child('entitytable').child('0000000陳健波ZZ0000000031')
    table_ref.set({ 'noofentry' : 0 ,
       'sourceiconurl' : 'http://newsstatic.rthk.hk/images/mfile_1354669_1_L_20170918153148.jpg',
       'lastupdatetime' : int(nowTime.timestamp())})
    table_ref = table_ref.child('entry')
    table_ref.set({ '0000000001ZZ0000011000' : '1xI3eNpWIbgoZW-eI4WDmElC8YFc89BL9JtwyCLBukJM' ,
       '0000011001ZZ0000022000' : '1lSyaAs45Brc9gYI1VDxqrbDbD7vtkiuaxinajLO8QG0',
       '0000022001ZZ0000033000' : '1Fd0Qr95Nb5HRrhQmhWOYOS7iIQLxyMJ_DnhtjnzR5FY' })

    table_ref = db.reference().child('v2').child('entitytable').child('0000000陳志全ZZ0000000076')
    table_ref.set({ 'noofentry' : 0 ,
       'sourceiconurl' : 'https://upload.wikimedia.org/wikipedia/commons/0/08/%E9%99%B3%E5%BF%97%E5%85%A8.jpg',
       'lastupdatetime' : int(nowTime.timestamp())})
    table_ref = table_ref.child('entry')
    table_ref.set({ '0000000001ZZ0000011000' : '1ILJMiwO8ZNhEKGA7FECKpJzbV0CtWjcxwD3XQsSTpg8' ,
       '0000011001ZZ0000022000' : '1-upV3lhXOL8yOvxY9rBYwS0vNO23yCiZy-B7UuYED8M',
       '0000022001ZZ0000033000' : '1wZTP-sIwA9y54LBKICpplonJSg9VehWc7mlo1SQH-eA' })

    table_ref = db.reference().child('v2').child('entitytable').child('0000000陳淑莊ZZ0000000312')
    table_ref.set({ 'noofentry' : 0 ,
       'sourceiconurl' : 'https://gdb.voanews.com/056904B9-95C1-44FB-B744-543CFCC3B544_w250_r1_s.jpg',
       'lastupdatetime' : int(nowTime.timestamp())})
    table_ref = table_ref.child('entry')
    table_ref.set({ '0000000001ZZ0000011000' : '1IOqPzLpJlwxeHZ1_pZ03HSDK6mon58pFjcpBvV35fTc' ,
       '0000011001ZZ0000022000' : '1wX60APkaZ5Js3Ih5MRTcNJYQihanmI6LsDXkdvhVIq4',
       '0000022001ZZ0000033000' : '1eOycYwIXZUQ5T_agab56VKdLeiDLU-kin2D4VSqty24' })

    table_ref = db.reference().child('v2').child('entitytable').child('0000000陳肇始ZZ0000000028')
    table_ref.set({ 'noofentry' : 0 ,
       'sourceiconurl' : 'https://www.gov.hk/en/about/govdirectory/po/images/Professor-Sophia-Chan-Siu-chee.jpg',
       'lastupdatetime' : int(nowTime.timestamp())})
    table_ref = table_ref.child('entry')
    table_ref.set({ '0000000001ZZ0000011000' : '1Gbhyi_Bv4gBTDE7Q2tnsLnWNZ_B9QNpgb00IhbU_Obo' ,
       '0000011001ZZ0000022000' : '1443UjtzRqQczUhXv8prwPtWsphsD75nSxpBhqDDQ7iI',
       '0000022001ZZ0000033000' : '1OYfqFyg-6w-zc6ezi7IWGEfNASd9hVP2Nu9jV8zfxoU' })

    table_ref = db.reference().child('v2').child('entitytable').child('0000000陳茂波ZZ0000000003')
    table_ref.set({ 'noofentry' : 0 ,
       'sourceiconurl' : 'http://newsstatic.rthk.hk/images/mfile_1362894_1_L_20171103185522.jpg',
       'lastupdatetime' : int(nowTime.timestamp())})
    table_ref = table_ref.child('entry')
    table_ref.set({ '0000000001ZZ0000011000' : '1MYgVHTlLgI3c9prhfVl2X9dGhtuBkdYomA6Unj4za9A' ,
       '0000011001ZZ0000022000' : '1Rsh6uABso1-grH92K2gW_ct4yhoYp_Y0hBm5ZVtIFI4',
       '0000022001ZZ0000033000' : '1NbshrjFO0mSzJa0bxazwLJ3l06WDPQP1M6taL7xd1_o' })

    table_ref = db.reference().child('v2').child('entitytable').child('0000000黃之鋒ZZ0000000128')
    table_ref.set({ 'noofentry' : 0 ,
       'sourceiconurl' : 'https://gdb.voanews.com/968EE382-5E6A-462B-94BD-067F68BCB686_w650_r1_s.jpg',
       'lastupdatetime' : int(nowTime.timestamp())})
    table_ref = table_ref.child('entry')
    table_ref.set({ '0000000001ZZ0000011000' : '1OgK3qvHTrKNTqj8USsDEmlO340fLrQV5kdp6e-dfZj4' ,
       '0000011001ZZ0000022000' : '1w-LrT5Qnd0iWvsOeduX-ZS3-dw-jsFY6-Eo3Zo5qrFM',
       '0000022001ZZ0000033000' : '1IdZISwKnMf5WKkXqVyccsr8UIvL7Ve6O5U54f2VEn9g' })

    table_ref = db.reference().child('v2').child('entitytable').child('0000000黃偉綸ZZ0000000335')
    table_ref.set({ 'noofentry' : 0 ,
       'sourceiconurl' : 'https://www.gov.hk/en/about/govdirectory/po/images/Mr-Michael-Wong-Wai-lun.jpg',
       'lastupdatetime' : int(nowTime.timestamp())})
    table_ref = table_ref.child('entry')
    table_ref.set({ '0000000001ZZ0000011000' : '1zZFKw6wagojFABOtpTl6OMTE-7sDne9DT8c8AuRROZI' ,
       '0000011001ZZ0000022000' : '1aKTmNF2BFamoGiSCOYufc5WhaNOHHQ_dCrGMB_cd5pI',
       '0000022001ZZ0000033000' : '1BXOyH0Xqs8WY38lXGcUQ2UtZCmPO75KB_McP6wcVPrI' })

    table_ref = db.reference().child('v2').child('entitytable').child('000000林鄭月娥ZZ0000000007')
    table_ref.set({ 'noofentry' : 0 ,
       'sourceiconurl' : 'https://upload.wikimedia.org/wikipedia/commons/thumb/f/fd/%E9%A6%99%E6%B8%AF%E5%80%99%E4%BB%BB%E7%89%B9%E9%A6%96%E6%9E%97%E9%84%AD%E6%9C%88%E5%A8%A513.jpg/450px-%E9%A6%99%E6%B8%AF%E5%80%99%E4%BB%BB%E7%89%B9%E9%A6%96%E6%9E%97%E9%84%AD%E6%9C%88%E5%A8%A513.jpg',
       'lastupdatetime' : int(nowTime.timestamp())})
    table_ref = table_ref.child('entry')
    table_ref.set({ '0000000001ZZ0000011000' : '15Fw5Zc7DPiPsZpKfGh2_8XgNq6bVRVsNxg5I1zycLjA' ,
       '0000011001ZZ0000022000' : '1P1QOEwVxt72qc6qrq0T4bDcKqEGhr4AeFDopRH7vwf0',
       '0000022001ZZ0000033000' : '1xX31DOhu4FuJLqxHh5qgy541D2x9nzAp7ID1rCGKAAY' })







    #table_ref = db.reference().child('v2').child('fragmenttable').child('hknewstable')
    #table_ref.set({ 'noofentry' : 0 , 'lastupdatetime' : int(nowTime.timestamp())})
    #table_ref = db.reference().child('v2').child('fragmenttable').child('hknewsarchivetable')
    #table_ref.set({ 'noofentry' : 0 , 'lastupdatetime' : int(nowTime.timestamp())})
    #table_ref = db.reference().child('v2').child('fragmenttable').child('finnewstable')
    #table_ref.set({ 'noofentry' : 0 , 'lastupdatetime' : int(nowTime.timestamp())})
    #table_ref = db.reference().child('v2').child('fragmenttable').child('finnewsarchivetable')
    #table_ref.set({ 'noofentry' : 0 , 'lastupdatetime' : int(nowTime.timestamp())})
    #table_ref = db.reference().child('fragmenttable').child('finlatestnewstable')
    #table_ref.set({ 'noofentry' : 0 , 'lastupdatetime' : int(nowTime.timestamp())})
    #table_ref = db.reference().child('v2').child('fragmenttable').child('finlatestnewsarchivetable')
    #table_ref.set({ 'noofentry' : 0 , 'lastupdatetime' : int(nowTime.timestamp())})
    
    #table_ref = db.reference().child('v2').child('fragmenttable').child('entnewstable')
    #table_ref.set({ 'noofentry' : 0 , 'lastupdatetime' : int(nowTime.timestamp())})
    #table_ref = db.reference().child('v2').child('fragmenttable').child('entnewsarchivetable')
    #table_ref.set({ 'noofentry' : 0 , 'lastupdatetime' : int(nowTime.timestamp())})
    #table_ref = db.reference().child('v2').child('fragmenttable').child('sportsnewstable')
    #table_ref.set({ 'noofentry' : 0 , 'lastupdatetime' : int(nowTime.timestamp())})
    #table_ref = db.reference().child('v2').child('fragmenttable').child('sportsnewsarchivetable')
    #table_ref.set({ 'noofentry' : 0 , 'lastupdatetime' : int(nowTime.timestamp())})

  if flags.checknoofentry :
    print ("  checknoofentry")
    table_ref = db.reference().child('latestnewstable').child('pagearchivelatestnews')
    #table_ref.update({ 'noofentry' : 32607 , 'lastupdatetime' : int(nowTime.timestamp())})
    #table_ref.update({ 'noofentry' : 32650 , 'lastupdatetime' : int(nowTime.timestamp())})
    table_ref = db.reference().child('fragmenttable').child('sportsnewstable')
    #table_ref.update({ 'noofentry' : 1460 , 'lastupdatetime' : int(nowTime.timestamp())})
    #table_ref.update({ 'noofentry' : 1441 , 'lastupdatetime' : int(nowTime.timestamp())})
    table_ref = db.reference().child('articlelookuptable')
    table_ref.update({ 'noofentry' : 99000 , 'lastupdatetime' :  1517274373 })
    #table_ref.update({ 'noofentry' : 125659 , 'lastupdatetime' : 1517274373 })

  checktime = datetime.now(timezone(timedelta(hours=8)))
  print ('checktime firebase-update-4 end', checktime)
      
     


if __name__ == '__main__':
  main()



