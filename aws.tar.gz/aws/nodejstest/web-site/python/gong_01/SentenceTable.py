
import sqlalchemy
from sqlalchemy.orm import relationship, aliased
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import Column, Integer, String, Text, Table, Boolean, DateTime
from sqlalchemy import ForeignKey
from CommonBase import Base



#Base=declarative_base()


class SentenceTable(Base):
  __tablename__ = 'sentencetable'

  #tentityTable=aliased(
  id=Column(Integer, primary_key=True)

  articletable_id = Column(Integer )

  sentencecontent=Column(Text)

  casetable_id = Column(Integer, ForeignKey('casetable.id') )
  casetable= relationship("CaseTable", back_populates="sentencetable_list", 
    foreign_keys=[casetable_id])

  activeentity_id = Column(Integer, ForeignKey('entitytable.id') )
  activeentity_table= relationship("EntityTable", 
    back_populates="activerole_list", 
    foreign_keys="SentenceTable.activeentity_id")

  passiveentity_id = Column(Integer, ForeignKey('entitytable.id') )
  passiveentity_table= relationship("EntityTable", 
    back_populates="passiverole_list", 
    foreign_keys="SentenceTable.passiveentity_id")

#  previoussentence_id=Column(Integer)
  previoussentence_id=Column(Integer, ForeignKey('sentencetable.id'))
  previoussentence=relationship( "SentenceTable", 
    foreign_keys="SentenceTable.previoussentence_id")

#  nextsentence_id=Column(Integer)
  nextsentence_id=Column(Integer, ForeignKey('sentencetable.id'))
  nextsentence=relationship( "SentenceTable", 
    foreign_keys="SentenceTable.nextsentence_id")

  tokensentencetable_list = relationship("TokenSentenceTable", 
                            back_populates='sentencetable', cascade="all, delete, delete-orphan")

  traintype= Column(Integer)


  def irepr(self):
    return "<SentenceTable(id='%d', articletable_id='%d', sentencecontent='%s', casetable_id='%d', activeentitytable_id='%d', passiveentitytable_id='%d', )>" % (self.id, 
            self.articletable_id, 
            self.sentencecontent, 
            self.casetable_id, 
            self.activeentity_id, 
            self.passiveentity_id )

  def __repr__(self):
    return "<SentenceTable(id='%s', articletable_id='%s', sentencecontent='%s', casetable_id='%s', activeentitytable_id='%s', passiveentitytable_id='%s', previoussentence_id='%s', nextsentence_id='%s' , traintype='%d')>\n" % (str(self.id), 
            str(self.articletable_id), 
            self.sentencecontent, 
            str(self.casetable_id), 
            str(self.activeentity_id), 
            str(self.passiveentity_id), 
            str(self.previoussentence_id), 
            str(self.nextsentence_id),
            str(self.traintype)
            )

