#! /usr/bin/env python3
import sys
import gensim
from gensim import corpora
import time
import json
from datetime import datetime, timedelta,timezone
from gensim import corpora, models, similarities
from collections import defaultdict
from collections import OrderedDict
import re
from gong_01_db import GongAllTable
import os
import operator
from pprint import pprint
import data_helpers
#from oauth2client import tools


nowTime = datetime.now(timezone(timedelta(hours=8)))
print ("start time for gensim = ", nowTime )


import requests
import pymongo
import boto3
import argparse

parser = argparse.ArgumentParser()
parser.add_argument('inputarg', nargs='*')
argument = parser.parse_args()

print ("argument.inputarg = " , argument.inputarg )

jobid = int(argument.inputarg[0])
mongodburl = argument.inputarg[1]
categorytable_1_id = int(argument.inputarg[2])
categorytable_2_id = 0
if len(argument.inputarg) >3 :
  categorytable_2_id = int(argument.inputarg[3])

#for now.......
#response = requests.get('http://localhost:3000/web/donegensim')
#print( "==============\n\n\n\n\n",
#  " gong_01 assignchildprocess 1.1 response.status_code",
#  response.status_code )
#time.sleep(10)
#os._exit(0)


#mongodb_client = = pymongo.MongoClient("mongodb+srv://normaluser:abcde12345@cluster0-q3gf2.mongodb.net")
mongodb_client = pymongo.MongoClient(mongodburl)
mongodb_db = mongodb_client.mongodblab
mongodb_articlecollection = mongodb_db.articlecollection

#dynamodb_client = boto3.client('dynamodb', endpoint_url='http://localhost:8000', region_name='us-east-2')
if jobid == 99999 :
  dynamodb_client = boto3.client('dynamodb',
    aws_secret_access_key='vEItH0g8VC5otwQ2Fy6zwXxpgOu2NnkLjjB854M4',
    aws_access_key_id="AKIAJWZT7VQHKKHY2BTQ",
    endpoint_url='http://localhost:8000', region_name='us-east-2')
else :
  dynamodb_client = boto3.client('dynamodb',
    aws_secret_access_key='vEItH0g8VC5otwQ2Fy6zwXxpgOu2NnkLjjB854M4',
    aws_access_key_id="AKIAJWZT7VQHKKHY2BTQ",
    region_name='us-east-2')

queryresult = dynamodb_client.list_tables()
if ( queryresult['ResponseMetadata']['HTTPStatusCode'] != 200 ) or ( \
     'articlecollection' not in queryresult['TableNames'] ):
   print(" gong_01 assignchildprocess error list_tables httpstatuscode="+
      queryresult['ResponseMetadata']['HTTPStatusCode'] )
   print(" gong_01 aws-gonggensim-sport error list_tables ="+
      queryresult['TableNames'] )
   exit(-1)

#get the data from dynamodb
def unpackAWSItem ( list_items , in_dynamodb_client, dynadelete_time ):
  resultOrderedDict=OrderedDict()
  for x in list_items :
    indDict={}

    #delete the item in dynamodb    
    """
    if delete_time >= int(x['timestampondoc']['N']) :
       in_dynamodb_client.delete_item ( Key={ 
         'categorytable_id' : {'N' : x['categorytable_id']['N'] } ,
         'id' : { 'N' : x['id']['N'] }  },
         TableName='articlecollection' )
       continue
    """

    indDict['rowid'] = int(x['rowid']['N'])
    indDict['id'] = int(x['id']['N'])
    indDict['_id'] = int(x['_id']['N'])
    indDict['firstsubdomaintable_id'] = int(x['firstsubdomaintable_id']['N'])
    indDict['finalurl'] = x['finalurl']['S']
    indDict['timestampondoc'] = datetime.fromtimestamp(int(x['timestampondoc']['N'])).replace(tzinfo=timezone(timedelta(hours=8)))
    indDict['timestamponretrieve'] = datetime.fromtimestamp(int(x['timestamponretrieve']['N'])).replace(tzinfo=timezone(timedelta(hours=8)))
    indDict['title'] = x['title']['S']
    indDict['content'] = x['content']['S']
    indDict['jpegname'] = None if 'NULL' in x['jpegname'] else x['jpegname']['S']
    indDict['imageurl'] = None if 'NULL' in x['imageurl'] else x['imageurl']['S']
    indDict['similaritieslist'] = None if 'NULL' in x['similaritieslist'] else x['similaritieslist']['S']
    indDict['similaritiescount'] = None if 'NULL' in x['similaritiescount'] else int(x['similaritiescount']['N'])
    indDict['updatetofirebase'] = None if 'NULL' in x['updatetofirebase'] else int(x['updatetofirebase']['N'])
    indDict['domaintable_id']= int(x['domaintable_id']['N'])
    indDict['categorytable_id']= int(x['categorytable_id']['N'])
    resultOrderedDict[indDict['id']] = indDict
  return resultOrderedDict

from botocore.exceptions import ClientError
RETRY_EXCEPTIONS = ('ProvisionedThroughputExceededException',
                    'ThrottlingException')

def getAWSItems ( finalqueryresult , categorytable_id) :
  endquery = True
  queryresult = {}
  sleep_retry = 1
  while (endquery) :
   try :
    if len(finalqueryresult) == 0 :
      queryresult = dynamodb_client.query( TableName='articlecollection',
        KeyConditionExpression=' id > :X1 AND categorytable_id = :X2 ',
        ExpressionAttributeValues={ ':X1' : { 'N' : '0' }, ':X2' : { "N" : str(categorytable_id)  } })
    else :
      queryresult = dynamodb_client.query( TableName='articlecollection',
        KeyConditionExpression=' id > :X1 AND categorytable_id = :X2 ',
        ExpressionAttributeValues={ ':X1' : { 'N' : '0' }, ':X2' : { "N" : str(categorytable_id) } },
      ExclusiveStartKey=queryresult['LastEvaluatedKey'] )
    if 'Items' in queryresult and len(queryresult['Items']) > 0 :
      finalqueryresult += queryresult['Items']
    else :
      print ("error error , it should have something")
      #exit(-1)
    if 'LastEvaluatedKey' not in queryresult :
      endquery=False
   except ClientError as err  :
    if err.response['Error']['Code'] not in RETRY_EXCEPTIONS:
      raise
    print ("need to sleep for retrieve")
    time.sleep(sleep_retry)
    sleep_retry += 1




awsqueryresult =[]
#for sport only one category
getAWSItems ( awsqueryresult , categorytable_1_id)
if len(awsqueryresult) ==0 :
  response = requests.get('http://localhost:3000/web/donegensim')
  print( "==============\n\n\n\n\n",
    " gong_01 aws-gonggensim-sport 1.1 len(awsqueryresult)response.status_code",
    response.status_code )
  os._exit(0)




# a ordereddict contains same category of articles, key is article id number,
# value is a dict which contain all the information 
deleteTime = nowTime  - timedelta(days=7)
dict_same_cat =  unpackAWSItem ( awsqueryresult , dynamodb_client, 
                 int(deleteTime.timestamp()) )


#import copy
#testdictlist= []
#testdictlist.append(copy.deepcopy(dict_same_cat[280369]))
#testdictlist.append(copy.deepcopy(dict_same_cat[271924]))
#testdictlist.append(copy.deepcopy(dict_same_cat[280370]))
#testdictlist.append(copy.deepcopy(dict_same_cat[271925]))
#testdictlist.append(copy.deepcopy(dict_same_cat[280372]))
#testdictlist.append(copy.deepcopy(dict_same_cat[271927]))
#testdictlist.append(copy.deepcopy(dict_same_cat[280374]))



print ("executing ..... " , sys.argv[0])



in_domain_eng_name = 'singtao'
in_category_eng_name = 'sportsnews'
singtaoDailyNews = [(k, v['content'] ) for k,v in dict_same_cat.items() if v['firstsubdomaintable_id'] == 28  ]
print (" split -----> " , singtaoDailyNews[0])
print (" split -----> " , singtaoDailyNews[1])
singtaoDailyTexts = [ indArticleTuple[1].split() for indArticleTuple in singtaoDailyNews] #indArticleTuple[0]=articleid , indArticleTuple[1]=content
singtaodictionary = corpora.Dictionary(singtaoDailyTexts)



in_domain_eng_name = 'appledaily'
in_category_eng_name = 'sportsnews'
appledailyDailyNews = [(k, v['content'] ) for k,v in dict_same_cat.items() if v['firstsubdomaintable_id'] == 29  ]
appledailyDailyTexts = [ indArticleTuple[1].split() for indArticleTuple in appledailyDailyNews]
singtaodictionary.add_documents(appledailyDailyTexts)


in_domain_eng_name = 'orientaldaily'
in_category_eng_name = 'sportsnews'
orientaldailyDailyNews = [(k, v['content'] ) for k,v in dict_same_cat.items() if v['firstsubdomaintable_id'] == 27  ]
orientaldailyDailyTexts = [ indArticleTuple[1].split() for indArticleTuple in orientaldailyDailyNews]
singtaodictionary.add_documents(orientaldailyDailyTexts)







singtaocorpus_org = [ singtaodictionary.doc2bow(text, allow_update=True) for text in singtaoDailyTexts ]
singtaocorpus = [ [ indCorpusTuple  for indCorpusTuple in indCorpus if indCorpusTuple[1] > 1 ] for indCorpus in singtaocorpus_org ]


appledailycorpus_org = [ singtaodictionary.doc2bow(text, allow_update=True) for text in appledailyDailyTexts ]
appledailycorpus = [ [ indCorpusTuple  for indCorpusTuple in indCorpus if indCorpusTuple[1] > 1 ] for indCorpus in appledailycorpus_org ]

orientaldailycorpus_org = [ singtaodictionary.doc2bow(text, allow_update=True) for text in orientaldailyDailyTexts ]
orientaldailycorpus = [ [ indCorpusTuple  for indCorpusTuple in indCorpus if indCorpusTuple[1] > 1 ] for indCorpus in orientaldailycorpus_org ]





newsArticleList = [ [appledailyDailyNews , appledailycorpus_org]  ,
                    [orientaldailyDailyNews, orientaldailycorpus_org],
                    [singtaoDailyNews, singtaocorpus_org]  ,
                  ]








def updateArticleSimiliarities ( in_dictionary, in_newsArticleList , in_similaritesRatio, modifylist_1 , dictlist ):
  for indexArtList , indnewsArticle in enumerate(in_newsArticleList) :
    #indnewsArticle[1] is the corpus of the corresponding articlelist
    #print ('--> updateArticleSimiliarities 1 len of len(indnewsArticle)=%d, indexArtList=%d' %(len(indnewsArticle[1]), indexArtList) )
    print ('--> updateArticleSimiliarities 1 len of len(indnewsArticle)=%d, indexArtList=' %(len(indnewsArticle[1])) )
    similaritiesIndex = similarities.MatrixSimilarity(indnewsArticle[1], num_features = len(in_dictionary.items()))
    #similaritiesIndex = similarities.SparseMatrixSimilarity(indnewsArticle[1])
    #print ('updateArticleSimiliarities 2 ' )
    for crosscheckindexArtList , indcrosscheckRestPairofNewsArticle in enumerate(in_newsArticleList) :
      #print ('updateArticleSimiliarities 4 crosscheckindexArtList=%d' % crosscheckindexArtList )
      for indcorpusindex , indArticleCorpus in enumerate(indcrosscheckRestPairofNewsArticle[1] ) :
        #print ('updateArticleSimiliarities 5 len= ', len(indArticleCorpus) )
        indArticleCorpusSimValue = similaritiesIndex[indArticleCorpus]
        #print ('updateArticleSimiliarities 6 ' )
        sortedindArticleCorpusSimValue = sorted(list(enumerate(indArticleCorpusSimValue)) ,  key=lambda tu : -abs(tu[1]))
        #sortedindArticleCorpusSimValue[0] of tuple (indextoNewsArticleList, score) has the highest score
        if sortedindArticleCorpusSimValue[0][1] > in_similaritesRatio :
          #print ('updateArticleSimiliarities 7 ratio = ' , sortedindArticleCorpusSimValue[0][1])
          #set the related list
          #indcrosscheckRestPairofNewsArticle[0] list of NewsArticle
          #indnewsArticle[0] list of NewsArticle
          if indcrosscheckRestPairofNewsArticle[0][indcorpusindex][0] != indnewsArticle[0][sortedindArticleCorpusSimValue[0][0]][0] :
            articleTableIndexPair = [ indcrosscheckRestPairofNewsArticle[0][indcorpusindex][0] ,  indnewsArticle[0][sortedindArticleCorpusSimValue[0][0]][0] ]
            setArticleSimilaritieslist(articleTableIndexPair , modifylist_1,
                 dictlist  )
            #print ('updateArticleSimiliarities 8 ' )



def setArticleSimilaritieslist( in_articleTablePair ,in_modifylist,
       in_articlelistdict   ) :
    #print ( 'setArticleSimilaritieslist 1 ', in_articleTablePair)
    for index, entryID in enumerate(in_articleTablePair) :
      updateEntryID = in_articleTablePair[1] if index == 0 else in_articleTablePair[0]
      #the first one
      result = ( in_articlelistdict[entryID]['similaritieslist'] ,
                 in_articlelistdict[entryID]['finalurl'] )
      result_updateEntryID = in_articlelistdict[updateEntryID]['finalurl'] 
      #print ( 'setArticleSimilaritieslist entryID=%s updateEntryID=%s' % (entryID, updateEntryID))
      if result is None  :
        #print ('setArticleSimilaritieslist 3 set error ' )
        return
      #print ( 'setArticleSimilaritieslist 4 result[0]=', result[0])
      if result[1] in result_updateEntryID[0] :
        #print ('setArticleSimilaritieslist 5 almost same url ' )
        return


      updatelist =''
      updatecount = 0
      if result[0] is None :
        #print ("result[0] is none " , updateEntryID)
        updatelist = str(updateEntryID)
        updatecount = 1
      else :
        #print (" updateentryid type", type(updateEntryID), ",value=", updateEntryID)
        #print (" result[0] type", type(result[0]), ",value=", result[0])
        if (' ' + str(updateEntryID) + ' ') not in (' ' + result[0] + ' ') :
          updatelist = result[0].strip() + ' ' +str(updateEntryID)
          updatecount = len( updatelist.split() )

      #print ( 'setArticleSimilaritieslist 6 updatecount=', updatecount )
      if updatelist != '' :
        #print ( 'setArticleSimilaritieslist 7 updatelist=', updatelist)
        in_articlelistdict[entryID]['similaritieslist'] = updatelist 
        in_articlelistdict[entryID]['similaritiescount'] = updatecount 
        in_modifylist.append( entryID)

    #print ( 'setArticleSimilaritieslist 9 ')








modifylistofid =[]
similaritesRatio = 0.35
updateArticleSimiliarities ( singtaodictionary, newsArticleList , similaritesRatio, modifylistofid , dict_same_cat )

#print (" --------> modifylistofid = ", modifylistofid)
#print ("=============================")
#print ("=============================")
#print ("=============================")
#print ("280374 = ", testdictlist[6] )
#print ("+++++++++++++++++++++++++++++")
#print ("samedict280374 = ", dict_same_cat[280374] )


#let's do the update
#because aws batchwriteitem cannot do the update
#https://docs.aws.amazon.com/amazondynamodb/latest/APIReference/API_BatchWriteItem.html
#so do it one by one
from pymongo import UpdateOne
import random
list_of_mongodb_ops = []
for x in modifylistofid :
  if x in dict_same_cat :
    list_of_mongodb_ops.append ( UpdateOne ( { 'id' : x }, { '$set' : { 
        'similaritieslist' : dict_same_cat[x]['similaritieslist'] ,
        'similaritiescount' : dict_same_cat[x]['similaritiescount'] } } ) )
    time.sleep( 1)
    retrySend=True
    sleeptime =10
    while (retrySend) and sleeptime < 200 :
        time.sleep(sleeptime)
        sleeptime +=1
        try :
         response = dynamodb_client.update_item (
          ExpressionAttributeNames= {
            '#SL' : 'similaritieslist',
            '#SC' : 'similaritiescount',
          },
          ExpressionAttributeValues = {
            ':slval' : {
               'S' : dict_same_cat[x]['similaritieslist'],
            },
            ':scval' : {
               'N' : str(dict_same_cat[x]['similaritiescount']),
            },
          },
          Key={
            'categorytable_id' : {
               'N' : str(categorytable_1_id),
            },
            'id' : {
               'N' : str(x),
            },
          },
          TableName='articlecollection',
          UpdateExpression='SET #SL = :slval , #SC = :scval '
         ) 
         retrySend=False
        except ClientError as e :
               print(" aws-gonggensim-sport  ",
                  " ClientError only e=", e)
               print(" aws-gonggensim-sport  ",
                  " ClientError only e=", e, file=sys.stderr )
               if err.response['Error']['Code'] not in RETRY_EXCEPTIONS:
                  raise
               sleeptime += random.randrange(10)
    #
    #
    if ( response['ResponseMetadata']['HTTPStatusCode'] != 200 )  :
      #something wrong
      print (" gong_01 aws-gonggensim-sport error update error=",
          response['ResponseMetadata']['HTTPStatusCode'] )
  #
  else :
      print (" gong_01 aws-gonggensim-sport error  wrong id=",x)
 
if len(list_of_mongodb_ops ) > 0 :
  mongodb_result = mongodb_articlecollection.bulk_write(list_of_mongodb_ops)
  print ("=============================")
  print ( "mongodb_result =", mongodb_result.bulk_api_result)
  print ("=============================")
else :
  print ("=============================")
  print ( "mongodb_result = no operation" )
  print ("=============================")
  

print ("end time for gensim = ", datetime.now(timezone(timedelta(hours=8))) )








response = requests.get('http://localhost:3000/web/donegensim')
print( "==============\n\n\n\n\n",
  " gong_01 assignchildprocess 1.1 response.status_code",
  response.status_code )
print( "==============\n\n\n\n\n",
  " gong_01 assignchildprocess 1.1 response.status_code",
  response.status_code , file=sys.stderr )
os._exit(0)




