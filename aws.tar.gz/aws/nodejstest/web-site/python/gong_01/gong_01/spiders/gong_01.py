import time
import scrapy
import json
import base64
from scrapy_splash import SplashRequest
from scrapy_splash import SlotPolicy
#from scrapy import Selector
from datetime import datetime, timedelta,timezone
import re
from gong_01_db import GongAllTable
from gong_01_generic_source import *


class Gong01Spider(scrapy.Spider):
    name = "gong_01"


    def start_requests(self):
        self.log('------------------ start_requests 1 hello')
        self.gong=GongAllTable('gong.db')
        self.session=self.gong.init_all_table()
        self.optionfirstsubdomain_num = getattr(self, 'firstsubdomain', "1")
        self.optiondomaintorun_num = getattr(self, 'domaintorun', 'crhk')
        self.optionnewstypetorun_num = getattr(self, 'newstypetorun', 'latestnews')
        self.optionlatestupdatetime_num = getattr(self, 'latestupdatetime', 
                 '0')
        self.optionawssplashurl = getattr(self, 'awssplashurl', 
                 'http://splash-local:8050')
        optionawsslotpolicy = getattr(self, 'awsslotpolicy', 
                 'perdomain')
        if (optionawsslotpolicy == 'perdomain') :
          self.optionawsslotpolicy = SlotPolicy.PER_DOMAIN
        elif (optionawsslotpolicy == 'singleslot') :
          self.optionawsslotpolicy = SlotPolicy.SINGLE_SLOT
        else :
          self.optionawsslotpolicy = SlotPolicy.SCRAPY_DEFAULT

        latestupdatetime =  datetime.fromtimestamp( \
             int(self.optionlatestupdatetime_num) ).replace(tzinfo=timezone(timedelta(hours=8)))

        result= self.gong.setLatestUpdateTimeAndUrl(int(self.optionfirstsubdomain_num),
                                             latestupdatetime,
                                             "aws" )
        
        self.optiondomaintorun = self.gong.getEngnameforDomainTable(int(self.optiondomaintorun_num))[0]
        self.optionnewstypetorun = self.gong.getEngnameforCategoryTable(int(self.optionnewstypetorun_num))[0]
        self.log('------------------ start_requests 1.1-1 fsd=%s' %
          self.optionfirstsubdomain_num)
        self.log('------------------ start_requests 1.1-2 domain=%s' %
          self.optiondomaintorun_num)
        self.log('------------------ start_requests 1.1-3 type=%s' %
          self.optionnewstypetorun_num )
        self.log('------------------ start_requests 1.1-4 latest=%s' %
          self.optionlatestupdatetime_num )
        self.log('------------------ start_requests 1.1-5 latestupdatetime=%s' %
          latestupdatetime )
        self.log('------------------ start_requests 1.1-6 awssplashurl=%s' %
          self.optionawssplashurl )
        self.log('------------------ start_requests 1.1-7 awsslotpolicy=%s' %
          optionawsslotpolicy )
        print('------------------ start_requests 1.1.1',self.optiondomaintorun)
        self.log('------------------ start_requests 1.1.1 =%s' % self.optiondomaintorun)

        #the following is the testing datetime
        self.nowTime= datetime.now(timezone(timedelta(hours=8)))
        print('----> starting gong_01.py ', self.nowTime)
        #the dailynews update time is around 3amHKT

        if self.nowTime.hour < 6 :
          self.nowTime = self.nowTime - timedelta(hours=4) 

        self.urlDict=self.gong.getRetrieveURLPair(self.nowTime)

        #for key in self.urlDict:
        self.log('------------------ start_requests 1.3.1 =%s' % self.optiondomaintorun)
        self.log('------------------ start_requests 1.3.2 =%s' % self.optionnewstypetorun)
     

        """
        key = (self.optiondomaintorun, self.optionnewstypetorun) 
        if ('hk01','updatedb') == key:
              self.log('------------------ start_requests hk01 updatedb 2' )
              listOfArticles = self.gong.getListOfArticleWithoutTitle(16)
              for x in listOfArticles :
                yield SplashRequest(x.finalurl, 
                            self.parse_result_main_item_update, 
                            endpoint= 'render.json',
                            args=  { 'html': 1,
                                     'jpeg': 1,
                                     'width': 600,
                                     'render_all': 1,
                                     'wait' : 15, },
                            meta={
                             'articleInfo_meta' : x,
                            })
              return None
        """


        if ( (self.optiondomaintorun, self.optionnewstypetorun) in \
           self.urlDict )  :
          key = (self.optiondomaintorun, self.optionnewstypetorun) 
          self.log('------------------ start_requests 1.5')
          latestupdateurl, latestupdatetime = self.gong.getLatestUpdateTimeAndUrl(self.urlDict[key][0]) 
          sNewsParser = GongGenericSource()

          if ('passiontimes','latestnews') == key:
             sNewsParser = PassiontimesLatestNewsParser()
             for categoryNum in [1,2,3,4,7 ,8,9,11,12,18,19 ,20,21,24,37] :
                
               self.log('------------------ start_requests passiontimes latestnews 2=%s' % (self.urlDict[key][1] + '/' + str(categoryNum)))
               yield SplashRequest(self.urlDict[key][1] + '/' + str(categoryNum) + '/?page=1', 
                            self.parse_result_main_webpage, 
                            endpoint=sNewsParser.endpointexecute,
                            args=sNewsParser.splash_args,
                            splash_url=self.optionawssplashurl, 
                            slot_policy=self.optionawsslotpolicy, 
                            meta={
                             'max_retry_times' : \
                                 sNewsParser.max_retry_times ,
                             'domain' : key ,
                             'latestupdatetime' : latestupdatetime ,
                             'sourcenewsparser' : \
                                 sNewsParser,
                               key : self.urlDict[key]
                            })
          else :

            if ('crhk','latestnews') == key:
              self.log('------------------ start_requests crhk latestnews 2=%s' % self.urlDict[key][1])
              sNewsParser = CrhkLatestNewsParser()
            elif ('rthk','latestnews') == key:
              self.log('------------------ start_requests rthk latestnews 2=%s' % self.urlDict[key][1])
              sNewsParser = RthkLatestNewsParser()
            elif ('orientaldaily_net','latestnews') == key:
              self.log('------------------ start_requests orientaldaily_net latestnews 2=%s' % self.urlDict[key][1])
              sNewsParser = OrientaldailyNetLatestNewsParser()
            elif ('orientaldaily','dailynews') == key:
              self.log('------------------ start_requests orientaldaily dailynews 2=%s' % self.urlDict[key][1])
              sNewsParser = OrientaldailyDailyNewsParser()
            elif ('appledaily','latestnews') == key:
              self.log('------------------ start_requests appledaily latestnews 2=%s' % self.urlDict[key][1])
              sNewsParser = AppledailyLatestNewsParser()
            elif ('appledaily','dailynews') == key:
              self.log('------------------ start_requests appledaily dailynews 2=%s' % self.urlDict[key][1])
              sNewsParser = AppledailyDailyNewsParser()
            elif ('singtao','latestnews') == key:
              self.log('------------------ start_requests singtao latestnews 2=%s' % self.urlDict[key][1])
              sNewsParser = SingtaoLatestNewsParser()
            elif ('singtao','dailynews') == key:
              self.log('------------------ start_requests singtao dailynews 2=%s' % self.urlDict[key][1])
              sNewsParser = SingtaoDailyNewsParser()
            elif ('mingpao','latestnews') == key:
              self.log('------------------ start_requests mingpao latestnews 2=%s' % self.urlDict[key][1])
              sNewsParser = MingpaoLatestNewsParser()
            elif ('mingpao','dailynews') == key:
              self.log('------------------ start_requests mingpao dailynews 2=%s' % self.urlDict[key][1])
              sNewsParser = MingpaoDailyNewsParser()
            elif ('standnews','latestnews') == key:
              self.log('------------------ start_requests standnews latestnews 2=%s' % self.urlDict[key][1])
              sNewsParser = StandnewsLatestNewsParser()
            elif ('post852','latestnews') == key:
              self.log('------------------ start_requests post852 latestnews 2=%s' % self.urlDict[key][1])
              sNewsParser = Post852LatestNewsParser()
            elif ('hk01','latestnews') == key:
              self.log('------------------ start_requests hk01 latestnews 2=%s' % self.urlDict[key][1])
              sNewsParser = Hk01LatestNewsParser()
            elif ('now','latestnews') == key:
              self.log('------------------ start_requests now dailynews 2=%s' % self.urlDict[key][1])
              sNewsParser = NowLatestNewsParser()
            elif ('am730','dailynews') == key:
              self.log('------------------ start_requests am730 dailynews 2=%s' % self.urlDict[key][1])
              sNewsParser = Am730DailyNewsParser()
            elif ('hkej_now','latestfinnews') == key:
              self.log('------------------ start_requests hkej_now latestfinnews 2=%s' % self.urlDict[key][1])
              sNewsParser = HkejLatestNewsParser()
            elif ('hkej','financialnews') == key:
              self.log('------------------ start_requests hkej financialnews 2=%s' % self.urlDict[key][1])
              sNewsParser = HkejDailyNewsParser()
            elif ('aastocks_now','latestfinnews') == key:
              self.log('------------------ start_requests aastocks_now latestfinnews 2=%s' % self.urlDict[key][1])
              sNewsParser = AAStocksLatestNewsParser()
            elif ('aastocks','financialnews') == key:
              self.log('------------------ start_requests aastocks financialnews 2=%s' % self.urlDict[key][1])
              sNewsParser = AAStocksDailyNewsParser()
            elif ('orientaldaily','financialnews') == key:
              self.log('------------------ start_requests orientaldaily financialnews 2=%s' % self.urlDict[key][1])
              sNewsParser = OrientaldailyFinDailyNewsParser()
            elif ('appledaily','financialnews') == key:
              self.log('------------------ start_requests appledaily financialnews 2=%s' % self.urlDict[key][1])
              sNewsParser = AppledailyFinDailyNewsParser()
            elif ('orientaldaily','sportsnews') == key:
              self.log('------------------ start_requests orientaldaily sportsnews 2=%s' % self.urlDict[key][1])
              sNewsParser = OrientaldailySportDailyNewsParser()
            elif ('appledaily','sportsnews') == key:
              self.log('------------------ start_requests appledaily sportsnews 2=%s' % self.urlDict[key][1])
              sNewsParser = AppledailySportDailyNewsParser()
            elif ('singtao','sportsnews') == key:
              self.log('------------------ start_requests singtao sportsnews 2=%s' % self.urlDict[key][1])
              sNewsParser = SingtaoSportDailyNewsParser()
            elif ('orientaldaily','entertainmentnews') == key:
              self.log('------------------ start_requests orientaldaily entertainmentnews 2=%s' % self.urlDict[key][1])
              sNewsParser = OrientaldailyEntDailyNewsParser()
            elif ('appledaily','entertainmentnews') == key:
              self.log('------------------ start_requests appledaily entertainmentnews 2=%s' % self.urlDict[key][1])
              sNewsParser = AppledailyEntDailyNewsParser()
            elif ('singtao','entertainmentnews') == key:
              self.log('------------------ start_requests singtao entertainmentnews 2=%s' % self.urlDict[key][1])
              sNewsParser = SingtaoEntDailyNewsParser()
            else :
              self.log('------------------ error, no such parser')
              return None
             
            yield SplashRequest(self.urlDict[key][1], 
                            self.parse_result_main_webpage, 
                            endpoint=sNewsParser.endpointexecute,
                            args=sNewsParser.splash_args,
                            splash_url=self.optionawssplashurl, 
                            slot_policy=self.optionawsslotpolicy, 
                            meta={
                             'max_retry_times' : \
                                 sNewsParser.max_retry_times ,
                             'domain' : key ,
                             'latestupdatetime' : latestupdatetime ,
                             'sourcenewsparser' : \
                                 sNewsParser,
                               key : self.urlDict[key]
                            })
        self.log('------------------ start_requests 4')






############# the following is for main webpage parse_result
    def parse_result_main_webpage(self, response):
        #self.log('------------------ parse_result_main_webpage 1')
        # magic responses are turned ON by default,
        # so the result under 'html' key is available as response.body
        html = response.body

        if 'lua_scroll_html' in response.data :
          info_html=response.data['lua_scroll_html']
        else :
          info_html = None
        if 'lua_nowtime' in response.data :
          lua_nowtime = response.data['lua_nowtime']
        else :
          lua_nowtime = None 

        #get latest time
        domain_key= response.request.meta['domain']
        domain_key_value = response.request.meta[domain_key]
        latestupdatetime = response.request.meta['latestupdatetime']
        sourceNewsParser = response.request.meta['sourcenewsparser']

        #self.log('------------------ parse_result_main_webpage 3len=%d'%len(info_html))
        #self.log('------------------ parse_result_main_webpage 3info_html=%s'%info_html[:100])

        newsItemList = sourceNewsParser.get_newsItemList(resp=response, info=info_html)
        #newsItemList =  scrapy.Selector(text=info_html).xpath('//div[@class="cat12"]//ul[contains(@class,"twocol") and contains(@class, "left")]/div[@class="date"] | //div[@class="cat12"]//ul[contains(@class,"twocol") and contains(@class, "left")]/li[@class="list1"]').extract()


        nowTime= datetime.now(timezone(timedelta(hours=8)))
        indNewsItemYear = nowTime.year
        indNewsItemMonth = nowTime.month
        indNewsItemDay = nowTime.day

        base_url= sourceNewsParser.base_url 
        update_indicator=True
        numOfYieldRequest=0 
        self.log('------------------ parse_result_main_webpage 4 len(newsItemList)=', len(newsItemList))
        for indNewsAboutArticleRow in newsItemList :
          check_date = scrapy.Selector(text=indNewsAboutArticleRow).xpath('//div[@class="date"]/b/text()').extract_first()

          self.log('------------------ parse_result_main_webpage 4.01')
          if (check_date is not None) and (len(check_date) > 0):
            #this is the date element
            indNewsItemYear=check_date[3:7]
            indNewsItemMonthandDay=check_date[8:].split('月')
            indNewsItemMonth= indNewsItemMonthandDay[0]
            indNewsItemDay =  indNewsItemMonthandDay[1][:-1]
            continue


          indNewsItemURL = sourceNewsParser.get_indNewsItemURL(indNewsAboutArticleRow)
          indNewsItemTitle = sourceNewsParser.get_indNewsItemTitle(indNewsAboutArticleRow)
          self.log('------------------ parse_result_main_webpage 4.1 %s ' % indNewsItemTitle)
          self.log('------------------ parse_result_main_webpage 4.2 %s ' % indNewsItemURL)
          self.log('------------------ parse_result_main_webpage 5 = %d'% numOfYieldRequest)

          indNewsItemTime= sourceNewsParser.get_indNewsItemTime(indNewsAboutArticleRow, url=indNewsItemURL, iyear=indNewsItemYear, imonth=indNewsItemMonth, iday=indNewsItemDay)
          self.log('------------------ parse_result_main_webpage 5.5 indNewsItemTime=%s latestupdatetime=%s'% (indNewsItemTime, latestupdatetime.replace(tzinfo=timezone(timedelta(hours=8))) ))
          if (indNewsItemTime > latestupdatetime.replace(tzinfo=timezone(timedelta(hours=8))))  :
            self.log('------------------ parse_result_main_webpage 6 =%s'% str(indNewsItemTime))
            if update_indicator :
              update_indicator=False
              testlatestupdateurl, testlatestupdatetime = self.gong.getLatestUpdateTimeAndUrl(self.urlDict[domain_key][0]) 
              if (  indNewsItemTime > testlatestupdatetime.replace(tzinfo=timezone(timedelta(hours=8))) ) :

                result= self.gong.setLatestUpdateTimeAndUrl(domain_key_value[0],
                                             self.nowTime,
                                             indNewsItemURL)
                print ('gong.setlatestupdatetimeandurl result=',result)
            
            numOfYieldRequest += 1
            #self.log('------------------ parse_result_main_webpage 7 =%d'% numOfYieldRequest)
            #test 
            if numOfYieldRequest > 0 :
              yield SplashRequest(indNewsItemURL, 
                            self.parse_result_main_item, 
                            endpoint= sourceNewsParser.endpointexecute_item,
                            args= sourceNewsParser.splash_args_item,
                            splash_url=self.optionawssplashurl, 
                            slot_policy=self.optionawsslotpolicy, 
                            meta={
                             'indNewsItemURL' : indNewsItemURL ,
                             'indNewsItemTitle' : indNewsItemTitle ,
                             'indNewsItemTime' : indNewsItemTime ,
                             'domain' : domain_key,
                             domain_key : domain_key_value,
                             'sourcenewsparser' : sourceNewsParser
                            })
        info_jpeg=response.data['jpeg']   
        jpeg_bytes = base64.b64decode(info_jpeg)
        firstdomainfilename = re.sub(r'/', '', response.url)
        firstdomainfilename = re.sub(r'\?', '', firstdomainfilename)
        firstdomainfilename = re.sub(r'\&', '', firstdomainfilename)
        firstdomainfilename = re.sub(r'\=', '', firstdomainfilename)
        firstdomainfilename = re.sub(r'\:', '', firstdomainfilename)
        self.log('------------------ parse_result_main_webpage 7.4=%s '% firstdomainfilename)
        filename_jpeg = domain_key[0] + '-' + domain_key[1] + \
             '-' + firstdomainfilename + '.jpeg'
        self.log('------------------ parse_result_main_webpage 7.5=%s '% filename_jpeg)
        #with open(filename_jpeg , 'wb') as f:
        #  f.write(jpeg_bytes)


        """ 
        filename_html = domain_key[0] + '-' + domain_key[1] + \
             '-'  + '.html'
        with open(filename_html , 'w') as f:
          f.write(str(html))
        """ 
        
       
 
        #deal with pagination    
        #check for pagination
        if sourceNewsParser.dopagination and (numOfYieldRequest >= sourceNewsParser.numOfYieldRequestLimit) and sourceNewsParser.get_havenextpage(response) :
          #the last article still newer than the latestupdate time, so go to page 2
          self.log('------------------ parse_result_main_webpage 9 =%s'% response.url)
          newPageURL = sourceNewsParser.get_newPageURL(response)
          self.log('------------------ parse_result_main_webpage 10 =%s'% newPageURL)
          
          yield SplashRequest(newPageURL, 
                            self.parse_result_main_webpage, 
                            endpoint= sourceNewsParser.endpointexecute,
                            args= sourceNewsParser.splash_args,
                            splash_url=self.optionawssplashurl, 
                            slot_policy=self.optionawsslotpolicy, 
                            meta={
                             'max_retry_times' : \
                                 sourceNewsParser.max_retry_times ,
                             'domain' : domain_key,
                             domain_key : domain_key_value,
                             'latestupdatetime' : latestupdatetime ,
                             'sourcenewsparser' : \
                                 sourceNewsParser
                            })




    def parse_result_main_item(self, response):
        #self.log('------------------ parse_result_main_item 1')
        # magic responses are turned ON by default,
        # so the result under 'html' key is available as response.body
        html = response.body
        #self.log('------------------ parse_result_main_item 2')

        #get latest time
        domain_key= response.request.meta['domain']
        domain_key_value = response.request.meta[domain_key]
        indNewsItemURL = response.request.meta['indNewsItemURL']
        indNewsItemTitle = response.request.meta['indNewsItemTitle']
        indNewsItemTime = response.request.meta['indNewsItemTime']
        sourceNewsParser = response.request.meta['sourcenewsparser']

        if sourceNewsParser.secondtryItemTime :
          indNewsItemTime = sourceNewsParser.get_secondItemTime(response)
          

        #self.log('------------------ parse_result_main_item 3')
        articleContent = sourceNewsParser.get_articleContent(response)
        parseImageURL = sourceNewsParser.get_parseImageURL(response)
        self.log('------------------ parse_result_main_item 3.1 articleContent=%s'% articleContent[:100])
        self.log('------------------ parse_result_main_item 3.2 parseImageURL=%s'% parseImageURL)

        
        filename_jpeg=None 
        """
        info_jpeg=response.data['jpeg']   
        jpeg_bytes = base64.b64decode(info_jpeg)
        titleString = re.sub(r'/','',indNewsItemTitle)
        filename_jpeg = domain_key[0] + '-' + domain_key[1] + \
             indNewsItemTime.strftime('%Y-%m-%d-%H-%M-%S') + \
             '-' + titleString + '.jpeg'
        with open(filename_jpeg , 'wb') as f:
          f.write(jpeg_bytes)
        self.log('------------------ parse_result_now_latestnews_item 4 filename=%s'% filename_jpeg)
 
        info_html=response.data['html']   
        titleString = re.sub(r'/','',indNewsItemTitle)
        filename_html = domain_key[0] + '-' + domain_key[1] + \
             indNewsItemTime.strftime('%Y-%m-%d-%H-%M-%S') + \
             '-' + titleString + '.html'
        with open(filename_html , 'w') as f:
          f.write(info_html)
        self.log('------------------ parse_result_standnews_latestnews_item 4.1 filename=%s'% filename_html)
        """

        result= self.gong.setArticleEntry( domain_key_value[0], 
                indNewsItemURL, indNewsItemTime, 
                indNewsItemTitle, articleContent, 
                filename_jpeg, parseImageURL)

        self.log(' ----> domain_key_value[0]=%s'%domain_key_value[0]) 
        self.log(' ----> indNewsItemURL=%s'%indNewsItemURL) 
        self.log(' ----> indNewsItemTime=%s'%indNewsItemTime) 
        self.log(' ----> indNewsItemTitle=%s'%indNewsItemTitle) 
        self.log(' ----> articleContent=%s'%articleContent[:100]) 
        self.log(' ----> parseImageURL=%s'%parseImageURL) 
         
        self.log('------------------ parse_result_main_item 5 result=%s'% str(result))




    def parse_result_main_item_update (self, response):
        #self.log('------------------ parse_result_main_item 1')
        # magic responses are turned ON by default,
        # so the result under 'html' key is available as response.body
        html = response.body
        #self.log('------------------ parse_result_main_item 2')

        #get latest time
        articleInfo_meta= response.request.meta['articleInfo_meta']
        title = response.xpath('//article//h1/text()').extract_first()
        result = self.gong.updateArticleTitle(articleInfo_meta , title)
        self.log('------------------ parse_result_main_item_update 1=%s'%result)
        self.log('------------------ parse_result_main_item_update 2=%s'%title)











