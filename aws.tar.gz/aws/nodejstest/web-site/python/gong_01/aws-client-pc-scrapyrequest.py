#! /usr/bin/env python3

from __future__ import print_function
#import httplib2
import os
from collections import OrderedDict

import io
import time
import datetime
from datetime import datetime, timedelta, timezone, date
import data_helpers

import sys
import time
import json
import lxml.html

import boto3
import pymongo
import pika
import logging


#the following for firebase
import firebase_admin
from firebase_admin import credentials
from firebase_admin import db

import argparse

parser = argparse.ArgumentParser()
parser.add_argument('inputarg', nargs='*')
argument = parser.parse_args()

print ("argument.inputarg = " , argument.inputarg )
#if argument.inputarg is not None :
if len(argument.inputarg) > 0 :
  localornot = "remote"
  args_rabbitmqurl = argument.inputarg[0]
  args_awsurl = argument.inputarg[1]
  args_mongodburl = argument.inputarg[2]
else :
  localornot = "local"
  args_rabbitmqurl= 'amqp://ngogongrabbitmq:abcde12345@rabbit-pub-docker:5672/'
  args_awsurl = "http://ecs-demo-web:3000"
  args_mongodburl = "mongodb+srv://normaluser:abcde12345@cluster0-q3gf2.mongodb.net"


cred = credentials.Certificate('./friendlychat-d1a66-firebase-adminsdk-eq7ke-c3ae44c287.json' )
default_app = firebase_admin.initialize_app(cred, {
        'databaseURL' : 'https://friendlychat-d1a66.firebaseio.com',
   })


LOG_FORMAT = ('%(levelname) -10s %(asctime)s %(name) -30s %(funcName) '
                '-35s %(lineno) -5d: %(message)s')
LOGGER = logging.getLogger(__name__)

class AWSPCClient_BLOCK():

    def __init__ (self, url, aws_url, mongodb_url) :
      self.url = url
      self.awsurl = aws_url
      #  self.awsurl =  "ecs-demo-web"
      self.mongodburl = mongodb_url
      #  self.mongodburl =  "mongodb+srv://normaluser:abcde12345@cluster0-q3gf2.mongodb.net"
      #self.rabbitmqserverurl = 'amqp://ngogongrabbitmq:abcde12345@rabbit-pub-docker:5672/'
      self.rabbitmqserverurl = url

      self.firstsubupdatedict = db.reference().child('v2').child('latestupdatetimetable').get() 


      self.articleID = str(db.reference().child('v2').child('articlelookuptable').child('noofentry').get())

      self.connection = pika.BlockingConnection(pika.URLParameters ( \
                        self.rabbitmqserverurl))
      self.channel = self.connection.channel ()
      #if use queue = 'rab_pc_client_q' , it means it consume itself
      #result = self.channel.queue_declare ( queue='rab_pc_client_q' )          
      result = self.channel.queue_declare ( exclusive=True )          
      self.callback_queue = result.method.queue

      print ("\n\n\n\n\n callback_queuename = ", self.callback_queue, "\n\n\n")
      
      self.channel.basic_consume ( self.on_response , 
                                   queue = self.callback_queue ) 

    def on_response ( self, ch, method, properties, body) :
      print ( "\n\n\n\n AWSPCClient_BLOCK on_response 1 jobid=", self.jobid,
              ", body=" , body )
      print ("\n\n\n\n\n")
      self.response = body
      if self.jobid == properties.correlation_id :
        self.response = body
      ch.basic_ack(delivery_tag = method.delivery_tag)

    def run (self) :
      print ( " AWSPCClient_BLOCK call 1 " )
      self.jobid = datetime.now(timezone(timedelta(hours=8)))
      msgbody ={ 'key' : 'scrapyrequest' ,
                 'data': { 'jobid'  : int(self.jobid.timestamp()) ,
                           'mongodburl' : self.mongodburl,
                           'awsurl' : self.awsurl ,
                           'replytoq' : self.callback_queue,
                           'articleID' : self.articleID,
                           'correlationid' : int(self.jobid.timestamp()) ,
                           'firstsubupdatedict' : self.firstsubupdatedict,
                           'rabbitmqserverurl' : self.rabbitmqserverurl  } }

      #self.channel.basic_publish( exchange='ngogongrabbitmqexchange',
      self.channel.basic_publish( exchange='',
                      routing_key='rab_pc_client_q',
                      properties = pika.BasicProperties (
                           reply_to = self.callback_queue,
                           correlation_id = str(int(self.jobid.timestamp())) ) ,
                      body = json.dumps(msgbody) )
      self.response = None
      while self.response is None :
        print ( " AWSPCClient_BLOCK call 2 " )
        self.connection.process_data_events() 
        time.sleep(10)
        print ( " AWSPCClient_BLOCK call 3 " )

"""
cred = credentials.Certificate('./friendlychat-d1a66-firebase-adminsdk-eq7ke-c3ae44c287.json' )
default_app = firebase_admin.initialize_app(cred, {
        'databaseURL' : 'https://friendlychat-d1a66.firebaseio.com',
   })
rabbitmqserverurl = 'amqp://ngogongrabbitmq:abcde12345@rabbit-pub-docker:5672/'
firstsubupdatedict = db.reference().child('v2').child('latestupdatetimetable').get()
articleID = str(db.reference().child('v2').child('articlelookuptable').child('noofentry').get())
awsurl =  "ecs-demo-web"
mongodburl =  "mongodb+srv://normaluser:abcde12345@cluster0-q3gf2.mongodb.net"
connection = pika.BlockingConnection(pika.URLParameters ( rabbitmqserverurl ) )
channel = connection.channel ()
#result = channel.queue_declare ( queue='rab_pc_client_q' )
result = channel.queue_declare ( queue='hello' )
def on_response ( ch, method, properties, body) :
  print (" body value = " , body)
  response=body 

callback_queue = result.method.queue
jobid = datetime.now(timezone(timedelta(hours=8)))
msgbody={'key' : 'checkstatus', 'data' : {'jobid' : int(jobid.timestamp()),
  'mongodburl' : mongodburl , 'awsurl' : awsurl ,
  'replytoq' : callback_queue, 'articleID' : articleID,
  'correlationid' : int(jobid.timestamp()),
  'firstsubupdatedict' : firstsubupdatedict ,
  'rabbitmqserverurl' : rabbitmqserverurl } }

#channel.basic_publish( exchange='ngogongrabbitmqexchange',
channel.basic_publish( exchange='',
  #routing_key='rab_pc_client_q',
  routing_key='hello',
  properties = pika.BasicProperties (
     reply_to = callback_queue,
     correlation_id = str(int(jobid.timestamp()))),
     body = json.dumps(msgbody) )






"""

def main():
    logging.basicConfig(level=logging.DEBUG, format=LOG_FORMAT)

    # Connect to localhost:5672 as guest with the password guest and virtual host "/" (%2F)
    # awspc_client = AWSPCClient_BLOCK('amqp://ngogongrabbitmq:abcde12345@localhost:5672/',
    #awspc_client = AWSPCClient_BLOCK('amqp://ngogongrabbitmq:abcde12345@rabbit-pub-docker:5672/',
    #   "http://ecs-demo-web:3000",
    #   "mongodb+srv://normaluser:abcde12345@cluster0-q3gf2.mongodb.net", 
    #  )
    awspc_client = AWSPCClient_BLOCK( args_rabbitmqurl,
       args_awsurl,
       args_mongodburl , 
      )
    awspc_client.run()


if __name__ == '__main__':
    main()   
  
