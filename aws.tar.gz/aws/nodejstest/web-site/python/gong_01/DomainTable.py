
import sqlalchemy
from sqlalchemy.orm import relationship
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import Column, Integer, String, Text, Table
from sqlalchemy import ForeignKey
from CommonBase import Base



#Base=declarative_base()


class DomainTable(Base):
  __tablename__ = 'domaintable'

  id=Column(Integer, primary_key=True)
  baseurl=Column(Text)
  chi_name=Column(Text)
  eng_name=Column(Text)
  firstsubdomaintable_list=relationship( "FirstSubDomainTable", back_populates='domaintable_entry', cascade="all, delete, delete-orphan")

  def __repr__(self):
    return "<DomainTable(id='%d', baseurl='%s', chi_name='%s', eng_name='%s')>" % (self.id, self.baseurl, self.chi_name, self.eng_name)

