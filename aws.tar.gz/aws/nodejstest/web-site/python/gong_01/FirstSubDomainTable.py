
import sqlalchemy
from sqlalchemy.orm import relationship
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import Column, Integer, String, Text, Table, Boolean, DateTime
from sqlalchemy import ForeignKey
from CommonBase import Base

#Base=declarative_base()

class FirstSubDomainTable(Base):
  __tablename__ = 'firstsubdomaintable'

  id=Column(Integer, primary_key=True)

  domaintable_id = Column(Integer, ForeignKey('domaintable.id') )
  domaintable_entry= relationship("DomainTable", back_populates="firstsubdomaintable_list", foreign_keys=[domaintable_id])

  categorytable_id = Column(Integer, ForeignKey('categorytable.id') )
  categorytable= relationship("CategoryTable", back_populates="firstsubdomaintable_list", foreign_keys=[categorytable_id])
  articletable_list=relationship("ArticleTable", back_populates='firstsubdomaintable', cascade="all, delete, delete-orphan")

  firstsubd=Column(Text)
  onlyweekdays=Column(Boolean, default=False)  #True False
  latestupdatetime=Column(DateTime)
  latestupdateurl=Column(Text)
  #similaritiesupdatetime =Column(DateTime)
  sourceiconurl=Column(Text)

  def __repr__(self):
  #  return "<FirstSubDomainTable(id='%d', domaintable_id='%d', categorytable_id='%d', firstsubd='%s', onlyweekdays='%s', latestupdatetime='%s', latestupdateurl='%s', similaritiesupdatetime='%s' )>" % (self.id, self.domaintable_id, self.categorytable_id, self.firstsubd, self.onlyweekdays, self.latestupdatetime, self.latestupdateurl, self.similaritiesupdatetime)
    return "<FirstSubDomainTable(id='%d', domaintable_id='%d', categorytable_id='%d', firstsubd='%s', onlyweekdays='%s', latestupdatetime='%s', latestupdateurl='%s', sourceiconurl='%s', )>" % (self.id, self.domaintable_id, self.categorytable_id, self.firstsubd, self.onlyweekdays, self.latestupdatetime, self.latestupdateurl, self.sourceiconurl )

