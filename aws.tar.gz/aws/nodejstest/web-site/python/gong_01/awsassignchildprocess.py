#! /usr/bin/env python3

from __future__ import print_function
import httplib2
import os
from collections import OrderedDict

from datetime import datetime, timedelta, timezone, date
from pprint import pprint
from gong_01_db import GongAllTable
import sys
import os

import time
import json
import lxml.html


import requests
import argparse
import pymongo
import boto3

parser = argparse.ArgumentParser()
parser.add_argument('inputarg', nargs='*')
argument = parser.parse_args()

print ("argument.inputarg = " , argument.inputarg )

jobid = int(argument.inputarg[0])
mongodburl = argument.inputarg[1]
firstsubdomaintable_id = int(argument.inputarg[2])
domaintable_id = int(argument.inputarg[3])
categorytable_id = int(argument.inputarg[4])
totalarticlecount = int(argument.inputarg[5])
msgcontent = int(argument.inputarg[6])

print(" gong_01 assignchildprocess 1")

#for now.......
response = requests.get('http://localhost:3000/web/doneassign')
print( " +++++++++++++\n\n\n\n",
  "gong_01 assignchildprocess 1.1 response.status_code", 
  response.status_code )
time.sleep(10)
os._exit(0)


gong=GongAllTable('gong.db')
session=gong.init_all_table()

article_list = gong.assignAndgetArticleDict(totalarticlecount)
#change ArticleTable object to regular dict
dict_list = []
for x in article_list :
   indDict = {}
   indDict['_id'] = x.id 
   indDict['rowid'] = x.rowid 
   indDict['id'] = x.id 
   indDict['firstsubdomaintable_id'] = x.firstsubdomaintable_id 
   indDict['finalurl'] = x.finalurl 
   indDict['timestampondoc'] = x.timestampondoc 
   indDict['timestamponretrieve'] = x.timestamponretrieve 
   indDict['title'] = x.title 
   indDict['content'] = x.content 
   indDict['jpegname'] = x.jpegname 
   indDict['imageurl'] = x.imageurl 
   indDict['similaritieslist'] = x.similaritieslist 
   indDict['similaritiescount'] = x.similaritiescount 
   indDict['updatetofirebase'] = x.updatetofirebase 
   indDict['domaintable_id']=domaintable_id
   indDict['categorytable_id']=categorytable_id
   dict_list.append(indDict)

#mongodb_client = pymongo.MongoClient("mongodb+srv://normaluser:abcde12345@cluster0-q3gf2.mongodb.net")
mongodb_client = pymongo.MongoClient(mongodburl)
mongodb_db = mongodb_client.mongodblab
mongodb_articlecollection = mongodb_db.articlecollection
result = mongodb_articlecollection.insert_many(dict_list)

print(" gong_01 assignchildprocess 2")
if len(dict_list) != len(result.inserted_ids) :
   print(" gong_01 assignchildprocess error len does not match")
   exit(-1)

#dynamodb_client = boto3.client('dynamodb', endpoint_url='http://localhost:8000', region_name='us-east-2')
dynamodb_client = boto3.client('dynamodb',
    aws_secret_access_key='vEItH0g8VC5otwQ2Fy6zwXxpgOu2NnkLjjB854M4',
    aws_access_key_id="AKIAJWZT7VQHKKHY2BTQ",
    endpoint_url='http://localhost:8000', region_name='us-east-2')

queryresult = dynamodb_client.list_tables()
if ( queryresult['ResponseMetadata']['HTTPStatusCode'] != 200 ) :
   print(" gong_01 assignchildprocess error list_tables httpstatuscode="+
      queryresult['ResponseMetadata']['HTTPStatusCode'] )
   exit(-1)

print(" gong_01 assignchildprocess 3")
#queryresult = dynamodb_client.describe_table( TableName='articlecollection' )
#queryresult['Table']['ItemCount']
#   ( 'articlecollection' in dynamodb_listoftables and \
#     dynamodb_client.describe_table( TableName='articlecollection' )['Table']['ItemCount'] == 0 ):

dynamodb_table = None
dynamodb_listoftables =dynamodb_client.list_tables()
print(" gong_01 assignchildprocess 3.1= ", dynamodb_listoftables )
if 'articlecollection' not in dynamodb_listoftables['TableNames']  :
   #it does not have the table, create it
   print(" gong_01 assignchildprocess 4")
   dynamodb_table = dynamodb_client.create_table(TableName='articlecollection',
          KeySchema=[ { 'AttributeName' : 'categorytable_id' , 'KeyType' : 'HASH' },
            { 'AttributeName' : 'id' , 'KeyType' : 'RANGE' } ] , 
          AttributeDefinitions=[ { 'AttributeName' : 'id' , 
              'AttributeType' : 'N' },
            { 'AttributeName' : 'categorytable_id' , 'AttributeType' : 'N'} ], 
          ProvisionedThroughput= { 'ReadCapacityUnits' : 1, 
          'WriteCapacityUnits' : 1 } )








print(" gong_01 assignchildprocess 5")
#okay , now has the table, copy the current firstsubdomain information 
# to dynamodb
# need to do the retry on fail   

# normal will use the dict_list, however, for testing purpose,
# it use the download_mongodbarticlelist for now
NO_OF_PER_INSERT = 20


def packSingleItem ( x ) :     
       return { 'PutRequest' : {
          'Item' : {
            'rowid' : { 'N' : str(x['rowid']) },
            'id' : { 'N' : str(x['id']) },
            '_id' : { 'N' : str(x['id']) },
            'firstsubdomaintable_id' : { 'N' : str(x['firstsubdomaintable_id']) },
            'finalurl' : { 'S' : x['finalurl'] },
            'timestampondoc' : { 'N' : str(int(x['timestampondoc'].timestamp())) },
            'timestamponretrieve' : { 'N' : str(int(x['timestamponretrieve'].timestamp()))},
            'title' : { 'S' : x['title'] },
            'content' : { 'S' : \
                  gong.getTokenDailyNewsArticleForAws( x['title'],
                  x['content']) },
            'jpegname' : { "NULL" if x['jpegname'] is None or len(x['jpegname']) == 0 else "S" : True if x['jpegname'] is None or len(x['jpegname']) == 0 else x['jpegname'] },
            'imageurl' : { "NULL" if x['imageurl'] is None or len(x['imageurl']) == 0 else "S" : True if x['imageurl'] is None or len(x['imageurl']) == 0 else x['imageurl'] },
            'similaritieslist' : { "NULL" if x['similaritieslist'] is None or len(x['similaritieslist']) == 0 else "S" : True if x['similaritieslist'] is None or len(x['similaritieslist']) == 0 else x['similaritieslist'] },
            'similaritiescount' : { "NULL" if x['similaritiescount'] is None else "N" : True if x['similaritiescount'] is None else str(x['similaritiescount']) },
            'updatetofirebase' : { "NULL" if x['updatetofirebase'] is None else "N" : True if x['updatetofirebase'] is None else str(x['updatetofirebase']) },
            'domaintable_id' : { 'N' : str(x['domaintable_id']) },
            'categorytable_id' : { 'N' : str(x['categorytable_id']) },
          },
        },
       }


def writeToAWS ( putrequest_list )  :
  #let start write 
  print(" gong_01 assignchildprocess writeToAWS 1")
  writeresult = dynamodb_client.batch_write_item (
      RequestItems= {
        'articlecollection' : putrequest_list }
      )
  # 
  print(" gong_01 assignchildprocess writeToAWS 2")
  if "UnprocessedItems" in writeresult and len(writeresult["UnprocessedItems"]) > 0 :
      #there are some unprocesseditems, use for loop to insert it one by one
      print(" gong_01 assignchildprocess warning UnprocessedItems " +
             " in writeresult ", 
             writeresult["UnprocessedItems"] )
      print(" gong_01 assignchildprocess warning UnprocessedItems " +
             " in writeresult with len=", 
             len(writeresult["UnprocessedItems"]["articlecollection"]) )
      for x in writeresult["UnprocessedItems"]["articlecollection"] :
         retrySend=True
         sleeptime=1
         while (retrySend) :
            time.sleep(sleeptime)
            sleeptime +=1
            print(" gong_01 assignchildprocess writeToAWS after sleep")
            ind_writeresult =  dynamodb_client.put_item ( \
               TableName = "articlecollection",
               Item = x['PutRequest']['Item'] ,
               ReturnConsumedCapacity='TOTAL',
            )
            if ind_writeresult['ResponseMetadata']['HTTPStatusCode'] == 200 :
               print(" gong_01 assignchildprocess warning retry single item " +
                 " ,id=" ,x['PutRequest']['Item']['id'] )
               retrySend=False 
    
"""
#do the main part 
len_dict_list = len(dict_list)
for y in range(0, len_dict_list, NO_OF_PER_INSERT) :
  putrequest_list = []
  for x in dict_list[y:y+NO_OF_PER_INSERT]:
    putrequest_item = packSingleItem( x )
    putrequest_list.append(putrequest_item)
  print(" gong_01 assignchildprocess calling main writeToAWS ")
  writeToAWS ( putrequest_list )  


#do the remain part 
len_dict_list = len(dict_list)
putrequest_list = []
for x in dict_list[-(len_dict_list%NO_OF_PER_INSERT):]:
    putrequest_item = packSingleItem( x )
    putrequest_list.append(putrequest_item)

print(" gong_01 assignchildprocess calling remain writeToAWS ")
writeToAWS ( putrequest_list )  
"""


print(" gong_01 assignchildprocess done ")
   
   
if True :   
   download_mongodbarticlelist = None   
   # copy data from mongodb to dynamodb because it is new
   if categorytable_id == 2 or categorytable_id == 3 :
      download_mongodbarticlelist =  mongodb_articlecollection.find( \
         { "$or" : [ { 'categorytable_id' : { "$eq" : 2 } },
         { 'categorytable_id' : { "$eq" : 3 } } ] } )

   if categorytable_id == 5 or categorytable_id == 6 :
      download_mongodbarticlelist =  mongodb_articlecollection.find( \
         { "$or" : [ { 'categorytable_id' : { "$eq" : 6 } },
         { 'categorytable_id' : { "$eq" : 6 } } ] } )

   if categorytable_id == 7  :
      download_mongodbarticlelist =  mongodb_articlecollection.find( \
         { 'categorytable_id' : { "$eq" : 7 } } )

   if categorytable_id == 8  :
      download_mongodbarticlelist =  mongodb_articlecollection.find( \
         { 'categorytable_id' : { "$eq" : 8 } } )


   if download_mongodbarticlelist is None :
     print(" gong_01 assignchildprocess error download_mongodbarticlelist " +
           "is None" )
     exit(-1)
   
   print(" gong_01 assignchildprocess download_mongodbarticlelist= ",
       download_mongodbarticlelist.count())
   dict_list = []
   for x in download_mongodbarticlelist.sort("id", pymongo.ASCENDING) :
     indDict = {}
     indDict['rowid'] = x['rowid'] 
     indDict['id'] = x['id'] 
     indDict['_id'] = x['id'] 
     indDict['firstsubdomaintable_id'] = x['firstsubdomaintable_id'] 
     indDict['finalurl'] = x['finalurl'] 
     indDict['timestampondoc'] = x['timestampondoc'] 
     indDict['timestamponretrieve'] = x['timestamponretrieve'] 
     indDict['title'] = x['title'] 
     indDict['content'] = x['content'] 
     indDict['jpegname'] = x['jpegname'] 
     indDict['imageurl'] = x['imageurl'] 
     indDict['similaritieslist'] = x['similaritieslist'] 
     indDict['similaritiescount'] = x['similaritiescount'] 
     indDict['updatetofirebase'] = x['updatetofirebase'] 
     indDict['domaintable_id']= x['domaintable_id']
     indDict['categorytable_id']= x['categorytable_id']
     dict_list.append(indDict)


#do the main part 
len_dict_list = len(dict_list)
print(" gong_01 assignchildprocess len_dict_list= ", len_dict_list)
for y in range(0, len_dict_list, NO_OF_PER_INSERT) :
  putrequest_list = []
  print(" gong_01 assignchildprocess start y= ", y)
  for x in dict_list[y:y+NO_OF_PER_INSERT]:
    putrequest_item = packSingleItem( x )
    putrequest_list.append(putrequest_item)
  print(" gong_01 assignchildprocess calling main writeToAWS ")
  writeToAWS ( putrequest_list )  


#do the remain part 
len_dict_list = len(dict_list)
putrequest_list = []
for x in dict_list[-(len_dict_list%NO_OF_PER_INSERT):]:
    putrequest_item = packSingleItem( x )
    putrequest_list.append(putrequest_item)
print(" gong_01 assignchildprocess calling remain writeToAWS ")
writeToAWS ( putrequest_list )  


"""
queryresult = dynamodb_client.query( TableName='articlecollection', KeyConditionExpression=' id > :X1 AND categorytable_id = :X2', ExpressionAttributeValues={ ':X1' : { 'N' : '16' }, ':X2' : { "N" : "3" } } , ExclusiveStartKey=queryresult['LastEvaluatedKey']  )
queryresult['LastEvaluatedKey']
import copy
dup_queryresult_items += copy.deepcopy(queryresult['Items'])

  
finalqueryresult =[]
endquery = True
queryresult = {}
while (endquery) :
  if len(finalqueryresult) == 0 :
    queryresult = dynamodb_client.query( TableName='articlecollection', 
      KeyConditionExpression=' id > :X1 AND categorytable_id = :X2 ', 
      ExpressionAttributeValues={ ':X1' : { 'N' : '0' }, ':X2' : { "N" : "3" } })
  else :
    queryresult = dynamodb_client.query( TableName='articlecollection', 
      KeyConditionExpression=' id > :X1 AND categorytable_id = :X2 ', 
      ExpressionAttributeValues={ ':X1' : { 'N' : '0' }, ':X2' : { "N" : "3" } },
    ExclusiveStartKey=queryresult['LastEvaluatedKey'] )
  if 'Items' in queryresult and len(queryresult['Items']) > 0 :
    finalqueryresult += queryresult['Items']
  else :
    print ("error error , it should have something")
    #exit(-1)
  if 'LastEvaluatedKey' not in queryresult :
    endquery=False







"""

