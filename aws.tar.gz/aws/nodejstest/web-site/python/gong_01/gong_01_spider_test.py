import time
import scrapy
import json
import base64
from scrapy_splash import SplashRequest
#from scrapy import Selector
from datetime import datetime, timedelta,timezone
import re
#from gong_01_db import GongAllTable
#from gong_01_generic_source import *

class GongGenericSource() :
  base_url = 'hello:GongGenericSource'
  log_main_jpeg = False
  log_main_html = False
  log_item_jpeg = False
  log_item_html = False
  itemParseIt = False
  endpointexecute = 'render.json'
  endpointexecute_item = 'render.json'
  numOfYieldRequestLimit = 20
  dopagination = False
  splash_args = {
            'html': 1,
            'jpeg': 1,
            'width': 600,
            'render_all': 1,
            'wait' : 15,
    }
  splash_args_item = splash_args
  max_retry_times = 10
  secondtryItemTime = False

  def parse_result_func (self, response) :
    print (' GongGenericSource : ---- > parse_result_func')

  def parse_result_item_func (self, response) :
    print (' GongGenericSource : ---- > parse_result_item_func')

  def get_endpoint(self) :
    print (' GongGenericSource : ---- > get_endpoint')

  def get_splash_args (self) :
    print (' GongGenericSource : ---- > get_splash_args')

  def get_splash_args_item (self) :
    print (' GongGenericSource : ---- > get_splash_args')


  def get_newsItemList (self, resp=None, info=None) :
    print (' GongGenericSource : ---- > get_newsItemList')

  def get_indNewsItemURL (self, itemtext, base_url=None) :
    print (' GongGenericSource : ---- > get_indNewsItemURL')

  def get_indNewsItemTitle (self, itemtext) :
    print (' GongGenericSource : ---- > get_indNewsItemTitle')

  def get_indNewsItemTime (self, iteminfo, url=None, iyear=None, imonth=None, iday=None) :
    print (' GongGenericSource : ---- > get_indNewsItemTime')

  def get_dopagination (self, response) :
    print (' GongGenericSource : ---- > get_dopagination')

  def get_havenextpage (self, response) :
    print (' GongGenericSource : ---- > get_havenextpage')
    return True

  def get_newPageURL (self, response) :
    print (' GongGenericSource : ---- > get_newPageURL')

  def get_itemParseIt (self) :
    print (' GongGenericSource : ---- > get_itemParseIt')

  def get_secondItemTime(self, response):
    print (' GongGenericSource : ---- > get_seconditemtime')

  def get_articleContent (self, response) :
    print (' GongGenericSource : ---- > get_newPageURL')

  def get_parseImageURL (self, response) :
    print (' GongGenericSource : ---- > get_parseImageURL')



################## on.cc latestnews  
class OrientaldailyNetLatestNewsParser(GongGenericSource) :
  base_url = 'http://hk.on.cc'
  #log_main_jpeg = False
  #log_main_html = False
  #log_item_jpeg = False
  #log_item_html = False
  #itemParseIt = False
  endpointexecute = 'execute'
  #self.numOfYieldRequestLimit = 20
  #self.dopagination = True

    ####   on_cc_latestnews
  script_org_on_cc_latestnews = """
function main(splash, args)
    treat = require("treat")
    local num_scrolls = 10
    local scroll_delay = 5

    local scroll_to = splash:jsfunc("window.scrollTo")
    local get_body_height = splash:jsfunc(
        "function() {return document.body.scrollHeight;}"
    )
    local log_iteration = splash:jsfunc(
        "function(number_log) {return document.title=number_log;}"
    )

    local num_of_div_class_seq = splash:jsfunc( [[
          function() {
            var seqstringlist = document.evaluate('//div[@class="seq"]', document , null, XPathResult.ANY_TYPE, null);
            var seqstring = seqstringlist.iterateNext();
            var seqstringcount =0;
            while (seqstring) {
              seqstringcount = seqstringcount +1;
              seqstring = seqstringlist.iterateNext() ;
            }
            return seqstringcount;
          }
     ]])
    -- splash:go( 'http://spidyquotes.herokuapp.com/scroll')
    --splash:set_user_agent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36')
    splash:set_user_agent('Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.140 Safari/537.36')
    -- splash:go( 'https://hk.news.yahoo.com/hong-kong/archive')
    -- splash:go( args.url)
    -- splash:go("https://hk.on.cc/hk/news/index.html" )
    splash:go("https://hk.on.cc" )
    -- error(' hello on.cc 0' )
    splash:wait(3)
    width, height=splash:set_viewport_full()
    splash:wait(3)
    splash:runjs(' document.title="hello world";')
    local result={}
    result['num_scrolls']= num_scrolls
    result['inside_width']= width
    result['inside_height']= height
    local check_div=0


    local addfooter= splash:select('#footer')
    assert(splash:select('#footer'))
    splash:select('#footer'):scrollIntoViewIfNeeded()
    addfooter:mouse_click()
    splash:wait(10)

--    splash:select('#breakingnewsContent'):scrollIntoViewIfNeeded()
    splash:select('#breakingnewsTab'):scrollIntoViewIfNeeded()
    assert(splash:select('#breakingnewsTab'))
    local breakingnewstab= splash:select('#breakingnewsTab')
    breakingnewstab:mouse_click()
    splash:wait(15)
    local addtabcontent= splash:select('#tabContent')
    assert(splash:select('#tabContent'))
    addtabcontent:mouse_click()
    splash:select('#tabContent'):scrollIntoViewIfNeeded()

    local count_num_scroll=0
--    for num_scroll = 0, num_scrolls do
--        scroll_to(0, get_body_height())
--        splash:wait(scroll_delay)
--        count_num_scroll= 1 + count_num_scroll
--    end  


    for num_scroll = 0, num_scrolls do
--       log_class_seq(num_scroll)
--
         --if (num_scroll /10) then
         --  check_div= num_of_div_class_seq()
--           if (check_div > 1)then
--             break
--           end
         --end
--       scroll_to(0, get_body_height())
--       splash:wait(scroll_delay)
         splash:select('#footer'):scrollIntoViewIfNeeded()
         splash:wait(scroll_delay)
         footerselect = splash:select('#footer')
         footerselect:mouse_click()
    end    
    --check_div=num_of_div_class_seq()
    local name_html= "lua_scroll_html"
    result[name_html]=splash:html()
    --error(' hello on.cc 1' )
    result['jpeg']=splash:jpeg()
    result['check_div']= check_div
    result['count_num_scroll']= count_num_scroll
    return result
end
                   """
  splash_args = {
            'html': 1,
            'width': 600,
            'render_all': 1,
            'wait' : 20,
            'timeout' : 350,
            'lua_source' : script_org_on_cc_latestnews,
    }
  splash_args_item = {
            'html': 1,
            'width': 600,
            'render_all': 1,
            'wait' : 15,
            'js_source' : ' var elements = document.getElementsByClassName("video") ; elements[0].parentNode.removeChild(elements[0]); '
    }





  def get_endpoint(self) :
    print (' GongGenericSource : ---- > get_endpoint')
    return self.endpointexecute

  def get_newsItemList (self, resp=None, info=None) :
    print (' orientaldailynetlatestnewsparser : ---- > get_newsItemList')
    return scrapy.Selector(text=info).xpath('//div[contains(@class,"focus clearfix") and not(contains(@class, "gemini-loaded"))]').extract()


  def get_indNewsItemURL (self, itemtext, base_url=None) :
    print (' orientaldailynetlatestnewsparser : ---- > get_indNewsItemURL')
    return self.base_url + (scrapy.Selector(text=itemtext).xpath('//div[@class="thumb"]/a/@href').extract_first()  )


  def get_indNewsItemTitle (self, itemtext) :
    print (' orientaldailynetlatestnewsparser : ---- > get_indNewsItemTitle')
    return scrapy.Selector(text=itemtext).xpath('//div[@class="thumb"]/a/@title').extract_first()
 
  def get_indNewsItemTime (self, iteminfo, url=None, iyear=None, imonth=None, iday=None) :
      indNewsItemHourandMin = scrapy.Selector(text=iteminfo).xpath('//div[@class="datetime"]/a/text()').extract_first().strip()[10:15].split(':')
      indNewsItemMonthandDay = scrapy.Selector(text=iteminfo).xpath('//div[@class="datetime"]/a/text()').extract_first().strip()[:5]

      indNewsItemMonth = indNewsItemMonthandDay[:2]
      indNewsItemDay = indNewsItemMonthandDay[3:]

      self.nowTime= datetime.now(timezone(timedelta(hours=8)))
      indNewsItemTime= datetime( self.nowTime.year,
                                    int(indNewsItemMonth),
                                    int(indNewsItemDay),
                                    int(indNewsItemHourandMin[0]),
                                    int(indNewsItemHourandMin[1]),
                                    0,
                                    tzinfo=timezone(timedelta(hours=8)))
      return indNewsItemTime


 
  #def get_dopagination (self, response) :
  #  print (' orientaldailynetlatestnewsparser : ---- > get_dopagination')

  #def get_newPageURL (self, response) :
  #  print (' orientaldailynetlatestnewsparser : ---- > get_newPageURL')
 
  #def get_itemParseIt (self) :
  #  print (' orientaldailynetlatestnewsparser : ---- > get_itemParseIt')
 
  def get_articleContent (self, response) :
    print (' orientaldailynetlatestnewsparser : ---- > get_newPageURL')
    articleParagraphList = response.xpath('//div[@class="leftSide"]/div[@class="breakingNewsContent"]/p[@class="summary"]').extract()

    articleContent = ''.join([ x.strip() for x in articleParagraphList])
    if len(articleContent.strip()) < 1 :
      articleContent = response.request.meta['indNewsItemTitle']

    return articleContent
    
 
  def get_parseImageURL (self, response) :
    print (' orientaldailynetlatestnewsparser : ---- > get_parseImageURL')
    parseImageURL = response.xpath('//div[@id="centerCTN"]//div[@class="photoCTN"]//img/@src').extract_first()
    if parseImageURL is not None and len(parseImageURL) == 0 :
       parseImageURL=None
    else :
       parseImageURL = 'http://hk.on.cc' + parseImageURL

    return parseImageURL 









class Gong01Spider(scrapy.Spider):
    name = "gong_01"


    def start_requests(self):
        self.log('------------------ start_requests 1')
        self.nowTime= datetime.now(timezone(timedelta(hours=8)))
        print('----> starting gong_01.py time=', self.nowTime)
        self.nowTime = self.nowTime - timedelta(hours=14) 
        print('----> starting gong_01.py modifytime=', self.nowTime)
        latestupdatetime=self.nowTime
        sNewsParser = OrientaldailyNetLatestNewsParser()

        yield SplashRequest("http://hk.on.cc/hk/news/index.html", 
                            self.parse_result_main_webpage, 
                            endpoint=sNewsParser.endpointexecute,
                            args=sNewsParser.splash_args,
                            meta={
                             'max_retry_times' : \
                                 sNewsParser.max_retry_times ,
                             'domain' : ('orientaldaily_net','latestnews'),
                             'latestupdatetime' : latestupdatetime ,
                             'sourcenewsparser' : \
                                 sNewsParser,
                              ('orientaldaily_net','latestnews') : [10,"http://hk.on.cc/hk/news/index.html" ],
                            })




############# the following is for main webpage parse_result
    def parse_result_main_webpage(self, response):
        #self.log('------------------ parse_result_main_webpage 1')
        # magic responses are turned ON by default,
        # so the result under 'html' key is available as response.body
        html = response.body

        if 'lua_scroll_html' in response.data :
          info_html=response.data['lua_scroll_html']
        else :
          info_html = None
        if 'lua_nowtime' in response.data :
          lua_nowtime = response.data['lua_nowtime']
        else :
          lua_nowtime = None 

        #get latest time
        domain_key= response.request.meta['domain']
        domain_key_value = response.request.meta[domain_key]
        latestupdatetime = response.request.meta['latestupdatetime']
        sourceNewsParser = response.request.meta['sourcenewsparser']

        #self.log('------------------ parse_result_main_webpage 3len=%d'%len(info_html))
        #self.log('------------------ parse_result_main_webpage 3info_html=%s'%info_html[:100])

        newsItemList = sourceNewsParser.get_newsItemList(resp=response, info=info_html)
        #newsItemList =  scrapy.Selector(text=info_html).xpath('//div[@class="cat12"]//ul[contains(@class,"twocol") and contains(@class, "left")]/div[@class="date"] | //div[@class="cat12"]//ul[contains(@class,"twocol") and contains(@class, "left")]/li[@class="list1"]').extract()


        nowTime= datetime.now(timezone(timedelta(hours=8)))
        indNewsItemYear = nowTime.year
        indNewsItemMonth = nowTime.month
        indNewsItemDay = nowTime.day

        base_url= sourceNewsParser.base_url 
        update_indicator=True
        numOfYieldRequest=0 
        #self.log('------------------ parse_result_main_webpage 4')
        for indNewsAboutArticleRow in newsItemList :
          check_date = scrapy.Selector(text=indNewsAboutArticleRow).xpath('//div[@class="date"]/b/text()').extract_first()

          if (check_date is not None) and (len(check_date) > 0):
            #this is the date element
            indNewsItemYear=check_date[3:7]
            indNewsItemMonthandDay=check_date[8:].split('月')
            indNewsItemMonth= indNewsItemMonthandDay[0]
            indNewsItemDay =  indNewsItemMonthandDay[1][:-1]
            continue


          indNewsItemURL = sourceNewsParser.get_indNewsItemURL(indNewsAboutArticleRow)
          indNewsItemTitle = sourceNewsParser.get_indNewsItemTitle(indNewsAboutArticleRow)
          self.log('------------------ parse_result_main_webpage 4.1 %s ' % indNewsItemTitle)
          self.log('------------------ parse_result_main_webpage 4.2 %s ' % indNewsItemURL)
          self.log('------------------ parse_result_main_webpage 5 = %d'% numOfYieldRequest)

          indNewsItemTime= sourceNewsParser.get_indNewsItemTime(indNewsAboutArticleRow, url=indNewsItemURL, iyear=indNewsItemYear, imonth=indNewsItemMonth, iday=indNewsItemDay)
          self.log('------------------ parse_result_main_webpage 5.5 indNewsItemTime=%s latestupdatetime=%s'% (indNewsItemTime, latestupdatetime.replace(tzinfo=timezone(timedelta(hours=8))) ))
          if (indNewsItemTime > latestupdatetime.replace(tzinfo=timezone(timedelta(hours=8))))  :
            self.log('------------------ parse_result_main_webpage 6 =%s'% str(indNewsItemTime))
            if update_indicator :
              update_indicator=False
            
            numOfYieldRequest += 1
            #self.log('------------------ parse_result_main_webpage 7 =%d'% numOfYieldRequest)
            #test 
            if numOfYieldRequest > 0 :
              yield SplashRequest(indNewsItemURL, 
                            self.parse_result_main_item, 
                            endpoint= sourceNewsParser.endpointexecute_item,
                            args= sourceNewsParser.splash_args_item,
                            meta={
                             'indNewsItemURL' : indNewsItemURL ,
                             'indNewsItemTitle' : indNewsItemTitle ,
                             'indNewsItemTime' : indNewsItemTime ,
                             'domain' : domain_key,
                             domain_key : domain_key_value,
                             'sourcenewsparser' : sourceNewsParser
                            })
        info_jpeg=response.data['jpeg']   
        jpeg_bytes = base64.b64decode(info_jpeg)
        firstdomainfilename = re.sub(r'/', '', response.url)
        firstdomainfilename = re.sub(r'\?', '', firstdomainfilename)
        firstdomainfilename = re.sub(r'\&', '', firstdomainfilename)
        firstdomainfilename = re.sub(r'\=', '', firstdomainfilename)
        firstdomainfilename = re.sub(r'\:', '', firstdomainfilename)
        self.log('------------------ parse_result_main_webpage 7.4=%s '% firstdomainfilename)
        filename_jpeg = domain_key[0] + '-' + domain_key[1] + \
             '-' + firstdomainfilename + '.jpeg'
        self.log('------------------ parse_result_main_webpage 7.5=%s '% filename_jpeg)
        with open(filename_jpeg , 'wb') as f:
          f.write(jpeg_bytes)


        """
        filename_html = domain_key[0] + '-' + domain_key[1] + \
             '-'  + '.html'
        with open(filename_html , 'w') as f:
          f.write(str(html))
        """
       
 
        #deal with pagination    
        #check for pagination
        if sourceNewsParser.dopagination and (numOfYieldRequest >= sourceNewsParser.numOfYieldRequestLimit) and sourceNewsParser.get_havenextpage(response) :
          #the last article still newer than the latestupdate time, so go to page 2
          self.log('------------------ parse_result_main_webpage 9 =%s'% response.url)
          newPageURL = sourceNewsParser.get_newPageURL(response)
          self.log('------------------ parse_result_main_webpage 10 =%s'% newPageURL)
          
          yield SplashRequest(newPageURL, 
                            self.parse_result_main_webpage, 
                            endpoint= sourceNewsParser.endpointexecute,
                            args= sourceNewsParser.splash_args,
                            meta={
                             'max_retry_times' : \
                                 sourceNewsParser.max_retry_times ,
                             'domain' : domain_key,
                             domain_key : domain_key_value,
                             'latestupdatetime' : latestupdatetime ,
                             'sourcenewsparser' : \
                                 sourceNewsParser
                            })




    def parse_result_main_item(self, response):
        #self.log('------------------ parse_result_main_item 1')
        # magic responses are turned ON by default,
        # so the result under 'html' key is available as response.body
        html = response.body
        #self.log('------------------ parse_result_main_item 2')

        #get latest time
        domain_key= response.request.meta['domain']
        domain_key_value = response.request.meta[domain_key]
        indNewsItemURL = response.request.meta['indNewsItemURL']
        indNewsItemTitle = response.request.meta['indNewsItemTitle']
        indNewsItemTime = response.request.meta['indNewsItemTime']
        sourceNewsParser = response.request.meta['sourcenewsparser']

        if sourceNewsParser.secondtryItemTime :
          indNewsItemTime = sourceNewsParser.get_secondItemTime(response)
          

        #self.log('------------------ parse_result_main_item 3')
        articleContent = sourceNewsParser.get_articleContent(response)
        parseImageURL = sourceNewsParser.get_parseImageURL(response)
        self.log('------------------ parse_result_main_item 3.1 articleContent=%s'% articleContent[:100])
        self.log('------------------ parse_result_main_item 3.2 parseImageURL=%s'% parseImageURL)

        
        filename_jpeg=None 
        """
        info_jpeg=response.data['jpeg']   
        jpeg_bytes = base64.b64decode(info_jpeg)
        titleString = re.sub(r'/','',indNewsItemTitle)
        filename_jpeg = domain_key[0] + '-' + domain_key[1] + \
             indNewsItemTime.strftime('%Y-%m-%d-%H-%M-%S') + \
             '-' + titleString + '.jpeg'
        with open(filename_jpeg , 'wb') as f:
          f.write(jpeg_bytes)
        self.log('------------------ parse_result_now_latestnews_item 4 filename=%s'% filename_jpeg)
 
        info_html=response.data['html']   
        titleString = re.sub(r'/','',indNewsItemTitle)
        filename_html = domain_key[0] + '-' + domain_key[1] + \
             indNewsItemTime.strftime('%Y-%m-%d-%H-%M-%S') + \
             '-' + titleString + '.html'
        with open(filename_html , 'w') as f:
          f.write(info_html)
        self.log('------------------ parse_result_standnews_latestnews_item 4.1 filename=%s'% filename_html)
        """


        self.log(' ----> domain_key_value[0]=%s'%domain_key_value[0]) 
        self.log(' ----> indNewsItemURL=%s'%indNewsItemURL) 
        self.log(' ----> indNewsItemTime=%s'%indNewsItemTime) 
        self.log(' ----> indNewsItemTitle=%s'%indNewsItemTitle) 
        self.log(' ----> articleContent=%s'%articleContent[:100]) 
        self.log(' ----> parseImageURL=%s'%parseImageURL) 
         
        self.log('------------------ parse_result_main_item 5 result=%s'% " ok")














