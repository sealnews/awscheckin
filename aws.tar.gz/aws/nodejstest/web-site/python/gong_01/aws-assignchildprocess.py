#! /usr/bin/env python3

from __future__ import print_function
import httplib2
import os
from collections import OrderedDict

from datetime import datetime, timedelta, timezone, date
from pprint import pprint
from gong_01_db import GongAllTable
import sys
import os

import time
import json
import lxml.html


import requests
import argparse
import pymongo
import boto3

from pymongo.errors import BulkWriteError

parser = argparse.ArgumentParser()
parser.add_argument('inputarg', nargs='*')
argument = parser.parse_args()

print ("argument.inputarg = " , argument.inputarg )

jobid = int(argument.inputarg[0])
mongodburl = argument.inputarg[1]
firstsubdomaintable_id = int(argument.inputarg[2])
domaintable_id = int(argument.inputarg[3])
categorytable_id = int(argument.inputarg[4])
totalarticlecount = int(argument.inputarg[5])
startidforarticle = int(argument.inputarg[6]) +1

if 'RUNNINGSERVERCHECK' not in os.environ :
  localornot = 'local'
elif 'RUNNINGSERVERCHECK' in os.environ  and os.environ['RUNNINGSERVERCHECK'] == 'AWS' :
  localornot = 'remote'
else : 
  localornot = 'local'


print(" gong_01 assignchildprocess 1")

"""
#for now.......
response = requests.get('http://localhost:3000/web/doneassign')
print( " +++++++++++++\n\n\n\n",
  "gong_01 assignchildprocess 1.1 response.status_code", 
  response.status_code )
time.sleep(10)
os._exit(0)
"""

gong=GongAllTable('gong.db')
session=gong.init_all_table()

article_list = gong.assignAndgetArticleDict(startidforarticle)
if len(article_list) == 0 :
  response = requests.get('http://localhost:3000/web/doneassign')
  print( " +++++++++++++\n\n\n\n",
    "gong_01 assignchildprocess 1.1 response.status_code",
    response.status_code )
  print(" gong_01 assignchildprocess done ")
  os._exit(0)
   


#change ArticleTable object to regular dict
dict_list = []
for x in article_list :
   indDict = {}
   indDict['_id'] = x.id 
   indDict['rowid'] = x.rowid 
   indDict['id'] = x.id 
   indDict['firstsubdomaintable_id'] = x.firstsubdomaintable_id 
   indDict['finalurl'] = x.finalurl 
   indDict['timestampondoc'] = x.timestampondoc 
   indDict['timestamponretrieve'] = x.timestamponretrieve 
   indDict['title'] = x.title 
   indDict['content'] = x.content 
   indDict['jpegname'] = x.jpegname 
   indDict['imageurl'] = x.imageurl 
   indDict['similaritieslist'] = x.similaritieslist 
   indDict['similaritiescount'] = x.similaritiescount 
   indDict['updatetofirebase'] = x.updatetofirebase 
   indDict['domaintable_id']=domaintable_id
   indDict['categorytable_id']=categorytable_id
   dict_list.append(indDict)

#mongodb_client = pymongo.MongoClient("mongodb+srv://normaluser:abcde12345@cluster0-q3gf2.mongodb.net")
mongodb_client = pymongo.MongoClient(mongodburl)
mongodb_db = mongodb_client.mongodblab
mongodb_articlecollection = mongodb_db.articlecollection

result=0
print (" gong_01 assignchildprocess len(dict_list) = ", len(dict_list) )
#insert data from sqlite to mongodb
try :
  result = mongodb_articlecollection.insert_many(dict_list)
except BulkWriteError as err :
  print ("BulkWriteError as err  1 ")
  print (err.details)
  print ("BulkWriteError as err  2 ")

print(" gong_01 assignchildprocess 2")
if result == 0 or len(dict_list) != len(result.inserted_ids) :
   print(" gong_01 assignchildprocess error len does not match")
   exit(-1)

#dynamodb_client = boto3.client('dynamodb', endpoint_url='http://localhost:8000', region_name='us-east-2')
if localornot == 'local' :
  print(" gong_01 aws-downloadmongotoaws 1.1")
  dynamodb_client = boto3.client('dynamodb',
    aws_secret_access_key='vEItH0g8VC5otwQ2Fy6zwXxpgOu2NnkLjjB854M4',
    aws_access_key_id="AKIAJWZT7VQHKKHY2BTQ",
    endpoint_url='http://localhost:8000', region_name='us-east-2')
else :
  print(" gong_01 aws-downloadmongotoaws 1.2")
  dynamodb_client = boto3.client('dynamodb',
    aws_secret_access_key='vEItH0g8VC5otwQ2Fy6zwXxpgOu2NnkLjjB854M4',
    aws_access_key_id="AKIAJWZT7VQHKKHY2BTQ",
     region_name='us-east-2')






queryresult = dynamodb_client.list_tables()
if ( queryresult['ResponseMetadata']['HTTPStatusCode'] != 200 ) :
   print(" gong_01 assignchildprocess error list_tables httpstatuscode="+
      queryresult['ResponseMetadata']['HTTPStatusCode'] )
   exit(-1)

print(" gong_01 assignchildprocess 3")
#queryresult = dynamodb_client.describe_table( TableName='articlecollection' )
#queryresult['Table']['ItemCount']
#   ( 'articlecollection' in dynamodb_listoftables and \
#     dynamodb_client.describe_table( TableName='articlecollection' )['Table']['ItemCount'] == 0 ):

dynamodb_table = None
dynamodb_listoftables =dynamodb_client.list_tables()
print(" gong_01 assignchildprocess 3.1= ", dynamodb_listoftables )
if 'articlecollection' not in dynamodb_listoftables['TableNames']  :
   #it does not have the table, create it
   print(" gong_01 assignchildprocess 4")
   dynamodb_table = dynamodb_client.create_table(TableName='articlecollection',
          KeySchema=[ { 'AttributeName' : 'categorytable_id' , 'KeyType' : 'HASH' },
            { 'AttributeName' : 'id' , 'KeyType' : 'RANGE' } ] , 
          AttributeDefinitions=[ { 'AttributeName' : 'id' , 
              'AttributeType' : 'N' },
            { 'AttributeName' : 'categorytable_id' , 'AttributeType' : 'N'} ], 
          ProvisionedThroughput= { 'ReadCapacityUnits' : 1, 
          'WriteCapacityUnits' : 1 } )








print(" gong_01 assignchildprocess 5")
#okay , now has the table, copy the current firstsubdomain information(article
# information from sqlite) to dynamodb 
# to dynamodb
# need to do the retry on fail   

# normal will use the dict_list, however, for testing purpose,
# it use the download_mongodbarticlelist for now
NO_OF_PER_INSERT = 15


def packSingleItem ( x ) :     
       return { 'PutRequest' : {
          'Item' : {
            'rowid' : { 'N' : str(x['rowid']) },
            'id' : { 'N' : str(x['id']) },
            '_id' : { 'N' : str(x['id']) },
            'firstsubdomaintable_id' : { 'N' : str(x['firstsubdomaintable_id']) },
            'finalurl' : { 'S' : x['finalurl'] },
            'timestampondoc' : { 'N' : str(int(x['timestampondoc'].timestamp())) },
            'timestamponretrieve' : { 'N' : str(int(x['timestamponretrieve'].timestamp()))},
            'title' : { 'S' : x['title'] },
            'content' : { 'S' : \
                  gong.getTokenDailyNewsArticleForAws( x['title'],
                  x['content']) },
            'jpegname' : { "NULL" if x['jpegname'] is None or len(x['jpegname']) == 0 else "S" : True if x['jpegname'] is None or len(x['jpegname']) == 0 else x['jpegname'] },
            'imageurl' : { "NULL" if x['imageurl'] is None or len(x['imageurl']) == 0 else "S" : True if x['imageurl'] is None or len(x['imageurl']) == 0 else x['imageurl'] },
            'similaritieslist' : { "NULL" if x['similaritieslist'] is None or len(x['similaritieslist']) == 0 else "S" : True if x['similaritieslist'] is None or len(x['similaritieslist']) == 0 else x['similaritieslist'] },
            'similaritiescount' : { "NULL" if x['similaritiescount'] is None else "N" : True if x['similaritiescount'] is None else str(x['similaritiescount']) },
            'updatetofirebase' : { "NULL" if x['updatetofirebase'] is None else "N" : True if x['updatetofirebase'] is None else str(x['updatetofirebase']) },
            'domaintable_id' : { 'N' : str(x['domaintable_id']) },
            'categorytable_id' : { 'N' : str(x['categorytable_id']) },
          },
        },
       }


import random
from botocore.exceptions import ClientError
RETRY_EXCEPTIONS = ('ProvisionedThroughputExceededException',
                    'ThrottlingException')


def writeToAWS ( putrequest_list )  :
  #let start write 
  print(" gong_01 assignchildprocess writeToAWS 1")
  try :
     print(" gong_01 assignchildprocess writeToAWS 1.1")
     writeresult = dynamodb_client.batch_write_item (
         RequestItems= {
           'articlecollection' : putrequest_list }
         )
     print(" gong_01 assignchildprocess writeToAWS 1.2")
  except ClientError as e :
           print(" gong_01 assignchildprocess writeToAWS ",
              " ClientError only e=", e)
           print(" gong_01 assignchildprocess writeToAWS ",
              " ClientError only e=", e, file=sys.stderr )
           writeToAWSOneByOne ( putrequest_list ) 
           return 

  # 
  print(" gong_01 assignchildprocess writeToAWS 2")
  if "UnprocessedItems" in writeresult and len(writeresult["UnprocessedItems"]) > 0 :
        #there are some unprocesseditems, use for loop to insert it one by one
        print(" gong_01 assignchildprocess warning UnprocessedItems " +
             " in writeresult ", 
             writeresult["UnprocessedItems"] )
        print(" gong_01 assignchildprocess warning UnprocessedItems " +
             " in writeresult with len=", 
             len(writeresult["UnprocessedItems"]["articlecollection"]) )
        for x in writeresult["UnprocessedItems"]["articlecollection"] :
           retrySend=True
           sleeptime=10
           while (retrySend) and sleeptime < 200 :
             try :
              time.sleep(sleeptime)
              sleeptime +=1
              print(" gong_01 assignchildprocess writeToAWS after sleep")
              ind_writeresult =  dynamodb_client.put_item ( \
                 TableName = "articlecollection",
                 Item = x['PutRequest']['Item'] ,
                 ReturnConsumedCapacity='TOTAL',
              )
              if ind_writeresult['ResponseMetadata']['HTTPStatusCode'] == 200 :
                 print(" gong_01 assignchildprocess warning retry single item " +
                 " ,id=" ,x['PutRequest']['Item']['id'] )
                 retrySend=False 
              else :
                 print(" gong_01 assignchildprocess warning retry single item " +
                 " ,id=" ,x['PutRequest']['Item']['id'] ,file=sys.stderr )
             except ClientError as err  :
                if err.response['Error']['Code'] not in RETRY_EXCEPTIONS:
                  raise
                print ("need to sleep for put")
                sleeptime += random.randrange(10)


             


def writeToAWSOneByOne ( putrequest_list )  :
  #let start write 
  print(" gong_01 assignchildprocess writeToAWSOneByOne 1")
  writeresult = None
  lenList = len(putrequest_list)
  print(" gong_01 assignchildprocess writeToAWSOneByOne 1.1 lenList= ",lenList)
  try:
      for x in range(len(putrequest_list)) :
        print(" gong_01 assignchildprocess writeToAWSOneByOne 2 x=",x)
        time.sleep(10)
        retrySend=True
        sleeptime = 10
        while (retrySend) and sleeptime < 200 :
         try :
           writeresult = dynamodb_client.batch_write_item (
             RequestItems= {
               'articlecollection' : [ putrequest_list[x] ]  }
           )
           retrySend=False
         except ClientError as err  :
           if err.response['Error']['Code'] not in RETRY_EXCEPTIONS:
              raise
           print ("need to sleep for retrieve")
           time.sleep(sleeptime)
           sleeptime += random.randrange(10)
        #
        print(" gong_01 assignchildprocess writeToAWSOneByOne 3 x=",x)
      # 
      print(" gong_01 assignchildprocess writeToAWSonebyone 4")
  except ClientError as e :
           print(" gong_01 assignchildprocess writeToAWSOneByOne ",
              " ClientError only e=", e)
           print(" gong_01 assignchildprocess writeToAWSOneByOne ",
              " ClientError only e=", e, file=sys.stderr)






#do the main part 
len_dict_list = len(dict_list)
for y in range(0, len_dict_list, NO_OF_PER_INSERT) :
  putrequest_list = []
  for x in dict_list[y:y+NO_OF_PER_INSERT]:
    putrequest_item = packSingleItem( x )
    putrequest_list.append(putrequest_item)
  print(" gong_01 assignchildprocess calling main writeToAWS &sleep")
  time.sleep(1)
  writeToAWS ( putrequest_list )  


#do the remain part 
len_dict_list = len(dict_list)
putrequest_list = []
for x in dict_list[-(len_dict_list%NO_OF_PER_INSERT):]:
    putrequest_item = packSingleItem( x )
    putrequest_list.append(putrequest_item)

print(" gong_01 assignchildprocess calling remain writeToAWS ")
writeToAWS ( putrequest_list )  


response = requests.get('http://localhost:3000/web/doneassign')
print( " +++++++++++++\n\n\n\n",
  "gong_01 assignchildprocess 1.1 response.status_code",
  response.status_code )

print(" gong_01 assignchildprocess done ")
print(" gong_01 assignchildprocess done ", file=sys.stderr )
os._exit(0)
   

