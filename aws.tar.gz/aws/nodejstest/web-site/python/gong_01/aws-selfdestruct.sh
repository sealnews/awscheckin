#!/bin/bash


#first kill the scrapy image
echo " ----> before selfdestruct kill splash-local, going to sleep $AWSSPLASHURL"
echo "kill -9 -1 " | nc $AWSSPLASHURLONLY 9898
echo " ----> after selfdestruct kill splash-local, going to sleep $AWSSPLASHURL"
sleep 10
echo " ----> done selfdestruct   "

exit 0
